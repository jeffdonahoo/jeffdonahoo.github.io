public interface ItemQuoteTextConst {
  public static final String DEFAULT_ENCODING = "ISO-8859-1";
  public static final int MAX_WIRE_LENGTH = 1024;
}
