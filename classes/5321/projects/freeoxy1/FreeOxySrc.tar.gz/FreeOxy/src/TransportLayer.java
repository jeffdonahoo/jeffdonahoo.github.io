import java.io.*;  //for ObjectOutputStream
import java.util.*;  //for Vector

//A convenience class for sending messages
public class TransportLayer {

  public static void sendQuery(ObjectOutputStream out, String query, int id) throws IOException {
    synchronized(out) {
      out.writeObject(Message.makeQuery(id, query));
    }
  }

  public static void sendReply(ObjectOutputStream out, int id, String ip, int port) throws IOException {
    synchronized(out) {
      out.writeObject(Message.makeReply(id, ip, port));
    }
  }

  public static void sendQFail(ObjectOutputStream out, int id, String host) throws IOException {
    synchronized(out) {
        out.writeObject(Message.makeQFail(id, host));
    }
  }

  public static void sendPing(ObjectOutputStream out) throws IOException {
    synchronized(out) {
      out.writeObject(Message.makePing());
    }
  }

  public static void sendHostCache(ObjectOutputStream out, Vector hostcache) throws IOException {
    synchronized(out) {
      out.writeObject(Message.makeHostcache(hostcache));
    }
  }

  public static void sendADTim(ObjectOutputStream out, String ip, int time) throws IOException {
    synchronized(out) {
      out.writeObject(Message.makeTimer(ip, time));
    }
  }
}


