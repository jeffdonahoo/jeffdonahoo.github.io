import java.net.*;
import java.io.*;

//listens for requests for the browser and creates RequestHandlers to handle them
public class ProxyBottom implements Runnable {
  ServerSocket sock;

  //bind to the appropriate location
  public ProxyBottom() throws IOException {
    sock = new ServerSocket();
    sock.setReuseAddress(true);
    sock.bind(new InetSocketAddress("127.0.0.1", Common.SERVER_PORT));
  }

  public int getPort() {
    return sock.getLocalPort();
  }

  //listen for requests and create RHs for them
  public void run() {
    try {
      while (true) {
        RequestHandler curHandler = new RequestHandler(sock.accept());
        new Thread(curHandler).start();
      }
    } catch (Exception e) {
    }
  }
}