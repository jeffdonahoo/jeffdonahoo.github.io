import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.awt.event.WindowEvent;

/**
 * <p>Title: MainFrame</p>
 * <p>Description: This class is our main application window</p>
 * Date: 11-30-2003
 * @author Scott Fulbright
 */
public class MainFrame extends JFrame {

  private boolean isStarted = false;
  JButton startButton = new JButton("Start");
  JCheckBox paranoidMode = new JCheckBox("Paranoid mode");
  JTextField browserPort = new JTextField(5);
  JLabel browserPortLabel = new JLabel("Browser port");
  JLabel addressLabel = new JLabel("IP Address");
  JTextField address = new JTextField(15);
  static JTextArea statusWindow = new JTextArea(20,80);
  static JScrollPane foo;

  GridBagLayout gridBagLayout = new GridBagLayout();

  public static void appendMessage(String s) {
    synchronized(statusWindow) {
      statusWindow.append(s);
      statusWindow.append("\n");
      JScrollBar vsb = foo.getVerticalScrollBar();
      vsb.setValue(vsb.getMaximum());
    }
  }

  public MainFrame() {
    try {
      BufferedReader config = new BufferedReader(new FileReader("config.txt"));
      Common.myIP = config.readLine();
      Common.paranoidMode = config.readLine().equals("true");
      Common.SERVER_PORT = Integer.parseInt(config.readLine());
      config.close();
    } catch (Exception e) {
      System.out.println("Unable to open config file");
      System.exit(1);
    }

    setTitle("Freeoxy");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    getContentPane().setLayout(gridBagLayout);
    GridBagConstraints c = new GridBagConstraints();

    JPanel topPanel = new JPanel();

    // Add the start button
    topPanel.add(startButton);

    // Add the paranoid mode checkbox
    paranoidMode.setAlignmentX(JCheckBox.RIGHT_ALIGNMENT);
    paranoidMode.setSelected(Common.paranoidMode);
    topPanel.add(paranoidMode);

    // Add the browser port text field and its label
    topPanel.add(browserPortLabel);
    browserPort.setText(""+Common.SERVER_PORT);
    topPanel.add(browserPort);

    // Add the IP address text field and its label
    topPanel.add(addressLabel);
    address.setText(Common.myIP);
    topPanel.add(address);
    c.fill = GridBagConstraints.BOTH;
    c.weightx = 1;
    c.gridx = 0;
    c.gridy = 0;
    getContentPane().add(topPanel, c);

    c.gridy = 1;
    c.gridwidth = 5;
    c.gridheight = 1;
    c.weighty = 1;
    c.fill = GridBagConstraints.BOTH;
    statusWindow.setEditable(false);
    foo = new JScrollPane(statusWindow);
    foo.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    foo.setAutoscrolls(true);
    getContentPane().add(foo, c);

    startButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Common.myIP = address.getText();
        Common.SERVER_PORT = Integer.parseInt(browserPort.getText());
        ConnectionManager cm = new ConnectionManager("hostcache.txt");
        new Thread(cm).start();
        try {
          ProxyBottom pb = new ProxyBottom();
          new Thread(pb).start();
        } catch (Exception er) {
          er.printStackTrace();
        }
        startButton.setEnabled(false);
      }
    });

    paranoidMode.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
      Common.paranoidMode = paranoidMode.isSelected();
    }
  });

  addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent windowEvent) {
        try {
          Common.myIP = address.getText();
          Common.SERVER_PORT = Integer.parseInt(browserPort.getText());
          BufferedWriter config = new BufferedWriter(new FileWriter("config.txt"));
          config.write(Common.myIP);
          config.write("\n");
          config.write(Boolean.toString(Common.paranoidMode));
          config.write("\n");
          config.write(Integer.toString(Common.SERVER_PORT));
          config.write("\n");
          config.close();
        } catch (Exception e) {
          System.out.println("Unable to write config file");
          System.exit(1);
        }
      }
    });


  }

  public static void main(String[] args) {
    MainFrame mainFrame = new MainFrame();
    mainFrame.pack();
    mainFrame.setVisible(true);
  }
}