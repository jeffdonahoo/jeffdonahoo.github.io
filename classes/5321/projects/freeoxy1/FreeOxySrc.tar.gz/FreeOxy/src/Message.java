import java.io.Serializable;
import java.util.Vector;

public class Message implements Serializable {
  public int type;  //identifies the type of the message

  public int id;  //used by lots of things
  public Vector hostcache;  //used by the hostcache messages
  public String url;  //used by query messages

  public String ip;  //used by reply and timer messages
  public int port;  //used by reply messages

  public int time;  //used by timer messages

  public Message(int type, int id, Vector hostcache, String url, String ip, int port, int time) {
    this.type = type;
    this.id = id;
    this.hostcache = hostcache;
    this.url = url;
    this.ip = ip;
    this.port = port;
    this.time = time;
  }

  //what follows are convenience functions that make specific uses of the constructor

  public static Message makeQuery(int id, String url) {
    return new Message(Common.QUERY, id, null, url, null, 0, 0);
  }

  public static Message makeReply(int id, String ip, int port) {
    return new Message(Common.REPLY, id, null, null, ip, port, 0);
  }

  public static Message makePing() {
    return new Message(Common.PING, 0, null, null, null, 0, 0);
  }

  public static Message makeHostcache(Vector hostcache) {
    return new Message(Common.HOSTCACHE, 0, hostcache, null, null, 0, 0);
  }

  public static Message makeTimer(String ip, int time) {
    return new Message(Common.TIMER, 0, null, null, ip, 0, time);
  }

  public static Message makeQFail(int id, String host) {
    return new Message(Common.QFAIL, id, null, host, null, 0, 0);
  }

}