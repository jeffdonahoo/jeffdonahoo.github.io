import java.net.*;       // for server socket
import java.io.*;        // for streams
import java.util.*;
import javax.net.ssl.*;
/**
 * <p>Title: </p>
 * <p>Description:This class creates a server socket and listens on it.
 * Provides methods to access the incoming and outgoing streams for
 * connections accepted on this socket. </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author Ravi Kosuri
 * @version 1.0
 */

public class IncomingConnection implements Runnable {
  SSLServerSocket servSocket;     // server socket
  int port;
  public SSLSocket sock;                 // receive on this on accept

  public ObjectInputStream objIn;
  public ObjectOutputStream objOut;
  /**
   * Constructor
   * @param port
   */
  public IncomingConnection(int port) {
    try{
      this.port = port;
      //construct the SSLServerSocket
      SSLServerSocketFactory sslSrvFact = (SSLServerSocketFactory)SSLServerSocketFactory.getDefault();
      servSocket = (SSLServerSocket)sslSrvFact.createServerSocket(port);
      servSocket.setEnabledCipherSuites(new String[] {
                                        "SSL_DH_anon_WITH_RC4_128_MD5",
                                        "SSL_DH_anon_WITH_DES_CBC_SHA",
                                        "SSL_DH_anon_WITH_3DES_EDE_CBC_SHA",
                                        "SSL_DH_anon_EXPORT_WITH_RC4_40_MD5",
                                        "SSL_DH_anon_EXPORT_WITH_DES40_CBC_SHA"});
    }
    catch(IOException e){
      MainFrame.appendMessage("Socket initiation failed on local port "+port);
    }
  }

  /**
   * Runs forever. Accepts a connection and handles its traffic
   *
   */
  public void run(){
    while (true) {
      try {
        sock = (SSLSocket)servSocket.accept();  //accept connection and construct streams
        objOut = new ObjectOutputStream(sock.getOutputStream());
        objIn = new ObjectInputStream(sock.getInputStream());

        Vector v = new Vector();
        OutgoingConnection[] outConns = null;
        if (ConnectionManager.adTimer.containsKey(sock.getInetAddress().getHostAddress())) {
          sock.close();  //if there is an adTimer for them, close the connection without giving a hostcache
        } else {  //otherwise give them a hostcache
          outConns = ConnectionManager.
              getOutgoingConnections();
          for (int i = 0; i < outConns.length; i++) {
            v.add(outConns[i].getAddress());
          }
          try {
            TransportLayer.sendHostCache(objOut, v);
          }
          catch (Exception e) {
          }
        }

        IncomingConnection[] socks = ConnectionManager.getIncomingConnections();
        boolean good = true;
        //make sure we don't connect to someone on our subnet
        //if (sock.getInetAddress().isSiteLocalAddress()) {
        if (sock.getInetAddress().isLinkLocalAddress()) {
          sock.close();
          good = false;
        }

        //don't allow connections from people who are already connected to us
        for (int i = 0; i < socks.length && good; i++) {
          if (socks[i] != null && socks[i] != this) {
            if (socks[i].sock != null) {
              String addr = socks[i].sock.getInetAddress().getHostAddress();
              if (addr.equals(sock.getInetAddress().getHostAddress())) {
                sock.close();
                good = false;
              }
            }
          }
        }

        //only allow up to fanIn - 1 connections (always keep one port open
        //to serve hostcaches)
        if (good && ConnectionManager.currentlyServing == Common.fanIn - 1) {
          sock.close();
          good = false;
        }

        if (!good) {
          continue;
        }

        //send timer and IP messages, and add them to our hostcache
        ConnectionManager.currentlyServing++;
        ConnectionManager.sendTimerToOutgoing(sock.getInetAddress().getHostAddress());
        ConnectionManager.sendIPToOutgoing(sock.getInetAddress().getHostAddress());
        HostCache1.addHost(new Host1(sock.getInetAddress().getHostAddress()));

        while (true) {
          try {
            Message m;
            synchronized (objIn) {
              m = (Message) objIn.readObject();  //read a Message
            }
            //dispatch or handle it based on the type
            if (m.type == Common.QUERY) {
              Routing.handleQuery(this, m.id, m.url);
            }
            if (m.type == Common.HOSTCACHE) {
              HostCache1.updateHostCache(m.hostcache);
            }
            if (m.type == Common.PING) {
              v.clear();
              outConns = ConnectionManager.getOutgoingConnections();
              for (int i = 0; i < outConns.length; i++) {
                v.add(outConns[i].getAddress());
              }
              TransportLayer.sendHostCache(objOut, v);
            }
            if (m.type == Common.TIMER) {
              ConnectionManager.recvTimerMessage(m.time, m.ip);
            }
          }

          catch (Exception e) {
            break;
          }
        }
        ConnectionManager.currentlyServing--;
      }
      catch (Exception e) {
      }
    }
  }

  /**
   * Closes the connection. Starts listening for new connections.
   */
  public void close() throws IOException{
    sock.close();
  }

  /**
   * Shuts the server socket down.
   * Is this the best way to do this?(This is temporary for now).
   * @throws IOException
   */
  public void shutdown() throws IOException{
    servSocket.close();
  }
}
