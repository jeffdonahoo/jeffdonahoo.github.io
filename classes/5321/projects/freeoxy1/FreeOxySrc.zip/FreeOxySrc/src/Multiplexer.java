import java.io.*;
import java.net.*;
import java.util.*;
import javax.net.ssl.*;

//A Multiplexer receives requests from RequestHandlers and dispatches them to
//a Demultiplexer
public class Multiplexer implements Runnable {
  SSLSocket sock;  //the socket to the demux
  ObjectOutputStream out;  //...and its streams
  ObjectInputStream in;
  public HashMap idToRH = new HashMap();  //a map from ids to RequestHandlers
  Thread myThread;

  public long lastLiveTime;
  public boolean dead = false;

  public Multiplexer(SSLSocket sock) {
    this.sock = sock;
    try {
      out = new ObjectOutputStream(sock.getOutputStream());
      lastLiveTime = new Date().getTime();
    }
    catch (IOException ex) {
    }
  }

  //sends Packet p to the demux
  public void send(Packet p) {
    synchronized(this) {
      try {
        out.writeObject(p);
      }
      catch (IOException ex) {
      }
    }
  }

  //gets an unused ID for new RHs
  public int getID(RequestHandler rh) {
    int retVal = Common.rng.nextInt();
    Integer id = new Integer(retVal);
    while(idToRH.containsKey(id)) {
      retVal = Common.rng.nextInt();
      id = new Integer(retVal);
    }
    idToRH.put(id, rh);

    return retVal;
  }

  public void run() {
    myThread = Thread.currentThread();

    Packet inPacket = null;

    try {
      sock.setSoTimeout(Common.PHTTP_TIMEOUT);
      in = new ObjectInputStream(sock.getInputStream());

      while (!dead || idToRH.size() > 0) {  //while we haven't PHTTP-Timeouted or there are still RHs running
        boolean timeout = false;
        try {
          inPacket = (Packet) in.readObject();  //read a Packet
        } catch (SocketTimeoutException e) {
          timeout = true;
        }
        if (!timeout) {
          Integer id = new Integer(inPacket.senderID);  //dispatch it to the appropriate RH
          if (idToRH.containsKey(id)) {
            RequestHandler r = (RequestHandler) idToRH.get(id);
            r.receivePacket(inPacket);
          }
        }
      }
    } catch (Exception e) {
    }

    Packet p = new Packet(0, null);
    p.closePacket = true;  //send a packet indicating we wish to close
    send(p);
    try {
      in.readObject();  //wait for the flow control packet, then close the packet
      sock.close();
    } catch (Exception e) {
    }
  }
}