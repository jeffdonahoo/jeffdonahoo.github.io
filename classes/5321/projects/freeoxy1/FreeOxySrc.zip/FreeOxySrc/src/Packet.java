import java.io.*;

public class Packet implements Serializable {
  public int senderID;
  public byte[] data;
  public boolean lastPacket = false;
  public boolean closePacket = false;

  public Packet(int senderID, byte[] data) {
    this.senderID = senderID;
    this.data = data;
  }
}