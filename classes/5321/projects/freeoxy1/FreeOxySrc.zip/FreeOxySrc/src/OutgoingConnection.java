
import java.io.*;               // for input and output streams
import java.net.*;              // for socket
import java.util.*;             //for Date
import javax.net.ssl.*;         //for SSLSocket

/**
 * <p>Title: </p>
 * <p>Description:Class for outgoing connections on the servent.
 * Creates a socket on the given IP address and port, and provides incoming
 * and outgoing streams </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author Ravi Kosuri
 * @version 1.0
 */

public class OutgoingConnection implements Runnable {
  public SSLSocket clntSock;
  public long lastLiveTime;
  public ObjectOutputStream objOut;
  public ObjectInputStream objIn;

  /**
   * Create a connection to given ip and port
   * @param ip
   * @param port
   * @throws java.lang.Exception
   */
  public OutgoingConnection(String ip, int port) throws UnknownHostException, IOException{
    SSLSocketFactory sslFact = (SSLSocketFactory)SSLSocketFactory.getDefault();
    clntSock = (SSLSocket)sslFact.createSocket();
    clntSock.setEnabledCipherSuites(new String[] {  //construct SSLSocket
                                     "SSL_DH_anon_WITH_RC4_128_MD5",
                                     "SSL_DH_anon_WITH_DES_CBC_SHA",
                                     "SSL_DH_anon_WITH_3DES_EDE_CBC_SHA",
                                     "SSL_DH_anon_EXPORT_WITH_RC4_40_MD5",
                                     "SSL_DH_anon_EXPORT_WITH_DES40_CBC_SHA"});

    clntSock.setSoTimeout(Common.FAIL_TIMEOUT);
    try {  //attempt to connect and create streams
      clntSock.connect(new InetSocketAddress(ip, port));
      objIn = new ObjectInputStream(clntSock.getInputStream());
      objOut = new ObjectOutputStream(clntSock.getOutputStream());
    } catch (Exception e) {
      objIn = null;
      objOut = null;
      return;
    }
  }

  public String getAddress() {
    return clntSock.getInetAddress().getHostAddress();
  }

  public void run() {
    while(true) {
      try {
        Message m;
        synchronized(clntSock.getInputStream()) {
          m = (Message) objIn.readObject(); //try to read a message
          //this will never timeout as long as we are receiving pings
        }
        //dispatch it based on type
        if (m.type == Common.HOSTCACHE) {
          HostCache1.updateHostCache(m.hostcache);
          lastLiveTime = new Date().getTime();
        }
        if (m.type == Common.REPLY) {
          Routing.handleReply(this, m.id, m.ip, m.port);
        }
        if (m.type == Common.QFAIL) {
          Routing.handleQfail(this, m.id, m.url);
        }
      } catch (Exception e) {
        break;
      }
    }

    try {
      close();
    } catch (Exception e) {

    }
  }

  /**
   * close the socket
   * @throws IOException
   */
  public void close() throws IOException{
    clntSock.close();
  }
}