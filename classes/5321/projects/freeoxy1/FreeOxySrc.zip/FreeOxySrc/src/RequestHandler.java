import java.net.*;
import java.io.*;
import java.util.*;

//This handles one HTTP request from the browser
public class RequestHandler implements Runnable {
  public Socket browserSock;
  public Vector inQueue = new Vector();

  public RequestHandler(Socket sock) {
    browserSock = sock;
  }

  //called to give a packet to this RH
  public void receivePacket(Packet p) {
    inQueue.add(p);
    synchronized(this) {
      this.notify();
    }
  }

  //called within this RH to receive a packet
  public Packet recv()
  {
    if (inQueue.size() == 0) {
      synchronized(this) {
        try {
          this.wait();
        } catch (InterruptedException e) {
        }
      }
    }

    return (Packet)inQueue.remove(0);
  }

  public void run() {
    Packet inPacket;
    Packet outPacket;
    int myID = 0;
    Multiplexer thisMux = null;

    try {
      BufferedReader sockIn = new BufferedReader(new InputStreamReader(browserSock.getInputStream()));
      byte[] inBuf = new byte[Common.BUFSIZ];
      OutputStream sockOut = browserSock.getOutputStream();

      String line = sockIn.readLine();  //read the first line of the request
      int t = line.indexOf("http://");
      String host = line.substring(t + 7, line.indexOf('/', t + 7));  //get the server name
      MainFrame.appendMessage("Browser requested " + host);

      thisMux = MuxController.getMux(host);  //get a multiplexer for the server
      if (thisMux == null) {  //if we couldn't for some reason
        MainFrame.appendMessage("Query failed");  //report failure
        browserSock.close();
        return;
      }
      myID = thisMux.getID(this);  //get an id for our packets

      outPacket = new Packet(myID, line.getBytes("US-ASCII"));
      thisMux.send(outPacket);  //send first line of proxy traffic

      while(!(line = sockIn.readLine()).equals("")) {  //send rest of proxy traffic
        outPacket = new Packet(myID, line.getBytes("US-ASCII"));
        thisMux.send(outPacket);
      }
      outPacket = new Packet(myID, "".getBytes("US-ASCII"));
      thisMux.send(outPacket);

      int contentLength = 0;

      Packet p = recv();  //receive a packet indicating contentLength
      try {
        contentLength = Integer.parseInt(new String(p.data, "US-ASCII"));
      } catch (NumberFormatException e) {
      }
      //send additional data
      char[] buf = null;
      int bufsiz = (contentLength > Common.BUFSIZ) ? Common.BUFSIZ : contentLength;
      if (contentLength > 0) {
        buf = new char[ bufsiz ];
      }

      //send additional data if necessary
      for(int i = 0; i < contentLength; ) {
        int len = sockIn.read(buf, 0, (buf.length < (contentLength - i)) ? buf.length : contentLength - i);
        outPacket = new Packet(myID, new String(buf, 0, len).getBytes("US-ASCII"));
        thisMux.send(outPacket);
        i += len;
      }

      while(true) {
        p = recv();  //receive data from the other side of the proxy
        if (p.lastPacket) {  //if this request is complete
          break;
        }
        sockOut.write(p.data);  //send it to the browser
      }

      p.lastPacket = true;
      thisMux.send(p);  //inform the other end that we're done
      thisMux.idToRH.remove(new Integer(myID));  //remove record of ourselves
      browserSock.close();

    } catch (Exception e) {
    }
    if (thisMux != null) {
      thisMux.idToRH.remove(new Integer(myID));
    }
  }

}