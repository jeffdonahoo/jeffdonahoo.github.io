/**
 * RoutingConsumeThread
 *
 * 11-24-2003
 */

import java.io.*; /* for InputStream and OutputStream */
import java.net.*;

/**
 * This class forwards data from the source socket to the destination socket
 */
class RoutingConsumeThread extends Thread
{
  protected static final int MAXSEGSIZE = 1460; /* MSS for ethernet */
  protected Socket source; /* the source socket */
  protected Socket dest; /* the destination socket */

  /**
   * instantiates a RoutingConsumeThread and associates the source and dest
   * handles above with sockets
   *
   * @param s the source socket
   * @param d the destination socket
   */
  public RoutingConsumeThread(Socket s, Socket d)
  {
    source = s;
    dest = d;
  }

  /**
   * the body of statements that the thread executes
   */
  public void run()
  {
    int cnt; /* the number of bytes read from the socket */
    byte[] buf = new byte[MAXSEGSIZE]; /* create a buffer to hold data */
    try {
      InputStream sourceIn = source.getInputStream();
      OutputStream destOut = dest.getOutputStream();
      while (true) {
        while ( (cnt = sourceIn.read(buf)) > 0) {
          destOut.write(buf, 0, cnt);
          destOut.flush();
        }
        dest.shutdownOutput();
        dest.close();
        source.close();
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
};
