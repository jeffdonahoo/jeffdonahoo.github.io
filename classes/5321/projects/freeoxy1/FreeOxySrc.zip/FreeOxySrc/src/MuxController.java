import java.util.*;
import javax.net.ssl.*;

//Handles assignment of multiplexers to RequestHandlers
public class MuxController {
  public static HashMap hostToMux = new HashMap();  //maps host to multiplexers
  public static HashMap hostToTask = new HashMap();  //maps host to TimerTasks
  public static Timer timer = new Timer();  //used to schedule things

  //gets a multiplexer for the given host, querying if necessary
  public static Multiplexer getMux(String host) {
    synchronized(hostToMux) {
      if (hostToMux.containsKey(host)) {  //if we already have a multiplexer for this host
        TimerTask t = (TimerTask)hostToTask.get(host);
        t.cancel();  //reset the PHTTP timer
        scheduleTimeout(host);
        return (Multiplexer)hostToMux.get(host);  //and return it
      }
    }

    return queryForMux(host);  //otherwise query for a multiplexer
  }

  //schedules the PHTTP timeout for a mux
  public static void scheduleTimeout(final String h) {
    TimerTask task = new TimerTask() {  //construct timeout task
      public void run() {
        Multiplexer mux = (Multiplexer)hostToMux.remove(h);
        mux.dead = true;  //alert the mux that it's dead
        hostToTask.remove(h);
      }
    };
    hostToTask.put(h, task);
    timer.schedule(task, Common.PHTTP_TIMEOUT);  //schedule the timeout
  }

  //create a new multiplexer pointed at a given demultiplexer
  public static void addMux(String host, String addr, int port) {
    try {
      SSLSocketFactory sslFact = (SSLSocketFactory)SSLSocketFactory.getDefault();
      SSLSocket sock = (SSLSocket)sslFact.createSocket(addr, port);
      sock.setEnabledCipherSuites(new String[] {  //construct the SSLSocket
                                  "SSL_DH_anon_WITH_RC4_128_MD5",
                                    "SSL_DH_anon_WITH_DES_CBC_SHA",
                                    "SSL_DH_anon_WITH_3DES_EDE_CBC_SHA",
                                    "SSL_DH_anon_EXPORT_WITH_RC4_40_MD5",
                                    "SSL_DH_anon_EXPORT_WITH_DES40_CBC_SHA"});

      Multiplexer mux = new Multiplexer(sock);  //create the mux
      hostToMux.put(host, mux);

      scheduleTimeout(host);

      new Thread(mux).start();
    } catch (Exception e) {
    }
  }

  //removes the mux for a given host
  public static void removeMux(String host) {
    hostToMux.remove(host);
  }

  //originates a query for a mux
  public static Multiplexer queryForMux(String host) {
    try {
      Routing.originateQuery(host);
    } catch (Exception e) {
      return null;
    }

    if (!hostToMux.containsKey(host)) {
      return null;
    }

    return (Multiplexer)hostToMux.get(host);
  }
}