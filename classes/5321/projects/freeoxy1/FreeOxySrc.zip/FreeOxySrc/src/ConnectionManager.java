import java.io.*;            // File handling
import java.util.*;          // for Random

public class ConnectionManager implements Runnable {

  private static Vector InConnList;          // vector of incoming connections
  private static Vector OutConnList;         // vector of outgoing connections
  static Timer timer;  //used to schedule various things
  TimerTask resetPorts;  //the task for port resetting
  TimerTask sendPings;  //the task for ping sending and liveness checking
  public static ConnectionManager me;  //a handle to ourselves
  public static int currentlyServing = 0;  //the number of incoming connections that are in use
  public static HashMap adTimer = new HashMap();  //keeps track of live adTimers
  public static HashMap usageTimer = new HashMap();  //keeps track of live usageTimers

  //Kills outgoing connection #i, removes it from the list of outgoing connections,
  //and wakes up the connection manager thread
  public void killConnection(int i) {
    OutgoingConnection outConn = (OutgoingConnection)OutConnList.get(i);
    try {
      outConn.close();
    } catch (Exception e) { }
    OutConnList.remove(i);
    synchronized(this) {
      this.notify();
    }
  }

  //sends timer messages about ip to all outgoing connections
  public static void sendTimerToOutgoing(String ip) {
    int value = Common.TIMER_CONSTANT;
    if (usageTimer.containsKey(ip)) {  //add the usage timer if it exists
      Integer timeVal = (Integer)usageTimer.get(ip);
      value += timeVal.intValue();
    }

    for(int i = 0; i < OutConnList.size(); i++) {  //send the timer message to all outgoing connections
      OutgoingConnection c = (OutgoingConnection)OutConnList.get(i);
      try {
        TransportLayer.sendADTim(c.objOut, ip, value);
      } catch (Exception e) { }
    }
  }

  //handles receipt of timer messages
  public static void recvTimerMessage(int time, final String ip) {
    int value = 0;
    if (adTimer.containsKey(ip)) {  //adds the adTimer value if it exists
      Integer i = (Integer)adTimer.remove(ip);
      value += i.intValue();
    }
    value += time;

    adTimer.put(ip, new Integer(value));  //adds the adTimer value to the appropriate map

    final int timerValue = value;
    TimerTask adTimerTask = new TimerTask() {  //construct event to fire when adTimer expires
      final String ipAddr = ip;
      final int initValue = timerValue;

      public void run() {
        adTimer.remove(ipAddr);  //remove the record of the adTimer

        TimerTask usageTimerTask = new TimerTask() {  //construct task to execute when usage timer expires
          final String id = ipAddr;
          public void run() {
            usageTimer.remove(id);  //remove record of usage timer
          }
        };
        int timeVal = Common.TIMER_MULTIPLIER * initValue;
        timer.schedule(usageTimerTask, timeVal);  //schedule usage timer
        usageTimer.put(ipAddr, new Integer(timeVal));  //add record for usage timer
      }
    };

    timer.schedule(adTimerTask, value);  //schedule adTimer
  }

  /**
   * Constructor
   * Initializes the host cache with entries from a bootstrap file and the TimerTasks
   */
  public ConnectionManager(String bootFileName){
    try{
      resetPorts = new TimerTask() {
        public void run() {
          MainFrame.appendMessage("End of day, resetting ports");
          for(int i = 0; i < InConnList.size(); i++) {  //stop listening on all old ports
            IncomingConnection conn = (IncomingConnection)InConnList.get(i);
            try {
              conn.close();
              conn.shutdown();
            } catch (IOException e) {
            }
          }

          InConnList.clear();

          initListeners();  //begin listening on new ports
        }
      };

      sendPings = new TimerTask() {
        public void run() {
          MainFrame.appendMessage("Sending pings");
          Date d = new Date();

          for(int i = 0; i < OutConnList.size(); i++) {  //check liveness
            OutgoingConnection outConn = (OutgoingConnection)OutConnList.get(i);
            if (outConn.lastLiveTime < d.getTime() - Common.PING_TIMEOUT) {  //if he hasn't sent us a hostcache in the last Common.PING_TIMEOUT msec
              killConnection(i);  //kill him
              continue;
            }

            try {
              TransportLayer.sendPing(outConn.objOut);  //send ping
            } catch (Exception e) {
              killConnection(i);  //if sending of ping fails, kill connection
            }
          }
        }
      };

      HostCache1.init(bootFileName);
      timer = new Timer();
    }
    catch(Exception e){
      MainFrame.appendMessage("Cannot read from bootstrap file");
      System.exit(1);
    }

    InConnList = new Vector();           // incoming list of connections
    OutConnList = new Vector();          // outgoing list of connections
  }

  //sends a hostcache message with one ip to all outgoing connections
  //--called when a servent connects to this servent
  public static void sendIPToOutgoing(String ip) {
    Vector v = new Vector();  //construct the vector
    v.add(ip);
    for(int i = 0; i < OutConnList.size(); i++) {
      OutgoingConnection outConn = (OutgoingConnection)OutConnList.get(i);

      if (outConn.objOut != null) {  //send it to all outgoing connections
        try {
          TransportLayer.sendHostCache(outConn.objOut, v);
        } catch (Exception e) { }
      }
    }
  }

  //returns an array of all outgoing connections
  public static OutgoingConnection[] getOutgoingConnections() {
    OutgoingConnection[] retVal = new OutgoingConnection[OutConnList.size()];
    for(int i = 0;i  < retVal.length; i++) {
      retVal[i] = (OutgoingConnection)OutConnList.get(i);
    }
    return retVal;
  }

  //returns an array of all incoming connections
  public static IncomingConnection[] getIncomingConnections() {
    synchronized(me) {
      IncomingConnection[] retVal = new IncomingConnection[InConnList.size()];
      for (int i = 0; i < retVal.length; i++) {
        retVal[i] = (IncomingConnection) InConnList.get(i);
      }
      return retVal;
    }
  }

  /**
   * returns an outgoing connection that connects(presumably) to another
   * FreeOxy server.
   * @return
   * @throws java.lang.Exception
   */

  private OutgoingConnection getOutgoingConnection(){
    Host1 h = HostCache1.getRandomHost();
    if (h == null) {
      MainFrame.appendMessage("Hostcache empty");
      return null;
    }
    String ip = h.getIPAddress();
    int port = this.getRandomPort(ip);
    try{
      for(int i = 0; i < OutConnList.size(); i++) {
        OutgoingConnection o = (OutgoingConnection)OutConnList.get(i);
        if (o.getAddress().equals(ip)) {  //don't return a connection to someone we already have a connection to
          return null;
        }
      }
      MainFrame.appendMessage("Trying to connect to " + ip + " " + port);
      OutgoingConnection newConn = new OutgoingConnection(ip,port);  //attempt connection
      if (newConn.objOut != null) {
        MainFrame.appendMessage("Connected to " + ip + ":" + port);
        new Thread(newConn).start();  //start a new OutgoingConnection if it succeeded
        return newConn;
      } else {  //otherwise repot failure
        MainFrame.appendMessage("Connection to " + ip + ":" + port + " failed");
        return null;
      }
    }
    catch(Exception e){
      MainFrame.appendMessage("Connection to " + ip + ":" + port + " failed");
      return null;
    }
  }

  //gets port #i for this host based on the hash function
  public int getPort(int i) {
    return (new Host1(Common.myIP)).getPorts()[i];
  }

  //gets a random port of host ip based on the hash function
  public static int getRandomPort(String ip) {
    int[] ports = new Host1(ip).getPorts();
    return ports[Common.rng.nextInt(ports.length)];
  }

  public void schedulePings() {
    Date d = new Date();
    timer.scheduleAtFixedRate(sendPings, new Date(d.getTime() + Common.PING_TIME), Common.PING_TIME);
  }

  public void schedulePortChange() {
    Date d = new Date();
    timer.scheduleAtFixedRate(resetPorts, new Date(d.getTime() + 86400000), 86400000);
  }

  //creates necessary IncomingConnections and starts them
  public void initListeners() {
    for(int i = 0; i < Common.fanIn; i++){
      int port = getPort(i);
      IncomingConnection conn = new IncomingConnection(getPort(i));
      new Thread(conn).start();
      InConnList.add(conn);
      MainFrame.appendMessage("Listening on port " + port);
    }
  }

  /**
   * Responsible for creating fanIn number of incoming connection threads and
   * maintaining fanout number of outgoing connections
   */
  public void run(){

    MainFrame.appendMessage("Connection manager running");
    me = this;

    //create fanIn number of incoming connections
    initListeners();

    //make an initial try to get fanout number of outgoing conections
    for(int i=0; i < Common.fanout; i++) {
      OutgoingConnection outConn = this.getOutgoingConnection();
      if (outConn != null) {
        OutConnList.add(outConn);
      }
    }

    //schedule periodic tasks
    schedulePings();
    schedulePortChange();

    while(true) {
      if (!HostCache1.isEmpty()) {  //if we have ips to try
        while (OutConnList.size() < Common.fanout) {  //and we need more outgoing connections
          OutgoingConnection outConn = this.getOutgoingConnection();  //try to get one
          if (outConn != null) {  //if it succeeded, add it to the list
            OutConnList.add(outConn);
          } else {  //otherwise wait and try again
            synchronized(this) {
              try {
                this.wait(10000);
              }
              catch (InterruptedException ex) {
              }
            }
          }
        }
      }
      try {  //wait for more hostcache info
        synchronized(this) {
          this.wait();
        }
      } catch (InterruptedException e) {
      }
    }
  }
}

