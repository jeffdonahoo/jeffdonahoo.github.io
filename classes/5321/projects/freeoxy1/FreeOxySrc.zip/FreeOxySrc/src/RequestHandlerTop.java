import java.net.*;
import java.io.*;
import java.util.*;

//One of these will be the proxy for each RequestHandler
public class RequestHandlerTop implements Runnable {
  private Vector inQueue;
  private Demultiplexer demux;

  public RequestHandlerTop(Demultiplexer d) {
    inQueue = new Vector();
    demux = d;
    d.addRHT();
  }

  //called to give a packet to this RHT
  public void receivePacket(Packet p) {
    inQueue.add(p);
    synchronized(this) {
      this.notify();
    }
  }

  //called from within this RHT to receive a packet
  public Packet recv() {
    if (inQueue.size() == 0) {
      synchronized(this) {
        try {
          this.wait();
        } catch (InterruptedException e) {
        }
      }
    }

    return (Packet)inQueue.remove(0);
  }

  public void run() {
    Packet p;

    while(true) {
      p = recv();

      //get the webserver
      String line = new String(p.data);
      String[] inter = line.split(" ");
      String host = inter[1].split("/")[2];
      String page = inter[1].split("/", 4)[3];
      int contentLength = 0;

      Socket webSocket = null;  //connect to it
      try {
        webSocket = new Socket(host, 80);
      } catch (Exception e) {
        return;
      }

      try {
        InputStream webStream = webSocket.getInputStream();
        OutputStream webW = webSocket.getOutputStream();

        StringBuffer request = new StringBuffer();  //build the first line
        request.append(inter[0]).append(" /");
        if (page.length() > 0) {
          request.append(page);
        }
        request.append(' ').append(inter[2]).append('\n');
        webW.write(request.toString().getBytes("US-ASCII"));  //send the first line

        p = recv();
        line = new String(p.data, "US-ASCII");
        while(!line.equals("")) {  //forward header traffic
          if (line.indexOf("Keep-Alive") == -1) {  //don't forward anything that would cause the browser not to close after it's done sending
            webW.write(p.data);
            webW.write("\n".getBytes("US-ASCII"));
          }

          int i = line.indexOf("Content-Length: ");  //catch contentLength so we can send it back to the RH
          if (i != -1) {
            contentLength = Integer.parseInt(line.substring(i + 16));
          }
          p = recv();
          line = new String(p.data, "US-ASCII");
        }
        webW.write("Connection: Close\n".getBytes("US-ASCII"));
        webW.flush();

        Packet outPacket = new Packet(p.senderID, String.valueOf(contentLength).getBytes("US-ASCII"));
        demux.send(outPacket);  //send the contentLength packet
        if (contentLength > 0) {  //if we need to receive additional data
          byte[] buf;

          for(int i = 0; i < contentLength; ) {  //receive it and send it to the webserver
            buf = recv().data;
            webW.write(buf, 0, buf.length);
            webW.flush();
            i += buf.length;
          }
        }
        webW.write("\n".getBytes("US-ASCII"));
        webW.flush();

        int count;
        byte[] buf = new byte[Common.BUFSIZ];
        int webContentLength = 0;
        //receive from the webserver and send to the RH
        while((count = webStream.read(buf, 0, Common.BUFSIZ)) > 0) {
          byte[] t = new byte[count];
          for(int i = 0; i < count; i++) {
            t[i] = buf[i];
          }
          outPacket = new Packet(p.senderID, t);
          demux.send(outPacket);
        }

        p.lastPacket = true;
        demux.send(p);  //send a close packet
        recv();  //wait for flow control traffic
        demux.removeRHT();
      } catch (Exception e) {
        p.lastPacket = true;
        demux.send(p);  //send a close packet
        recv();  //wait for flow control traffic
        demux.removeRHT();
      }
    }
  }


}