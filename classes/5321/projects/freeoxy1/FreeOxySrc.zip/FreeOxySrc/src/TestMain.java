/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.net.*;
import java.util.*;
import java.io.*;
import java.security.*;

public class TestMain {

  public static void main( String []args ){
    try {
      BufferedReader config = new BufferedReader(new FileReader("config.txt"));
      Common.myIP = config.readLine();
      Common.paranoidMode = config.readLine().equals("true");
      config.close();
    } catch (Exception e) {
      MainFrame.appendMessage("Unable to open config file");
      System.exit(1);
    }

    ConnectionManager cm = new ConnectionManager("hostcache.txt");
    new Thread(cm).start();
    try {
      ProxyBottom pb = new ProxyBottom();
      new Thread(pb).start();
    } catch (Exception e) {
    }
    Thread.currentThread().suspend();
  }

}