import java.io.*;      // for File i/o and other i/o.
import java.util.*;    // for ArrayList
/**
 * <p>Title: FreeOxy Project</p>
 * <p>Description: This class provides an implementation for the host cache
 * for  a FreeOxy servent</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author Ravi Kosuri
 * @version 1.0
 */

public class HostCache1 {

  private static Vector hc;       // for holding the host cache
  private static Random rand;                // for generating the random index into the list
  private static String filename;
  /**
   * Constructor
   * Initializes the host cache with hosts contained in the file <filename>
   * @param filename
   */
  public static void init (String fn) throws FileNotFoundException, IOException{
    hc = new Vector();       //instantiate the array list
    filename = fn;

    rand = new Random();    // for generating the random index into the list

    FileReader fr = new FileReader(filename);
    BufferedReader br = new BufferedReader(fr);
    String s;    // for reading a line from the file

    //read each line, parse it into a host and then put it into the host cache
    while((s=br.readLine())!=null){

      Host1 host = new Host1(s);
      hc.add(host);
    }
    br.close();
  }

  /**
   * adds the host to the host cache. Returns true if the add is successful.
   * No duplicate inserts allowed.
   * @param host
   * @return
   */
  public static boolean addHost(Host1 host){
    //check for duplicates and then insert
    if(!(contains(host.getIPAddress()))){
      boolean b = hc.add(host);
      if (b) {
        if (ConnectionManager.me != null) {
          synchronized(ConnectionManager.me) {
            ConnectionManager.me.notify();
          }
        }
        try {
          FileWriter fr = new FileWriter(filename);
          for(int i = 0; i < hc.size(); i++) {
            fr.write(((Host1)hc.get(i)).getIPAddress());
            fr.write("\r\n");
          }
          fr.close();
        } catch (Exception e) { }
      }
      return b;
    }
    return false;
  }

  /**
   * Picks a random host from the host cache and returns it.
   * @return
   */
  public static Host1 getRandomHost(){
    if (hc.size() > 0) {
      int randIndex = rand.nextInt(hc.size()); // fetch a random index between 0 and no. of hosts in cache
      return ( (Host1) hc.get(randIndex));
    } else {
      return null;
    }
  }

  public static boolean isEmpty() {
    return hc.isEmpty();
  }

  /**
   * Removes all occurrences of the hosts with the specified ip address.
   * Returns true if there has been at least one remove.
   * @param ipAddr
   * @return
   */
  public static boolean removeHost(String ipAddr){
    boolean remFlag = false;      // set if there is at least one match of the ip in the cache

    for(int i=0; i<hc.size();i++){
      Host1 tempHost = (Host1)hc.get(i);
      if((tempHost.getIPAddress()).equals(ipAddr)){
        hc.remove(i);
        remFlag = true;
      }
    }
    return remFlag;
  }

  /**
   * Removes the specified host(every occurrence) from the host cache.
   * Returns true if the remove was successful.
   * @param host
   * @return
   */
  public static boolean removeHost(Host1 host){
    //return hc.remove(host);
    boolean remFlag = false;

    for(int i=0;i<hc.size();i++){
      if(((Host1)hc.get(i)).equals(host)){
        hc.remove(i);
        remFlag = true;
      }
    }

    return remFlag;
  }

  /**
   * Returns true if the host cache contains the specified ip address.
   * @param ip
   * @return
   */
  public static boolean contains(String ip){
    boolean remFlag=false;

    for(int i=0; i<hc.size();i++){
      Host1 tempHost = (Host1)hc.get(i);
      if((tempHost.getIPAddress()).equals(ip)){
        remFlag = true;
      }
    }
    return remFlag;
  }

  /**
   * Takes a vector of ip addresses(strings) and updates the host cache with the ip addresses
   * @param vc
   */
  public static void updateHostCache(Vector vc){

    for(int i=0;i<vc.size();i++){
      String ip = (String)vc.get(i);
      Host1 tempHost = new Host1(ip);
      addHost(tempHost);
    }

  }

}
