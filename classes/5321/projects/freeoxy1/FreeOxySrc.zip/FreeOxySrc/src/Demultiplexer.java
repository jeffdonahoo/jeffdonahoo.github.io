import java.io.*;  //for the Object<in/out>putStreams
import java.util.*;  //for HashMap
import javax.net.ssl.*;  //for SSLSocket and SSLServerSocket

//A demultiplexer takes Packets from a Multiplexer and dispatches them to the
//appropriate HandlerTop
public class Demultiplexer implements Runnable {
  private SSLServerSocket listener;
  private SSLSocket sock;
  private ObjectInputStream sockIn;
  private ObjectOutputStream sockOut;
  private HashMap idToRHT;
  int rhtCount;

  public Demultiplexer() {
    idToRHT = new HashMap();
    rhtCount = 0;
    try {  //construct SSLServerSocket
      SSLServerSocketFactory sslSrvFact = (SSLServerSocketFactory)SSLServerSocketFactory.getDefault();
      listener = (SSLServerSocket)sslSrvFact.createServerSocket(0);
      listener.setEnabledCipherSuites(new String[] {
                                        "SSL_DH_anon_WITH_RC4_128_MD5",
                                        "SSL_DH_anon_WITH_DES_CBC_SHA",
                                        "SSL_DH_anon_WITH_3DES_EDE_CBC_SHA",
                                        "SSL_DH_anon_EXPORT_WITH_RC4_40_MD5",
                                        "SSL_DH_anon_EXPORT_WITH_DES40_CBC_SHA"});

    } catch (Exception e) { }
  }

  //sends packet p to the Multiplexer
  public void send(Packet p) {
    synchronized(this) {
      try {
        sockOut.writeObject(p);
      }
      catch (IOException ex) { }
    }
  }

  public void addRHT() {
    rhtCount++;
  }

  public void removeRHT() {
    rhtCount--;
  }

  public int getPort() {
    return listener.getLocalPort();
  }

  public void run() {  //receives Packets and dispatches them
    Packet inPacket = null;

    try {
      sock = (SSLSocket)listener.accept();  //accept a connection and create streams
      sockIn = new ObjectInputStream(sock.getInputStream());
      sockOut = new ObjectOutputStream(sock.getOutputStream());
      sock.setSoTimeout(Common.FAIL_TIMEOUT);

      while (true) {
        inPacket = (Packet)sockIn.readObject();
        if (inPacket.closePacket == true) {  //if the Multiplexer indicates desire to close
          break;
        }
        Integer id = new Integer(inPacket.senderID);  //where should this packet go?
        if (idToRHT.containsKey(id)) {  //if it's a preexisting RHT, pass the packet to it
          RequestHandlerTop r = (RequestHandlerTop) idToRHT.get(id);
          r.receivePacket(inPacket);
        }
        else { //otherwise create a new RHT and pass the packet to it
          RequestHandlerTop r = new RequestHandlerTop(this);
          idToRHT.put(id, r);
          r.receivePacket(inPacket);
          new Thread(r).start();
        }
      }
    } catch (Exception e) {
    }

    try {
      while(rhtCount > 0) {  //wait for all RHTs to finish
        synchronized(this) {
          this.wait(Common.PHTTP_TIMEOUT);
        }
      }
      send(inPacket);  //send the flow control packet (the mux waits for this), then close sockets
      sock.close();
      listener.close();
    } catch (Exception e) {
    }
  }

}