
/**
 * <p>Title:FreeOxy project </p>
 * <p>Description: This class represents a host in the FreeOxy network. A host is
 * identified by its ip address.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author Ravi Kosuri
 * @version 1.0
 */
import java.util.*;
import java.security.*;

public class Host1 implements Comparable{

  private String ipAddr;  // ip address of the host

  /**
   * Constructor. Initializes to an ip address.
   * @param ipAddr
   */
  public Host1(String ipAddr) {
    this.ipAddr = ipAddr;
  }

  //gets an array of listening ports based on the hash function
  public int[] getPorts() {
    int[] ports = new int[Common.fanIn];
    try {
      MessageDigest md = MessageDigest.getInstance("MD5");
      Date d = new Date();
      md.update(Long.toOctalString((d.getTime() - d.getTime() % 86400000) / 86400000).getBytes());
      md.update(ipAddr.getBytes());
      byte[] b = md.digest();
      for (int i = 0; i < ports.length; i++) {
        ports[i] = 5000 + (b[ (i * 3) % b.length] * b[(i * 3) % b.length]) % 5000;
      }
    } catch (Exception e) { }
    return ports;
  }

  /**
   * Returns the ip address of the host
   * @return
   */
  String getIPAddress(){
    return ipAddr;
  }

  /**
   * override toString()
   * @return
   */
  public String toString(){
    return ipAddr;
  }

  /**
   * For the comparable interface.
   * Returns 0 if the objects have the same ip and port.
   * @param host
   * @return
   */
  public int compareTo(Object host){
    Host1 tempHost = (Host1) host;
    if ( (this.ipAddr).equals(tempHost.ipAddr)){
      return 0;
    }
    return -1;
  }

  /**
   * returns true if the specified host is the same as me.
   * @param host
   * @return
   */
  public boolean equals(Host1 host){
    if(this.compareTo(host) == 0){
      return true;
    }
    return false;
  }
}
