import java.util.*;

public class Common {
  public static int SERVER_PORT = 12808;  //the port we listen on for the browser
  public static final int BUFSIZ = 1460;  //ethernet frame - headers
  public static final Random rng = new Random();
  public static final int PHTTP_TIMEOUT = 3000;  //time to continue using old query result (msec)
  public static final int FAIL_TIMEOUT = 60000;  //timeout for various failures (msec) - should always be larger than PING_TIME + max estimated RTT
  public static final int PING_TIME = 30000;     //time between pings (msec)
  public static final int PING_TIMEOUT = 45000;  //timeout for ping failure (msec)
  public static boolean paranoidMode;  //whether or not we're in paranoid mode
  public static String myIP;  //the ip to bind to when listening for FreeOxy network traffic
  public static int fanout = 4;  //number of outgoing connections to maintain
  public static int fanIn = (int)(fanout * 1.5);  //number of incoming connections to listen for
  public static final int TIMER_CONSTANT = 60000;  //the constant for the a-d-timer (msec) (see paper)
  public static final int TIMER_MULTIPLIER = 10;  //the multiplier for the a-d- timer (msec) (see paper)

  //constants defining message types
  public static final int QUERY = 0;
  public static final int REPLY = 1;
  public static final int PING = 2;
  public static final int HOSTCACHE = 3;
  public static final int TIMER = 4;
  public static final int QFAIL = 5;
}