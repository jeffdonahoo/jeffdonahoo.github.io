/**
 * Routing
 *
 * 11-20-2003
 */

import java.net.*; /* for HttpURLConnection */
import java.util.*;
import java.io.IOException; /* for Random & Vector */

/**
 * This class handles the origination and forwarding of queries
 */
class Routing
{
  protected static HashMap origTable = new HashMap();
      /* the table of query ids associated with hosts for queries that we
         originated */
  protected static HashMap consumeTable = new HashMap();
      /* table of query ids for queries that we have consumed */
  protected static HashMap forwardTable = new HashMap();
      /* map from query ids to a Vector of handles to outGoingConnections that
         we have already used to forward the query */
  protected static HashMap hostToThreads = new HashMap();
      /* map from hosts to requestHandler threads */
  protected static HashMap cannotFetch = new HashMap();
  protected static Random rand = new Random();
      /* used for generating random numbers for decision-making and id
         generation purposes */
  protected static ConnectionManager connManager;
      /* a handle to the connection mannager */

  /**
   * used to initialize the handle to the connection manager in Routing
   *
   * @param cm a handle to the connection manager
   */
  public static void init(ConnectionManager cm)
  {
    connManager = cm;
  }

  /**
   * used to locate a connection that is not unable to contact host and that we
   * have not already forwarded this query out
   *
   * @param id the id of the query
   * @param host the host that we are trying to contact
   * @return an Socket that we can use to send the query
   */
  protected static OutgoingConnection getConnectionForSearch(int id, String host)
  {
    OutgoingConnection conn = null; /* the socket that will eventually be returned
                                    by this function */
    OutgoingConnection[] connList = connManager.getOutgoingConnections();
        /* list of all outgoing connections */
    Vector v = new Vector();
    Integer objID = new Integer(id);
    /* iterate through the connections and eliminate all the connections that
       are unable to fetch webpages from host */
    for(int i=0; i<connList.length; i++)
    {
      if(cannotFetch.containsKey(connList[i]))
      {
        if(!((Vector)cannotFetch.get(connList[i])).contains(host))
        {
          v.add(connList[i]);
        }
      }
      else
      {
        v.add(connList[i]);
      }
    }
    /* get a random connection from the list we just built that we haven't
       already used to forward this query */
    if(v.size()>0)
    {
      int num = rand.nextInt() % v.size();
      if (num < 0) {
        num = -num;
      }
      conn = (OutgoingConnection)v.get(num);
    }
    else
    {
      return null;
    }

    //v now contains all connections that haven't QFAILed for this host in the past

    boolean done = true; /* tells when we are done with our loop */
    if(forwardTable.containsKey(objID))
    {
      if (((Vector)forwardTable.get(objID)).contains(conn)) {  //we have forwarded this query to him before
        done = false;
      }
    }
    while(!done)
    {
      v.remove(conn);
      if(v.size() == 0)
      {
        return null;
      }
      conn = (OutgoingConnection)v.get(rand.nextInt() % v.size());
      done = true;
      if (forwardTable.containsKey(objID)) {
        if (((Vector)forwardTable.get(objID)).contains(conn)) {
          done = false;
        }
      }
    }
    return conn;
  }

  /**
   * inject a query into the network whose source is this node
   *
   * @param host the host that this query is searching for
   */
  public static void originateQuery(String host) throws QueryException
  {
    MainFrame.appendMessage("Originating query for " + host);
    int newID = rand.nextInt();
    /* get a handle to the current thread */
    Thread curThread = Thread.currentThread();

    /* if we already have a query outstanding for this host */
    if(hostToThreads.containsKey(host))
    {
      /* then we simply add the current thread to the list of threads waiting
         on a response to that query */
      ((Vector)hostToThreads.get(host)).add(curThread);
      return;
    }
    /* otherwise we must initiate a query for this host */
    else
    {
      Vector v = new Vector(); /* the vector of threads that will be associated
                                  with the query for the given host */
      v.add(curThread);
      hostToThreads.put(host, v);
      /* now find a connection to send the query out */
      OutgoingConnection conn = getConnectionForSearch(newID, host);
      System.out.println("got outgoing connection " + conn.getAddress());
      if(conn != null)
      {
        try {
          TransportLayer.sendQuery(conn.objOut, host, newID);
        } catch (Exception e) {
          throw new QueryException("All connections were unable to fetch pages "
                                 + "from: "+host);
        }
      }
      else
      {
        throw new QueryException("All connections were unable to fetch pages "
                                 + "from: "+host);
      }
    }

    origTable.put(new Integer(newID), host);
    try
    {
      curThread.sleep(Common.FAIL_TIMEOUT);
    }
    catch(InterruptedException e)
    {
      /* Do nothing, as this indicates that the query has been replied to */
      return;
    }
    throw new QueryException("Query timed out");
  }

  /**
   * handles the routing of received queries
   *
   * @param incoming the socket that this query arrived on
   * @param id the id of the query we are handling
   * @param host the host that this query is searching for
   */
  public static void handleQuery(IncomingConnection incoming,
                                 int id, String host)
  {
    boolean success = false;
    if(!Common.paranoidMode)
    {
      /* try to fetch the page */
      try {
        URL u = new URL("http://" + host);
        HttpURLConnection conn = (HttpURLConnection) u.openConnection();
        conn.addRequestProperty("User-Agent", "");
        success = conn.getResponseCode() == HttpURLConnection.HTTP_OK;
        conn.disconnect();
      } catch (Exception e) { success = false; }
    }
    /* if we can fetch it, then we reply to this query */
    if(success)
    {
      Demultiplexer dmux = new Demultiplexer();
      new Thread(dmux).start();
      int port = dmux.getPort();
      try {
        TransportLayer.sendReply(incoming.objOut, id, incoming.sock.getLocalAddress().getHostAddress(), port);
      } catch (Exception e) {
      }
      return;
    }
    /* otherwise we forward the query */
    else
    {
      /* find a connection to forward this query out */
      OutgoingConnection conn = getConnectionForSearch(id, host);
      /* check to see if we were unable to find a proxy to forward to */
      if(conn == null)
      {
        try {
          TransportLayer.sendQFail(incoming.objOut, id, host);
        } catch (Exception e) {
        }
        return;
      }
      else
      {
        /* decide if we consume this query */
        if(rand.nextInt()%10==0 && !consumeTable.containsKey(new Integer(id)))
        {
          consumeTable.put(new Integer(id), incoming);
        }
        else
        {
          /* add the found connection to the list of connections that this
             query has been forwarded out */
          if(forwardTable.containsKey(new Integer(id)))
          {
            ((Vector)forwardTable.get(new Integer(id))).add(conn);
          }
          else
          {
            Vector v = new Vector(); /* vector of connections that we have
                                        forwarded this query out */
            v.add(conn);
            forwardTable.put(new Integer(id), v);
          }
        }
        try {
          TransportLayer.sendQuery(conn.objOut, host, id);
        } catch (Exception e) {
        }
        return;
      }
    }
  }

  /**
   * handles the routing of received responses
   *
   * @param incoming the socket that this response came in on
   * @param id the id of the query we are handling
   * @param ip the ip address contained in the response
   * @param port the port contained in the response
   */
  public static void handleReply(OutgoingConnection incoming, int id,
                                    String ip, int port)
  {
    HostCache1.addHost(new Host1(ip));
    /* see if I originated this query */
    if(origTable.containsKey(new Integer(id)))
    {
      String host = (String)origTable.get(new Integer(id)); /* get the host
                                                               associated with
                                                               the query id */
      MuxController.addMux(host, ip, port);
      /* wake up all the threads associated with this host */
      if(hostToThreads.containsKey(host))
      {
        Vector v = (Vector) hostToThreads.get(host);
        if(v!=null)
        {
          for(int i=0; i< v.size(); i++)
          {
            Thread t = (Thread)v.get(i);
            synchronized(t)
            {
              t.interrupt();
              v.remove(i);
            }
          }
          hostToThreads.remove(host);
        }
      }
    }
    /* check to see if I forwarded this query */
    else if(forwardTable.containsKey(new Integer(id)))
    {
      Vector v = (Vector)forwardTable.get(new Integer(id));
      OutgoingConnection conn = (OutgoingConnection)v.get(v.size()-1);
      /* forward reply to the last place I forwarded this to */
      try {
        TransportLayer.sendReply(conn.objOut, id, ip, port);
      } catch (Exception e) {
      }
      return;
    }
    /* check to see if I consumed this query */
    else if(consumeTable.containsKey(new Integer(id)))
    {
      IncomingConnection conn = (IncomingConnection)consumeTable.get(new Integer(id));
      String myIP = conn.sock.getLocalAddress().getHostAddress();
      try {
        ServerSocket serv = new ServerSocket(0);
        TransportLayer.sendReply(conn.objOut, id, myIP, serv.getLocalPort());
        Socket s = serv.accept();
        Socket d = new Socket(incoming.clntSock.getInetAddress(), port);
        RoutingConsumeThread forward = new RoutingConsumeThread(s, d);
        RoutingConsumeThread reverse = new RoutingConsumeThread(d, s);
        forward.start();
        reverse.start();
      } catch (Exception e) {

      }
    }
  }

  /**
   * handle query failure messages
   *
   * @param incoming the socket from which this message arrived
   * @param id the id of the query that failed
   * @param host the host that the failed query was trying to contact
   */
  public static void handleQfail(OutgoingConnection incoming, int id,
                                 String host) {
    /* if this connection already has a cannotFetch entry */
    if(cannotFetch.containsKey(incoming))
    {
      /* we add to it */
      ((Vector)cannotFetch.get(incoming)).add(host);
    }
    /* otherwise */
    else
    {
      /* we just give it a new entry */
      Vector v = new Vector();
      v.add(host);
      cannotFetch.put(incoming, v);
    }
    OutgoingConnection conn = getConnectionForSearch(id, host);
    if(conn == null)
    {
      /* forward the query failure message to someone else */
      if(forwardTable.containsKey(new Integer(id)))
      {
        Vector v = (Vector)forwardTable.get(new Integer(id));
        OutgoingConnection s = (OutgoingConnection)v.get(v.size()-1);
        try {
          TransportLayer.sendQFail(s.objOut, id, host);
        } catch (Exception e) {
        }
        return;
      }
      /* forward the query failure message even if we consumed it */
      if(consumeTable.containsKey(new Integer(id)))
      {
        IncomingConnection s = (IncomingConnection)consumeTable.get(new Integer(id));
        try {
          TransportLayer.sendQFail(s.objOut, id, host);
        } catch (Exception e) {
        }
        consumeTable.remove(new Integer(id));
      }

      if (origTable.containsKey(new Integer(id))) {
        if(hostToThreads.containsKey(host))
        {
          Vector v = (Vector) hostToThreads.get(host);
          if(v!=null)
          {
            for(int i=0; i< v.size(); i++)
            {
              Thread t = (Thread)v.get(i);
              synchronized(t)
              {
                t.interrupt();
                v.remove(i);
              }
            }
            hostToThreads.remove(host);
          }
        }
      }
    }
    else
    {
      /* forward the query to someone I haven't forwarded it to yet */
      if(forwardTable.containsKey(new Integer(id)))
      {
        Vector v = (Vector)forwardTable.get(new Integer(id));
        v.add(conn);
      }
      try {
        TransportLayer.sendQuery(conn.objOut, host, id);
      }
      catch (IOException ex) {
      }
    }
  }
};
