java -cp /usr/share/java/:/usr/share/java:/usr/share/java/idev_bluez.jar:classes Browser 
