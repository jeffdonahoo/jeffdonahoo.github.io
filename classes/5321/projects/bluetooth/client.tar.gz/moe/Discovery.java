import javax.bluetooth.*;
import com.rococosoft.impronto.util.*;
import javax.microedition.io.*;
import com.rococosoft.impronto.util.BluetoothConstants;
import java.io.*;
import java.util.*;
import java.security.*;

/*
  Welcome to callback land.  I'll wait here, wake me up and tell me if you
  enjoyed your stay when you finish.
*/

public class Discovery implements DiscoveryListener
{
    private final static UUID uuid = UUIDUtil.generateUUID("nuggets");  //a unique string identifying the nuggets service
    private static DiscoveryAgent agent;  //used to register for callbacks
    private Vector known;  //this will act like a stack.  It keeps recently queried hosts
    
    public void findNuggets() {
	System.out.println("Finding nuggets");
	try {
	    agent = LocalDevice.getLocalDevice().getDiscoveryAgent();
	} catch (BluetoothStateException e) {
	    System.out.println("kernel recompiles are your friend");
	}

	known = new Vector();
        try {
	    agent.startInquiry(DiscoveryAgent.GIAC, this);  //register for device discovery callbacks
	    synchronized (this) {
		try {
		    this.wait();
		} catch(Exception e) {
		}
	    }
	} catch(BluetoothStateException e) {
	    e.printStackTrace();
	}
    }

    /*
      The DiscoveryListener interface requires implementation of both service discovery callbacks
      and device discovery callbacks.  Since this class only deals with device discovery, the service
      discovery implementations are rather short...
    */

    private boolean searchServices(RemoteDevice[] dList) {
	return false;
    }
    public void serviceSearchCompleted(int transID, int respCode) {}
    public void servicesDiscovered(int transID, ServiceRecord[] servRecord) {}


    public void deviceDiscovered(RemoteDevice btDevice, DeviceClass cod) {
	//On discovery of a device, if we haven't already checked it, 
	//start a thread that searches it for nuggets and if found,
	//exchanges nuggets
	System.out.println("device discovered");
	if (known.contains(btDevice))
	    {
		System.out.println("already knew about him");
	    }
	else
	    {
		known.insertElementAt(btDevice, 0);  //add this device to the top of the stack
		known.setSize(5);  //trim the vector to 5 elements
		Thread dt = new DiscoveredThread(btDevice);
		dt.start();
	    }
    }

    /*
      As far as I can tell, impronto doesn't have a 'discover devices for an infinite amount of time' mode.
      The discovery will eventually finish when it's satisfied that it's found all possible devices.  Since
      we'd like to be discovering forever, we just intercept that event, wait a bit, then discover again.
      
      Justification for waiting a bit:
        Impronto caches known devices and their services.  If we restart the discovery again and nobody new
	is in range, the inquiry will complete very quickly.  On a battery powered device, we want to be
	sleeping most of the time, so these quick retries are bad.
    */

    public void inquiryCompleted(int discType) {
	System.out.println("trying again");

	try {
	    synchronized(this) {
		this.wait(5000);
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	}

	try {
	    agent.startInquiry(DiscoveryAgent.GIAC, this);
	} catch (BluetoothStateException e) {
	    e.printStackTrace();
	}
    }
}

class DiscoveredThread extends Thread implements DiscoveryListener  //once a device is discovered, it gets one of these pointed at it
{
    private RemoteDevice other;
    private static DiscoveryAgent agent = null;

    public DiscoveredThread(RemoteDevice o)  //just initialization
    {
	if (agent == null) {
	    try {
		agent = LocalDevice.getLocalDevice().getDiscoveryAgent();
	    } catch (BluetoothStateException e) {
		System.out.println("It's kernel recompile time for you...");
	    }
	}

	other = o;
    }

    public void run()  //this searches the device 'other' for nuggets and exchanges nuggets with him if it's found
    {
	UUID[] searchList = {UUIDUtil.generateUUID("nuggets")};  //search only for nuggets
	System.out.println("searching device: " + other.toString());

	try {
	    agent.searchServices(null, searchList, other, this);  //yet another callback registration command
	} catch (BluetoothStateException e) {
	    System.out.println("Start recompiling that kernel buddy...");
	}

	synchronized(this)
	    {
		try {
		    this.wait();  //sleep while it searches
		    System.out.println("exiting");
		} catch (Exception e) {
		    e.printStackTrace();
		}
	    }
    }
    
    public void serviceSearchCompleted(int transID, int respCode) {
	System.out.println("search completed");  //on search completion, wake up the run() function so it can exit
	synchronized(this) {
	    this.notifyAll();
	}
    }

    /*
      As with the previous class, two of the callback functions should never be called.  Given that, their
      implementations are... small.
    */

    public void deviceDiscovered(RemoteDevice dev, DeviceClass cod) {}
    public void inquiryCompleted(int foo) { }

    public void servicesDiscovered(int transID, ServiceRecord[] servRecord) {  //we've found the nuggets service...
	System.out.println("Length of servRecord is " + servRecord.length);
	for(int i = 0; i < servRecord.length; i++)
	    {
		exchangeNuggets(servRecord[i].getConnectionURL(0, false));  //so exchange nuggets with him
	    }
    }
    
    public static void exchangeNuggets(String connectString)  //finally, the actual nuggets exchange function
    {
	MessageDigest md5 = null;
	try {
	    md5 = MessageDigest.getInstance("MD5");  //initialize the hash function
	} catch (Exception e) {
	    e.printStackTrace();
	}

	FileInputStream fIn = null;
	//Open the file containing our nugget.
	try {
	    fIn = new FileInputStream("nugget");
	} catch (Exception e) {
	    System.out.println("nuggets file not found, echo 'something incriminating' > nuggets");
	    return;
	}
	
	L2CAPConnection con = null;

	try {
	    con = (L2CAPConnection)Connector.open(connectString);  //attempt to connect to the nuggets service on the remote device
	    int outBufSize = con.getTransmitMTU();

	    byte[] buf = new byte[outBufSize];
	    try
		{
		    int nuggetLen = 0;  //make one pass through the file...
		    int f = 0;
		    while((f = fIn.read(buf)) != -1) {
			nuggetLen += f;  //...calculating the nugget length...
			md5.update(buf, 0, f);  //..and the hash
		    }
		    
		    /*
		      To those familliar with Zero Wing (aka 'All your base are belong to us'), these status messages
		      are by themselves indicative of the order in which they should come.
		    */

		    System.out.println("Nugget sending... How Are You Gentlemen ");
		    
		    //nuggetLen += 16;  //account for the hash
		    byte[] lenBuf = new byte[4];  //calculate byte representation of the length
		    for(int i = 0; i < 4; i++) {  //(the java microedition has no good way of doing this)
			lenBuf[i] = new Integer((nuggetLen % (1 << (8 * (i + 1)))) / (1 << (8 * i))).byteValue();
		    }

		    con.send(lenBuf);  //send the length (4 bytes)
		    byte[] digest = md5.digest();
		    con.send(digest);  //send the hash (16 bytes)
		    
		    fIn = new FileInputStream("nugget");  //reset the file pointer
		    while(fIn.read(buf) != -1) {
			con.send(buf);  //send the nugget
		    }
		    fIn.close();

		    System.out.println("Nugget sending... Someone Set Us Up The Bomb");
		}
	    catch (IOException e)
		{
		    e.printStackTrace();
		}
	    
	    try {
		con.receive(buf);  //wait for the empty packet from the server that signals receipt of the nugget
	    } catch (IOException e) {
		System.out.println("conneciton closed");
	    }
	    
	    if(con != null)
		con.close();

	} catch (IOException e) {
	    e.printStackTrace();
	}
	
    }

}
