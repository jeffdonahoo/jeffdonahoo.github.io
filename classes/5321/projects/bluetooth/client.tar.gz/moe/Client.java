/* -*- mode: java; c-basic-indent: 3; indent-tabs-mode: t -*- */

import javax.bluetooth.*;
import com.rococosoft.impronto.util.*;
//import com.rococosoft.impronto.util.swing.SDPTree;
import javax.microedition.io.*;
import com.rococosoft.impronto.util.BluetoothConstants;
import java.io.*;
import java.util.*;
import java.security.*;

public class Client
{
    public static void main(String[] args)
    {
	Discovery foo = new Discovery();
	foo.findNuggets();
    }

}
