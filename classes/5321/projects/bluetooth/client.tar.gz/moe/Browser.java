/* -*- mode: java; c-basic-indent: 3; indent-tabs-mode: t -*- */

import javax.bluetooth.*;
import com.rococosoft.impronto.util.*;
//import com.rococosoft.impronto.util.swing.SDPTree;
import javax.microedition.io.*;
import com.rococosoft.impronto.util.BluetoothConstants;
import java.io.*;

public class Browser
{
    private static LocalDevice me;
    private final static UUID uuid = UUIDUtil.generateUUID("nuggets");

    public static void main(String[] args) throws Exception
    {
	me = LocalDevice.getLocalDevice();
	System.out.println(uuid);
	
	L2CAPConnectionNotifier service = null;
	L2CAPConnection con = null;
	String serviceURL = "btl2cap://localhost:"+uuid.toString()+
                ";ReceiveMTU=512;TransmitMTU=512;name=nuggets";

	
	try {
	    /*
	     * Creates an SPP service record.
	     */
	    System.out.println("argh");
	    System.out.println(serviceURL);
	    service = (L2CAPConnectionNotifier)Connector.open(serviceURL);
            ServiceRecord rec = LocalDevice.getLocalDevice().getRecord(service);
            
	    //LocalDevice.getLocalDevice().updateRecord(rec);
	    System.out.println(rec);
	    //Thread.sleep(30000);
	    /*
	     * Add the service record to the SDDB and
	     * accept a client connection.
	     */
	    System.out.println("hello");
	    	    con = (L2CAPConnection)(service.acceptAndOpen());
	    //	    is = con.openInputStream();
	    //	    is.close();
	    System.out.println("hello");
	    /*
	     * Close connection.
	     */
	    if(con != null)
		con.close();
	    /*
	     * Remove service record from the SDDB.
	     * Stop accepting connections.
	     */
	    service.close();
	    System.out.println("yay");
	} catch (IOException e) {
	    e.printStackTrace();
	}
	
    }
}
