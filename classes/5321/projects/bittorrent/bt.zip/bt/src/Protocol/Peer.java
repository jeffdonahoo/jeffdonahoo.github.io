package Protocol;

import java.net.Socket;
import Utilities.trackStruct;
import java.util.Set;
import java.util.TreeSet;
import java.io.UnsupportedEncodingException;
import java.net.UnknownHostException;
import java.io.IOException;
import java.util.Random;
import Utilities.Constants;



/**
 *
 * <p>Title: Peer.java </p>
 * <p>Description: This describes the interaction between the client and the peer
 * </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company:Baylor Univ </p>
 * @author not attributable
 * @version 1.0
 */


public class Peer implements Runnable
{
  private Socket aSocket = null;
  private Client aClient;
  private trackStruct myTS;
  private boolean CHOKED=true;
  private boolean INTERESTING;
  private boolean bitFieldGot = false;
  private torrentProcess myTorrentProcess = null;
  private ListenerThread lT;
  private Set myPiecesSet;
  private Thread th;
  private boolean threadFlag=false;
  /**
   * toString method which returns the peer details
   * @return String
   */
  public String toString()
  {
    return myTS.toString();
  }
  private void setThreadFlag(boolean val)
  {
    threadFlag=val;
  }
  /**
   * This is the default constructor which generates the c
   * @param aTorrentProcess torrentProcess
   * @param tS trackStruct
   */
  public Peer(torrentProcess aTorrentProcess, trackStruct tS) {

    myTorrentProcess = aTorrentProcess;
    aClient = new Client();
    myTS = tS;
    myPiecesSet = new TreeSet();



  }
  /**
   * This function sets the choking flag to true
   * @param flag boolean
   */

  public void setChoking(boolean flag) {
    CHOKED = flag;
  }

  /**
   * This fumction checks if the bit field is got
   * @return boolean
   */

  public boolean isBitFieldGot(){
    return bitFieldGot;
  }

  /**
   * This function checks if the client is unchoked
   * @return boolean
   */

  public boolean isUnchoked()
  {
    if(CHOKED == false)
      return true;
    return false;
  }

  /**
   * This function sets the client to the unchoked state
   */
  public void setUnChoked()
  {
    CHOKED=false;
  }

  /**
   * This function returns the set of pieces downloaded from this peer
   * @return Set
   */
  public Set getPiecesSet() {
    return myPiecesSet;
  }

  /**
   * This function sets the bits for the piece and inserts the piece in the set
   * @param pieceIndex int
   * @param piece byte[]
   */

 public void downloadedPiece( int pieceIndex, byte[] piece)
 {

//System.out.println("Downloaded piece "+ pieceIndex+ " by "+ this.toString());

//set the bit
   myTorrentProcess.setBitAt(pieceIndex);
   myTorrentProcess.setDownLoaded();
//add the piece
  Piece tempPiece = new Piece(pieceIndex, piece);
  myPiecesSet.add(tempPiece);

 }
  public void setInteresting(boolean flag){
  INTERESTING = flag;
}
/**
 * get the choked status of the client with this peer
 * @return boolean
 */


public boolean getChokedStatus(){
  return(CHOKED);
}
/**
 * get the interested status of the client with this peer
 * @return boolean
 */

public boolean getInterestStatus(){
return(INTERESTING);
}
/**
 *set the bit field got of the client with this peer
 */
public void setBitFieldGot()
{
  bitFieldGot=true;
}
/**
 * returns the socket for this connection
 * @return Socket
 */
 public Socket getSocket()
  {
    return aSocket;
  }
  /**
   * returns the parent torrent process
   * @return torrentProcess
   */
  public torrentProcess getTorrentProcess() {
    return myTorrentProcess;
  }
  /**
   * Thread's run function
   */
  public void run()
  {

    peerCycle();

  }

  /**
   * Cycle for the client and peer to download the pieces
   */
  public void peerCycle()
  {
      try {

      //create the socket appropriately
          int sPort = Integer.parseInt(myTS.peerPort);

          aSocket = aClient.ConnectToPeer(myTS.peerIP, sPort);

          //IF a socket is created
          if (aSocket != null)
          {

            //do handshagke
            boolean hS = false;
            hS = MessageImpl.doHandShake(aSocket,this.myTS.peerID);
            //If handShake is successful

            if (hS == true)
            {
              //set the Listener thread
              lT=new ListenerThread(this);
              th=new Thread(lT);
              th.start();

              //wait till the3 bit field is got
              while(isBitFieldGot()==false)
              {

              }



              //send an unchoke to the peer
              hS=MessageDefns.sendUnChoke(aSocket);

              //wait till the unchoked is got
              while(isUnchoked()==false)
              {

              }


              //send am interesting message
              hS=MessageDefns.sendInterested(aSocket);

              //send the keep alive
              hS = MessageImpl.doKeepAlive(aSocket);


            //get the id as described by the getREqID
            int n;
             n=getReqID();
             if(n > -1)
             {
               do
               {

                 //se the pieceindex
                 lT.setPieceIndex(n);

                 int length = 8192;
                 //loop and download...deal last piece separately
                 if (n == FileInfo.numberOfPieces - 1)
                 {

                   int offset = 0;
                   int lastPieceLength = FileInfo.lastPieceLength;
                   //reques all the pieces except the last

                   while ( (offset + length) < lastPieceLength) {

                     hS = MessageDefns.sendRequestMessage(aSocket, n, offset,
                         length);
                     offset = offset + length;

                   }
                   //does a request message for the last piece
                   hS = MessageDefns.sendRequestMessage(aSocket, n, offset,
                       lastPieceLength - offset);
                 }
                 else {
                  // System.out.println("Requesting piece" + n + " by " +this.toString());
                   for (int i = 0; i < FileInfo.pieceLength / length; i++) {

                     hS = MessageDefns.sendRequestMessage(aSocket, n, i * length,
                         length);

                   }
                 }

                 //loop and wait until n is downloaded
                 while(myTorrentProcess.isBitSetAt(n)==false);
                 n=getReqID();
                 MessageDefns.sendKeepAlive(aSocket);

               }
               while (n > -1);

             }



             //stop the thread amd close the socket
              setThreadFlag(true);
              th.suspend();
              aClient.closeSocket(aSocket);


           }
           else
           {
             setThreadFlag(true);
              th.suspend();
              aClient.closeSocket(aSocket);


           }
          }

        }

        catch (UnknownHostException e) {
          System.out.println("Don't know about host:");
        }

        catch (IOException e) {
          System.out.println("Couldn't get I/O for the connection to: "); ;
        }
        catch (Exception e)
        {
          System.out.println(e.toString() + "error at client");
        }
     }
      /**
       * get the value of the thread flag
       * @return
       */
      public boolean getThreadFlag()
      {
        return threadFlag;
      }
      /**
       * finalize function
       */
      protected void finalize()
      {
        setThreadFlag(true);
        aClient.closeSocket(aSocket);
      }

      /**
       * This computes the requested id by interacting with the torrentprocess and
       * checking if the one that has not been downloaded by the torrent process
       * is downloaded by this one
       * @return int
       */
  public int getReqID()
{
//    System.out.println("Getting ID from "+ this.toString());
    boolean flag=false;
    while(flag==false)
    {
      if(lT.isBitAvailable()==true && myTorrentProcess.isBitAvailable()==true)
      {
      int pid = 0;

      //first get a random integer from  0 to no of pieces -1
      Random myRandom = new Random(System.currentTimeMillis());

      int anInt = myRandom.nextInt();


      if(anInt < 0)
        anInt=-anInt;
      //take the mod to get it within the no of pieces
      anInt = anInt % FileInfo.numberOfPieces;


      //check if it is avaialbe from hte peer
     if (lT.isSetBit(anInt) == true)
      {
        //check if the bit is set in teh torrent
        if (myTorrentProcess.isBitSetAt(anInt) == true) {
          //if so mark it closed in peer
          lT.setBitFalse(anInt);

        }
        else {
          //else retimr

          return anInt;

        }
      }
    }
    else
    {

        flag=true;
    }

    }


//-1 to indicate no more needed from this peer


  return -1;
}

}


