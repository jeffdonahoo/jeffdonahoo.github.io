package Protocol;

import java.net.Socket;
import java.io.IOException;
import java.net.UnknownHostException;
/**
 *
 * <p>Title: Client </p>
 * <p>Description: Utility functions like connecting to a Peer and closing socket</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: CSI5321 </p>
 * @author Firasath Riyaz
 * Modified By Arun Chokkalingam
 * @version 1.0
 */

public class Client
{

  /**
   * Closes an already opened socket
   * @param soc Socket
   */
  public static void closeSocket(Socket soc)
  {
    try {
      if(soc.isClosed()==false)
        soc.close();
    }
    catch (IOException ex) {
       System.out.println("Closing socket at client :"+ex.toString());
    }
  }
  /**
   * Connects to a remote a Peer and returns the socket
   * @param peerIP String
   * @param port int
   * @throws UnknownHostException
   * @throws IOException
   * @return Socket
   */
  public static Socket ConnectToPeer(String peerIP, int port) throws
     UnknownHostException, IOException
 {

   Socket socket = null ;

   // Connect to Peer
       try {


           socket = new Socket(peerIP, port);

       }
       catch (UnknownHostException e)
       {
           System.out.println("Catch while connecting to the peer " + peerIP + e);
       }
       catch (Exception e)
       {
           System.out.println("caught at client " + peerIP + e);
       }

  return socket;
 }

}
