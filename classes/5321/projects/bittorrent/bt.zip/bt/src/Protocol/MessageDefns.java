package Protocol;

import java.net.Socket;
import Utilities.Constants;


/**
 *
 * <p>Title:MessageDefns.java </p>
 * <p>Description: This does the sends of the messages by calling the appropriate message send functions</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Baylor University </p>
 * @author CSI 5321
 * @version 1.0
 */
public class MessageDefns
{
   /**
   * This function sends a keep alive message on the socket.Returns true if successful.
   * @param s Socket
   * @return boolean
   */

  public static boolean sendKeepAlive(Socket s)
  {

    return MessageSend.msgLenOnly(s,(Constants.keepAliveLen));
  }
  /**
   * This function sends an interested message on the socket.Returns true if successful.
   * @param s Socket
   * @return boolean
   */

public static boolean sendInterested(Socket s)
{
  return MessageSend.msgLenID(s, Constants.interestedLen,
                              Constants.interestedID);
}
/**
 * This function sends a request message.Returns true if successful.
 * @param s Socket
 * @param ind int
 * @param begin int
 * @param length int
 * @return boolean
 */
  public static boolean sendRequestMessage(Socket s,int ind,int begin, int length) {

    return MessageSend.msgLenIDPayLoadThree(s,Constants.requestLen,
                                            Constants.requestID,ind,begin,length);


  }

  /**
   * This function sends an unchoke message. Returns true if successful
   * @param s Socket
   * @return boolean
   */
  public static boolean sendUnChoke(Socket s)
{
  return MessageSend.msgLenID(s, Constants.unchokeLen,
                              Constants.unchokeID);
}




}
