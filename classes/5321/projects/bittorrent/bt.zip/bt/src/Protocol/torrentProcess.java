package Protocol;

import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.TreeSet;
import Utilities.trackStruct;
import Utilities.Functions;
import java.util.Set;
import java.util.Iterator;
import java.io.File;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.Object;
import Servelet.TrackerInteract;
import Utilities.Constants;
import java.io.DataOutputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.net.UnknownHostException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import javax.swing.JFrame;
import java.awt.FileDialog;


/**
 *
 * <p>Title: torrentProcess.java</p>
* <p>Description: This class contains the overall processing of the torrent. A list of peers
is passed and the process is done
</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Baylor University</p>
 * @author CSI 5321
 * @version 1.0
 */

public class torrentProcess {

  //maintain a list of client vectors
  private ArrayList peerList;

  private ArrayList torrentPeerList;
  private int[] MamaBitField;

  private Map PieceMap;



  private TrackerInteract myTI;

  /**
   * default constructor
   */
  public torrentProcess(TrackerInteract tI)
  {


    myTI=tI;

    peerList = new ArrayList();
    System.out.println("No of pieces to download "+FileInfo.numberOfPieces);
    MamaBitField=new int[FileInfo.numberOfPieces];
    PieceMap = new HashMap();
  }
  /**
   * checks if bit is set at position a of the bit set
   * @param a int
   * @return boolean
   */
  public boolean isBitSetAt(int a)
  {
    boolean flag=true;
    if(MamaBitField[a]==1)
    {
      return true;
    }
    else
      return false;

  }
  /**
   * sets the bit at position a of the bit set
   * @param a int
   * @return boolean
   */
  public boolean setBitAt(int a)
  {
    if(MamaBitField[a]==0)
      {
        MamaBitField[a] = 1;
        return true;
      }
      else
        return false;
  }
  /**
   * turns the bit off at position a
   * @param a int
   */
  public void turnBitOffAt(int a)
  {
        MamaBitField[a] = 0;


  }
  /**
   * does the Bittorrent protocol for downloading
   * @param v Vector
   * @throws NumberFormatException
   * @throws UnknownHostException
   * @throws IOException
   */
  public void doProtocol(ArrayList v) throws IOException {

    //choose all the ipAdresses in a random order
    TreeSet alreadyChosen=new TreeSet();
    int maxSize=v.size();

    //initialize the vector of bitfields
    for(int i=0; i < FileInfo.numberOfPieces ; i++)
    {
      MamaBitField[i]=0;
    }



    for(int i=0;i<maxSize;i++)
    {


          trackStruct tS=(trackStruct)v.get(i);
    //      System.out.println("Peerchk  " +i+" "+ tS.toString());
          //block my own
          if(tS.getIP().equals(Functions.getHostName())==false ||
             tS.getPort().equals(new String(new Integer(Constants.portNumber).toString()))==false)
          {
            //get the vector at that position
            trackStruct peerDetails = (trackStruct) v.get(i);

            //start thee peers concurrently
            Peer newPeer = new Peer(this,peerDetails);
            peerList.add(newPeer);
            //System.out.println(newPeer.toString());
            new Thread(newPeer).start();
          }


    }


//wait till all the pieces are downloaed
   while(isBitAvailable()==true) {

   };

   //System.out.println( " Hey i am out " );
   setDownLoaded();

    //now loop through all the peers and get the pieces

    for(int i=0;i<peerList.size();i++)
    {
      Peer tmpPeer=(Peer)peerList.get(i);
     //get the downloaded set of a peer
      Set pSet= (Set) tmpPeer.getPiecesSet();

      Iterator myIter=pSet.iterator();
      //iterate thro hte pieces
      while(myIter.hasNext())
      {

        //add them to a mapc.torr
        Piece tmpPiece=(Piece)myIter.next();
        PieceMap.put(new Integer(tmpPiece.getPId()),tmpPiece.getPiece());
      }
    }

    FileInfo.fileMap=PieceMap;

    //Write to a file ..by choosing from a dialog box


     JFrame saveFrame=new JFrame();
     saveFrame.show();
     saveFrame.setVisible(true);
     FileDialog saveDialog=new FileDialog(saveFrame,"Save File as",FileDialog.SAVE);
     saveDialog.setFile(FileInfo.fileName);
     saveDialog.show();
     String saveFile=saveDialog.getDirectory()+saveDialog.getFile();
     saveFrame.pack();
     saveFrame.dispose();
     java.io.DataOutputStream outSte = new java.io.DataOutputStream(new
     BufferedOutputStream(new FileOutputStream(saveFile)));
    // fileOut.writeTo(outSte);
       for(int i=0;i<PieceMap.size();i++)
       {
         Integer pInd=new Integer(i);


         byte[] aPFull=((byte[])PieceMap.get(pInd));

          outSte.write(aPFull);

       }
       outSte.flush();
       outSte.close();



       FileInfo.bitField=MamaBitField;
       FileInfo.download=(long)FileInfo.length;
       FileInfo.left=0;
       FileInfo.completed=true;
      myTI.trackerCompStopped(FileInfo.announceURL, FileInfo.TrackerInfoHash,Constants.completedEvent);









  }
  /**
   * checks if any piece has to be downloaded
   * @return boolean
   */

  public void setDownLoaded() {
    long down = 0;
    System.out.print("----> downloaded 1" );
    for(int i=0;i<FileInfo.numberOfPieces-1;i++)
   {
     // System.out.print(MamaBitField[i]);
     if(MamaBitField[i]==1)
     {
       down += FileInfo.pieceLength;
     }
   }
   //System.out.println(MamaBitField[FileInfo.numberOfPieces-1]);
   down += MamaBitField[FileInfo.numberOfPieces-1]*FileInfo.lastPieceLength;
   FileInfo.download = down;
   FileInfo.left = (long)(FileInfo.length - (double)FileInfo.download);
  }
  public boolean isBitAvailable()
 {
   boolean flag=false;
   for(int i=0;i<FileInfo.numberOfPieces;i++)
   {
     if(MamaBitField[i]==0)
     {
       return true;
     }
   }
     return false;
 }




}
