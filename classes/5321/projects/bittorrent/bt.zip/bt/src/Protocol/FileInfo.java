package Protocol;

import java.util.Map;
import Utilities.Constants;
/**
 *
 * <p>Title:FileInfo </p>
 * <p>Description:This holds the details of the file that is being downl. </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Baylor University </p>
 * @author CSI 5321
 * @version 1.0
 */

public class FileInfo {
  //Single File info directory fileds
 public static String fileName;
//  public static String fileName;
 public static double length;
 //Piece Length read from the meta file and the other details
 public static int pieceLength;
 public static String pieces;
 public static int numberOfPieces;
 public static int lastPieceLength;

 public static String myId;
 public static String myInfoHash;
 public static String TrackerInfoHash;
 public static String trackerIP;

 public static String announceURL;

 public static boolean idSetFlag=false;
 public static long upload=0;
 public static long download=0;
 public static long left=0;

 public static int bitField[];
 public static Map fileMap;
 public static boolean completed =false;
 public static String torrentFileName;
// privat

 public static String dir="" ;
 /**
  * Takes the decodedMap of the Torrent File and intializes the values
  * @param decodedFileMap Map
  */
  public static void updateInfo(Map decodedFileMap) {
   Map tempInfoMap = (Map)decodedFileMap.get(Constants.INFO_KEY );
   fileName = (String)tempInfoMap.get(Constants.FILE_NAME_KEY);
   length = Double.parseDouble(tempInfoMap.get(Constants.LENGTH_KEY).toString());
   pieceLength = Integer.parseInt(tempInfoMap.get(Constants.PIECE_LENGTH_KEY ).toString());
   pieces = (String)tempInfoMap.get(Constants.PIECES_KEY);

   numberOfPieces = (int)Math.ceil((double )length / pieceLength);
   lastPieceLength = (int) (length - ( (numberOfPieces - 1) * pieceLength));
 }

}
