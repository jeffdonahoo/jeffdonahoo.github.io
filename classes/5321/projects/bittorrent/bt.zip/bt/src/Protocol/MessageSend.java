package Protocol;

import java.net.Socket;
import java.io.IOException;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.util.Arrays;
import Utilities.Functions;


/**
 *
 * <p>Title: MessageSend</p>
 * <p>Description:Handler for messages to send  </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company:Baylor University </p>
 * @author CSI 5321
 * @version 1.0
 */

public class MessageSend {


  /**
   * This does the handshake function. Returns true if successful.
   * @param socket Socket
   * @param peerID String
   * @param info_hash String
   * @throws IOException
   * @throws InterruptedException
   * @return boolean
   */

  public static boolean HandShake(Socket socket, String peerID,String info_hash, String theOtherPeer) throws
      IOException, InterruptedException
  {



  byte[]  reservedBytes = new byte[8];


  // Acquire the input and output streams
  //DataOutputStream outbound = new DataOutputStream(socket.getOutputStream() );
  //BufferedReader inbound = null;
  DataInputStream in = null;
  DataOutputStream out = null;
  try {


   in = new DataInputStream ( new BufferedInputStream(socket.getInputStream()));

 } catch(Exception e) {

    System.out.println("Caught while creating InputStream " + e.toString() );
return false;
  }


  try {


    out = new DataOutputStream ( new BufferedOutputStream(socket.getOutputStream()));
  }
  catch(Exception e) {

    System.out.println("Caught while creating OutputStream " + e.toString() );
return false;
  }

//wrtie the protocol and its length
  String protocol = "BitTorrent protocol";
  out.write(19);
  out.write("BitTorrent protocol".getBytes());
  //write the infohash,peerid and othere details
  out.write(reservedBytes);
  out.write( info_hash.getBytes());
  out.write(peerID.getBytes());
  out.flush();

  //read the length and check for bittorrent

  byte ef = in.readByte();
  if (ef != 19)
       throw new IOException("Handshake failure : Protocol length MisMatch");
     byte[] bs = new byte[19];
     in.read(bs);
     String bittorrentProtocol = new String(bs, "UTF-8");
     if (!"BitTorrent protocol".equals(bittorrentProtocol))
       throw new IOException("Handshake failure, expected "
                             + "'Bittorrent protocol', got '"
                             + bittorrentProtocol + "'");

     //read the reserved bytes
     in.readFully(reservedBytes);
     byte[] bs1 = new byte[20];
     bs = new byte[20];

     //read and validate the infohash
     in.read(bs1);
     if (!Arrays.equals(info_hash.getBytes(), bs1))
       throw new IOException("Unexpected MetaInfo hash");

     in.read(bs);
     String opID=Functions.convertBytesToString(bs);


     if(opID.equals(theOtherPeer)==false)
       return false;
return true;
}
   /**
    * Function that will send a message only with the length . Returns true if successful.
    * @param socket Socket
    * @param len int
    * @return boolean
    */

   public static boolean msgLenOnly(Socket socket,int len)
   {
     boolean flag=false;
       // Acquire  output streams
      DataOutputStream out = null;
     try
     {

      out = new DataOutputStream ( new BufferedOutputStream(socket.getOutputStream()));
     }
     catch(Exception e)
     {

       System.out.println("Caught while creating OutputStream " + e.toString() );
       return false;
     }


     ///write the length
     try
     {

       out.writeInt(len);
       out.flush();
     }
     catch (IOException ex)
     {

       System.out.println("Caught in client during keep alive" + ex.toString() );
       return false;
     }



     return true;
   }
   /**
    * Function that will send a message only with the length and ID. Returns true if successful.
    * @param socket Socket
    * @param len int
    * @param ID byte
    * @return boolean
    */
   public static boolean msgLenID(Socket socket,int len,byte ID)
   {
     boolean flag=false;
     // Acquire  output streams
      DataOutputStream out = null;
     try
     {

      out = new DataOutputStream ( new BufferedOutputStream(socket.getOutputStream()));
     }
     catch(Exception e)
     {

       System.out.println("Caught while creating OutputStream " + e.toString() );
       return false;
     }



//write the len n Id
     try
     {
      out.writeInt(len);
      out.writeByte(ID);
      out.flush();
     }
     catch (IOException ex)
     {

       System.out.println("Caught in client during keep alive" + ex.toString() );
       return false;
     }

     return true;
   }

   /**
    * Function that will send a message only with the length and ID and payload. Returns true if successful.
    * @param socket Socket
    * @param len int
    * @param ID byte
    * @param payLoad int
    * @return boolean
    */

     public static boolean msgLenIDPayLoad(Socket socket, int len,byte ID,int payLoad)
     {
       boolean flag=false;
        //acquire output stream
        DataOutputStream out = null;
       try
       {

        out = new DataOutputStream ( new BufferedOutputStream(socket.getOutputStream()));
       }
       catch(Exception e)
       {

         System.out.println("Caught while creating OutputStream " + e.toString() );
         return false;
       }



     //write int ,bytea n payload
       try
       {
         out.writeInt(len);
         out.writeByte(ID);
         out.write(payLoad);
         out.flush();
       }
       catch (IOException ex)
       {

         System.out.println("Caught in client during keep alive" + ex.toString() );
         return false;
       }


       return true;
     }
     /**
      * Function that will send a message only with the length and ID. Returns true if successful.
      * @param socket Socket
      * @param len int
      * @param ID byte
      * @param payLoad1 int
      * @param payLoad2 int
      * @param payLoad3 int
      * @return boolean
      */

    public static boolean msgLenIDPayLoadThree(Socket socket, int len, byte ID,int payLoad1, int payLoad2, int payLoad3)
         {
           boolean flag=false;
             // Acquire the input stream
            DataOutputStream out = null;
           try
           {

            out = new DataOutputStream ( new BufferedOutputStream(socket.getOutputStream()));
           }
           catch(Exception e)
           {

             System.out.println("Caught while creating OutputStream " + e.toString() );
             return false;
           }



           //writes the len,id,and the payloads
           try
           {
             out.writeInt(len);
             out.writeByte(ID);
             out.writeInt(payLoad1);
             out.writeInt(payLoad2);
             out.writeInt(payLoad3);
             out.flush();
           }
           catch (IOException ex)
           {

             System.out.println("Caught in client during keep alive" + ex.toString() );
             return false;
           }



           return true;
         }

         /**
          *  Function that will send a piece in the form len,id,payload 1,payload2 amd payload3. Returns true if successful.
          * @param socket Socket
          * @param len int
          * @param ID byte
          * @param payLoad1 int
          * @param payLoad2 int
          * @param payLoad3 byte[]
          * @return boolean
          */

         public static boolean msgLenIDPiecePayLoad(Socket socket, int len,byte  ID,int payLoad1,int payLoad2, byte[] payLoad3)
                {
                  boolean flag=false;
                    // Acquire the o/p stream
                   DataOutputStream out = null;

                  try
                  {

                   out = new DataOutputStream ( new BufferedOutputStream(socket.getOutputStream()));
                  }
                  catch(Exception e)
                  {

                    System.out.println("Caught while creating OutputStream " + e.toString() );
                    return false;
                  }



                  //wrie the len,id and payloads
                  try
                  {
                    out.writeInt(len);
                    out.writeByte(ID);
                    out.writeInt(payLoad1);
                    out.writeInt(payLoad2);
                    out.write(payLoad3);
                    out.flush();
                  }
                  catch (IOException ex)
                  {

                    System.out.println("Caught in client during keep alive" + ex.toString() );
                    return false;
                  }


                  return true;
                }



       }

