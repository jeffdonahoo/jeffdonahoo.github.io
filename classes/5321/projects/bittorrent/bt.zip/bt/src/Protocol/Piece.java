package Protocol;


import java.io.*;
/**
 *
 * <p>Title: Piece.java</p>
 * <p>Description:Description of a piece </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Baylor Universtiy</p>
 * @author CSI 5321
 * @version 1.0
 */
public class Piece implements Comparable, java.io.Serializable{
  private int myPieceIndex;
  private byte[] myPiece;
  /**
   * Constructor to construct with piece index and piece
   * @param aPieceIndex int
   * @param aPiece String
   */
  public Piece(int aPieceIndex, byte[] aPiece)
  {

    myPiece=aPiece;
    myPieceIndex = aPieceIndex;

  }
  /**
   * compare to on piece index
   * @param anObject Object
   * @return int
   */
  public int compareTo( Object anObject)
  {
    Piece tempPiece = (Piece)anObject;
    return ( myPieceIndex - tempPiece.myPieceIndex);

  }
  /**
   * get the piece id
   * @return int
   */
  public int getPId()
  {
    return myPieceIndex;
  }
  /**
   * get the piece
   * @return String
   */

  public byte[] getPiece()
  {
    return myPiece;
  }
  /**
   * toString returns the piece and piece index
   * @return String
   */
  public String toString()
  {

    return "\n\n" + myPieceIndex +" -> " + myPiece;
  }

}
