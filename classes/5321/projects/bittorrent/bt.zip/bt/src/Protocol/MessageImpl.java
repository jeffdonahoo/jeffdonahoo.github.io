package Protocol;

import java.net.Socket;
import java.io.IOException;


/**
 *
 * <p>Title:MessageImpl </p>
 * <p>Description: This implements the messages to send </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
public class MessageImpl {
  public MessageImpl() {
  }
  /**
   * Implements handshake and takes care of exceptions. Returns true if successful.
   * @param aSocket Socket
   * @return boolean
   */
  public static boolean doHandShake(Socket aSocket,String theOtherPeer)
 {
   boolean hS;
   try
     {
       //call the message send's handshake
       hS = MessageSend.HandShake(aSocket, FileInfo.myId, FileInfo.myInfoHash,theOtherPeer);

     }
     //catch texceptions
     catch (InterruptedException ex)
     {
       System.out.println("Bad Handshake " + ex.toString());
       hS = false;
     }
     catch (IOException ex) {
       System.out.println("Bad Handshake" + ex.toString());
       hS = false;
     }   catch (Exception ex)
     {
       System.out.println("Bad Handshake" + ex.toString());
       hS = false;
     }

     return hS;

 }
 /**
  *  This takes care of the keep alive. Returns true if successful
  * @param aSocket Socket
  * @return boolean
  */
 public static boolean doKeepAlive(Socket aSocket)
 {
   boolean ka=true;
   try
   {
          ka= MessageDefns.sendKeepAlive(aSocket);
    }
    catch (Exception e)
    {
      System.out.println("Caught at torrent PRoceess doing keepAlive" +
                              e.toString() + " sock value " +aSocket.toString());
       ka=false;
   }
   return ka;

 }





}
