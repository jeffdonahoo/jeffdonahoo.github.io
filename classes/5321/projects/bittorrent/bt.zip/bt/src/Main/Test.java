package Main;


import java.io.IOException;


/**
 *
 * <p>Title: TESTING Class for the BitTorrent</p>
 * <p>Description: The execution of the BitTorrent Client starts here</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: CSI5321</p>
 * @author Arun/Firasath
 * @version 1.0
 */

public class Test
{

  /**
   * <p> Description: Execution starts here </p>
   * @param args String[]
   * @throws IOException
   */
  public static void main (String args[])
  {
    try
    {




      Communicator c= new Communicator();
      c.Communicate();
    }
    catch(Exception e)
    {
      System.out.println("Error caught in main"+e.toString());
    }

  }



}



