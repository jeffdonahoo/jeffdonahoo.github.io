package Main;

///import javax.swing.ProgressMonitor;
import javax.swing.JFrame;
import Protocol.FileInfo;
import javax.swing.JProgressBar;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import Utilities.Constants;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class MyProgressBar implements Runnable{
  private static JFrame frame;
  public MyProgressBar(JFrame aFrame) {
      frame = aFrame;
  }
  public void run()
          {
          /*  try {



              ProgressMonitor pm = new ProgressMonitor(frame, "DownLoading...", "fff",
                                                       0, 100);

              pm.setMillisToDecideToPopup(0);

              int Progress = 0;
              double fraction;

              fraction = ( (double) FileInfo.download) / FileInfo.length;
              Progress = (int ) (fraction * 100);
            while( Progress < 100) {


                pm.setNote("DownLoading"+ Integer.toString(Progress));
                fraction = ((double)FileInfo.download) / FileInfo.length;

                Progress = (int ) (fraction * 100);



                  pm.setProgress(Progress);


              }


              pm.close();
            }
            catch(Exception ex) {
            System.out.println("Caught while starting the progress bar" + ex.toString() );
            }
*/
          }

}