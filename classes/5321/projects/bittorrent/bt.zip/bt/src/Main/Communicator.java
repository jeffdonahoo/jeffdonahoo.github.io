package Main;

import java.util.Map;
import Utilities.MetaInfoSTSF;
import Utilities.Constants;
import java.io.*;
import Protocol.FileInfo;
import Utilities.InfoHash;
import java.net.URLEncoder;
import java.net.URLDecoder;
import Servelet.TrackerInteract;
import java.util.ArrayList;
import Protocol.torrentProcess;
import java.net.UnknownHostException;
import java.net.MalformedURLException;
import Utilities.Functions;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.FileDialog;
import Server.MainServer;
import javax.swing.ProgressMonitor;
import javax.swing.JTextField;


public class Communicator
{
  private static JFrame frame;
public TrackerInteract myTI;
  public void Communicator()
  {
     TrackerInteract myTI=new TrackerInteract();
  }
public void Communicate()
{

    //first start the server
 /*   MainServer myServer = new MainServer();
    new Thread(myServer).start();

*/
    /*Decode the torrent file */


    //1. Optional: Specify who draws the window decorations.
    JFrame.setDefaultLookAndFeelDecorated(true);

//2. Create the frame.
    frame = new JFrame("BaylorTorrent");

    //3. Doesnt close when x is pressed so that we close after sending close
    //to the tracker
    frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

    frame.getContentPane().setLayout(null);

//4. Create components and put them in the frame.


    //first define the torrent file dialog
    JLabel torFileLabel=new JLabel("Choose the torrent File");
    frame.getContentPane().add(torFileLabel);
   torFileLabel.setBounds(Constants.startX+Constants.nextCol,Constants.startY+Constants.nextRow,
25*Constants.nextCol, (5*Constants.nextRow));

    JButton torFileButton=new JButton("Open Torrent File");
    torFileButton.addActionListener(new ActionListener()
    {

      public void actionPerformed(ActionEvent actionEvent)
      {
        if(actionEvent.getActionCommand().toString().equals("Open Torrent File"))
        {
            FileDialog tFD = new FileDialog(frame,"Choose torrent File",FileDialog.LOAD);
            tFD.show();
            FileInfo.torrentFileName=tFD.getDirectory()+tFD.getFile();
            System.out.println(FileInfo.torrentFileName);
        }
      }
    })                        ;
    frame.getContentPane().add(torFileButton);
    int currStartX= Constants.startX+(22*Constants.nextCol);
    int currStartY= Constants.startY+(2*Constants.nextRow);
    torFileButton.setBounds(currStartX,currStartY,
(10*Constants.nextCol), currStartY+(1*Constants.nextRow));




//next define the save dialog
    JButton downLoadButton=new JButton("Download");

  frame.getContentPane().add(downLoadButton);
  downLoadButton.setBounds(Constants.startX+(5*Constants.nextCol),Constants.startY+(10*Constants.nextRow),
10*Constants.nextCol, (5*Constants.nextRow));


//define the action listener for the button
 downLoadButton.addActionListener(new ActionListener(){

  public void actionPerformed(ActionEvent actionEvent)
  {
    if(actionEvent.getActionCommand().toString().equals("Download"))
    {


      MyProgressBar myPBar = new MyProgressBar(frame);
      new Thread(myPBar).start();

      Map dMap = null;
      String file=FileInfo.torrentFileName;
      try
      {
        dMap = MetaInfoSTSF.getDecodedFile(file);
      }
      catch (IOException ex)
      {
        System.out.print(ex.toString() + "Caught in Communicator");
      }

      /* Initialize the Values */
      FileInfo.updateInfo(dMap);
      String info_hash = null;
      String deCodedInfo = null;

      try
      {
        /*Get the SHA1 of the info Hash */
        info_hash = InfoHash.getInfoHash(dMap);

        //assign the string to values
        //get the string back
        String infoHash2;
        String myURLEncoded = URLEncoder.encode(info_hash,Constants.BYTE_ENCODING);
        infoHash2=URLDecoder.decode(myURLEncoded);
        FileInfo.myInfoHash=infoHash2;


      }
      catch(Exception e )
      {
        System.out.println("Caught while creating SHA1 of info value " + e.toString());
      }

     /* Communicates with the tracker to get Peer Information*/

      String announceURL=new String(dMap.get("announce").toString() );

     //call the tracker with the announce url and the sha1 infohash and get the
     //list of peers


     FileInfo.announceURL=announceURL;

     FileInfo.TrackerInfoHash=info_hash;

     TrackerInteract myTI=new TrackerInteract();

      ArrayList peerList=null;
      try {
        peerList = myTI.getInfofromTracker(announceURL, info_hash);
     //   myTI.trackerCompleted(announceURL,info_hash);
      }
      catch (IOException ex1) {
        System.out.println("Caught while calling tracker Interact " +ex1.toString());
      }




       //create a torrent process and call its doProtocol method

       torrentProcess myTorrentProcess=new torrentProcess(myTI);

       try
      {
        //System.out.println("Starting the protocol");
        myTorrentProcess.doProtocol(peerList);
      }
      catch (IOException ex2) {
        System.out.println("Caught while calling torrent Process doProtocol " + ex2.toString());
      }

      }




    }



 });
 //frame.setVisible(true);

//next define the complete button
   JButton completeButton=new JButton("Close");

  frame.getContentPane().add(completeButton);
  completeButton.setBounds(Constants.startX+(20*Constants.nextCol),Constants.startY+(10*Constants.nextRow),
10*Constants.nextCol, (5*Constants.nextRow));

//define the action listener for the button
 completeButton.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent actionEvent) {
              TrackerInteract myTI=new TrackerInteract();
     if (actionEvent.getActionCommand().toString().equals("Close"))
     {
          try {

            myTI.trackerCompStopped(FileInfo.announceURL,
                                    FileInfo.TrackerInfoHash,
                                    Constants.stoppeddEvent);
            System.exit(0);
          }
          catch (IOException ex) {
          }
     }
   }
 });






///add progress bar





    frame.getContentPane().add(downLoadButton);


//5. Size the frame.
    frame.setBounds(Constants.startX,Constants.startY,Constants.endX,Constants.endY);

//6. Show it.
    frame.setVisible(true);
    frame.show();




//Send close //

}









}
