package Utilities;

import java.util.Map;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import BenCoder.Encoder;
import Protocol.FileInfo;
/**
 *
 * <p>Title: InfoHash </p>
 * <p>Description: Provides the methods for Calculating Hash of the info Value of the Torrent File </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: CSI5321</p>
 * @author Firasath Riyaz
 * @version 1.0
 */
public class InfoHash {

  /**
   * <p> Description: Takes a Map of the meta file and returns a Map containing only info Key-Value pairs </p>
   * @param metaFileMap obtained from the Torrent ( meta File )
   * @return tempInfoMap containing the "info" Key-Value pair
   *
   */

  private static Map createInfoMap ( Map metaFileMap ){

    return((Map)metaFileMap.get("info"));
  }
    /**
     * <p> Description: Takes a Map of info Key-Value pairs and B-encodes the info Key_Value pair</p>
     * @param  infoMap of info Key-value pair
     * @return aBencodedInfo
     *
     */


//This calls the bencoder's encoder and encodes the the infohash
  private static String getBencodedInfoMap ( Map infoMap ) throws IOException {
   //B-encode the info key value pair
   String aBencodedInfo = Encoder.encode(infoMap);

   return (aBencodedInfo);

 }


 /**
  * <p> Description: Calculates the SHA1 encoding on the infoMap </p>
  * @param metaFileMap Map
  * @throws IOException
  * @throws NoSuchAlgorithmException
  * @return String
  */

  //Get the Hash value for the bencoded value of the info key

  public static String getInfoHash(Map metaFileMap)  throws IOException,
  NoSuchAlgorithmException
  {


   Map infoMap = null;

   //Create a map with info key-value pair
    try {

      infoMap = InfoHash.createInfoMap(metaFileMap);
    }
    catch (Exception e ) {
      System.out.println("Caught while creating info Map " + e.toString());
    }



    //Bencode the info Map
    String bencodedInfoValue=null;
    try
    {

        //get the infoMap bencoded
        bencodedInfoValue = InfoHash.getBencodedInfoMap(infoMap);

    }
    catch (Exception e )
    {
      System.out.println("Caught while Bencoding info Map " + e.toString());
    }

   //Get an instance of the Sha1
    SHA12 mySHA12=new SHA12();
    //Get the becoded info Map


    //get the sha1 encoding of the bencoded info map
    mySHA12.init();
    mySHA12.updateASCII(bencodedInfoValue);
    mySHA12.finish();

    //Convert the hex string to Bytes
    byte[] myBits=Functions.convertHexStringToByte(mySHA12.digout());


                  //     String s11=Functions.ourStringFunc(myBits);

    //get the info sha1 string and return
    String newSha1Info = new String(myBits, Constants.BYTE_ENCODING);

    FileInfo.myInfoHash=newSha1Info;

    return newSha1Info;

  }

}
