package Utilities;

import java.util.Map;
import java.awt.Color;

/**
 *
 * <p>Title: Constants </p>
 * <p>Description: Contains the constants used in the BitTorrent  </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: CSI5321</p>
 * @author Jeff Donahoo
 * @version 1.2
 * Modified by : Firasath Riyaz
 */

public class Constants
{
   public static final String DEFAULT_ENCODING = "UTF8";
   public static final String BYTE_ENCODING = "ISO-8859-1";
   public static final String USASC_ENCODING = "US-ASCII";
   public static final String UTF16BE_ENCODING = "UTF-16BE";
   public static final String UTF16LE_ENCODING = "UTF-16LE";
   public static final String UTF16_ENCODING = "UTF-16";

  public static final String INFO_KEY = "info";
  public static final String LENGTH_KEY = "length"; //Length of the File
  public static final String FILE_NAME_KEY = "name";//Name of the File
  public static final String PIECE_LENGTH_KEY ="piece length";
  public static final String PIECES_KEY = "pieces";

 //Messgage defns follow
 //keep Alive
 public static final int keepAliveLen=0;

 //choke
 public static final int chokeLen = 1;
 public static final byte chokeID= 0;

 //unchoke
 public static final int unchokeLen = 1;
 public static final byte unchokeID = 1;

 //interested
 public static final int interestedLen=1;
 public static final byte interestedID=2;

 //not Interested
 public static final int notInterestedLen = 1;
 public static final byte notInterestedID = 3;

 //bitfield
 public static final int bitFieldLen = 1;
 public static final byte bitFieldID = 5;

 //request
 public static final int requestLen=13;
 public static final byte requestID=6;

 //piece
 public static final int pieceLen = 9;
 public static final byte pieceID = 7;

 //cancel
 public static final int cancelLen = 13;
 public static final byte cancelID = 8;

//********These variables are initialized once after/during download
 //set the listening port .. This might change if there is another BT client
 //listening on the same port
 public static int portNumber=6880;

 public static final int maxConnections=50;

public static final int myKey = 36077018;
 public static final int myCompact=1;

 public static final String completedEvent="completed";
 public static final String stoppeddEvent="stopped";

 public static final int startX=0;
 public static final int endX=450;
 public static final int startY=0;
 public static final int endY=350;

 public static final int nextRow=10;
 public static final int nextCol=10;

 public static final Color aColor = new Color(0,0,125);


}
