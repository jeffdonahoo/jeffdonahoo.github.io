package Utilities;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.File;
import java.util.Map;
import java.io.IOException;
import BenCoder.Decoder;
import java.util.HashMap;
import Protocol.FileInfo;

/**
 *
 * <p>Title: MetaFile Reader</p>
 * <p>Description: Reads a meta file or the torrent file and creates a Map of the information </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: CSI5321</p>
 * @author Arun Chokkalingam
 * @version 1.0
 */

public class MetaInfoSTSF {

  /**
   * <p> Description : convert a file to bufferedInputStream </p>
   * @param fileName String
   * @return BufferedInputStream
   */

  public static BufferedInputStream convertFileBIS(String fileName)
  {

    BufferedInputStream bis = null;
    try
    {
      File inputFile = new File(fileName);
      FileInputStream fis = new FileInputStream(inputFile);
      bis = new BufferedInputStream(fis);

    }
    catch(Exception e)
    {
      System.out.println("Error in Tracker File reading "+ e.toString());


    }

    return bis;


  }

  /**
   * <p> Description: Reads the Torrent file and creates a Map </p>
   * @param fileName String
   * @throws IOException
   * @return Map
   */

  //get a filename and get the map of the decoded string
  public static Map getDecodedFile(String fileName) throws IOException {

        BufferedInputStream bis=new BufferedInputStream(convertFileBIS(fileName));


        //Decode the torrent file
        Map decodedMap=Decoder.decode(bis);
        Map tempMap = new HashMap();

        //first get the announce
        String tempAnnounce = null;

         try
         {
           tempAnnounce = Functions.convertBytesToString(decodedMap.get("announce"));
         }
         catch(Exception e)
         {
           System.out.println("Caught while coding string " +e.toString());
         }

         //Get all the fields of the info directory  into a Map
        tempMap.put("announce", tempAnnounce );

        Map tempInfoMap = (Map) decodedMap.get("info");

        Map tempInfoMap2 = new HashMap();
        tempInfoMap2.put("piece length", tempInfoMap.get("piece length"));
        tempInfoMap2.put("length", tempInfoMap.get("length"));
        FileInfo.left=new Integer(tempInfoMap.get("length").toString()).intValue();
        tempInfoMap2.put("pieces", Functions.convertBytesToString(tempInfoMap.get("pieces")));
        tempInfoMap2.put("name", Functions.convertBytesToString(tempInfoMap.get("name")));

        tempMap.put("creation date", decodedMap.get("creation date"));
        tempMap.put("info", tempInfoMap2);
        //Return the Map
        return tempMap;
      }


}
