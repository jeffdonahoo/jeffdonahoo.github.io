package Utilities;


import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.net.URLDecoder;
import Protocol.FileInfo;

/**
 *
 * <p>Title:Utilities </p>
 * <p>Description: Contains the Utility functions like conversion of bytes to strings etc..</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: CSI5321</p>
 * @author Arun Chokkalingam
 * @version 1.0
 */
public class Functions {

  /**
   * Finds the IP address of the machine
   * @return String
   */
  //This returns the IpAddress of the System
  public static final String getHostName() {
    try {
      java.net.InetAddress MyIAdd = java.net.InetAddress.getLocalHost();
      return MyIAdd.getHostAddress();

    }
    catch (Exception e) {
      System.out.println("While getting ipaddress caught " + e.toString());
      return null;
    }
  }

  /**
   * Returns the port number that the client will listen to
   * @return String
   */
  public static final String getPortNumber() {
    String portNumber = new String(new Integer(Constants.portNumber).toString());
    return portNumber;
  }
  /**
   * returns the left value in constants as a String
   * @return
   */
  public static final String getLeft() {
  String le = new String(new Long(FileInfo.left).toString());
  return le;
}
/**
 * returns the uploaded value in constants as a String
 * @return
 */
public static final String getUploaded()
{
  String up = new String(new Long(FileInfo.upload).toString());
  return up;
}

public static final String getDownloaded()
{
  String down = new String(new Long(FileInfo.download).toString());
  return down;


}


  /**
   * COnverts the Bytes to String using the Byte Encoding
   * @param value Object
   * @return String
   */
  public static String convertBytesToString(Object value) {
    byte[] val = null;

    //Typeconvert the Object to Bytes
    try {
      val = (byte[]) value;
    }
    catch (Exception e) {
      val = value.toString().getBytes();

    }
    String myVal = null;

    //Convert the bytes to String using Byte Encoding
    try {
      myVal = new String(val, Constants.BYTE_ENCODING);
    }

    catch (Exception e) {
      System.out.println("Caught while codeing string " + e.toString());
    }
    //Return the string
    return myVal;
  }


  /**
   * URLEncode a given string and return it
   * @param s String
   * @return String
   */
  public static String doEncoding(String s) {
    try {
      return URLEncoder.encode(s, Constants.BYTE_ENCODING);
    }
    catch (UnsupportedEncodingException ex) {
      return null;
    }
  }
  /**
   * COnvert a string to ByteArray
   * @param s String
   * @return byte[]
   */
  public static byte[] convertMsgBytes(String s) {
    try {
      return s.getBytes(Constants.BYTE_ENCODING);
    }
    catch (UnsupportedEncodingException ex) {
      System.out.println("Error while converting msg to bytes " + ex.toString());
      return null;
    }
  }
  /**
   * Compare two bytes and return OR them and return the result as a string
   * @param mask byte
   * @param b byte
   * @return String
   */
  public static String comp(byte mask, byte b) {

    byte result1 = (byte) 0xff;

    //OR two bytes mask is a byte with only one bit cleared
     // Its to check whether a particular bit is set or not in the
     // BitField
    byte or1 = (byte) (mask | b);

    //If the result is 1111 1111 then return 1
     //else return 0
    if (or1 == result1) {
      return "1";
    }
    else {
      return "0";
    }

  }

  /**
   * Converts a binary string of a given byte
   * @param b byte
   * @return String
   */
  public static String getBinary(byte b) {
    String s2 = null;

    //Set the mask to 0111 1111 and or it with the given byte to find whether
    // MSB is set or clear similarly for other bits of the given Byte
    byte mask = 0x7f;
    s2 = comp(mask, b);

    mask = (byte) 0xbf;
    s2 = s2 + (comp(mask, b));

    mask = (byte) 0xdf;
    s2 = s2 + (comp(mask, b));

    mask = (byte) 0xef;
    s2 = s2 + (comp(mask, b));

    mask = (byte) 0xf7;
    s2 = s2 + (comp(mask, b));

    mask = (byte) 0xfb;
    s2 = s2 + (comp(mask, b));

    mask = (byte) 0xfd;
    s2 = s2 + (comp(mask, b));

    mask = (byte) 0xfe;
    s2 = s2 + (comp(mask, b));

   //Return the binary representation of the byte
    return s2;
  }
  /**
   * This function converts the stored bit field to bytes. This is the reverse of
   * the getBinary Function
   * @param bitFld
   * @return
   */
  public static  byte[] getByteBitField()
  {
    int len=FileInfo.bitField.length;
    int noOfBytes=len/8;
    if(len % 8 > 0)
      noOfBytes++;

    byte[] bitFieldBytes=new byte[noOfBytes];


    int byteArrPos=noOfBytes-1;
    int bytePos=7;
    //first clear all the bits
    for(int i=0;i<noOfBytes;i++)
    {
      bitFieldBytes[i]=(byte)0;
    }
    //first initialize all the bits to 0s.
    for(int i=len-1;i>=0;i--)
    {

      if(FileInfo.bitField[i] == 0)
      {

       bitFieldBytes[byteArrPos]=clearBitAt(bitFieldBytes[byteArrPos],bytePos);
      }

      if(FileInfo.bitField[i]==1)
      {

        bitFieldBytes[byteArrPos]=setBitAt(bitFieldBytes[byteArrPos],bytePos);
      }

      //dec the pointers
     bytePos--;
      if(bytePos < 0)
      {
        bytePos=7;
        byteArrPos--;
      }

    }


    return bitFieldBytes;

  }
  /**
   * This function clears the bit at the position pos of the byte a and returns
   * the new byte
   * @param a
   * @param pos
   * @return
   */
  private static byte setBitAt(byte a, int pos)
  {
    byte mask;

    ///the mask is essentially the 2 power pos value
    switch(pos)
    {
      case 0:
        mask=0x01;
        break;
      case 1:
        mask=0x02;
        break;
      case 2:
        mask=0x04;
        break;
      case 3:
        mask=0x08;
        break;
      case 4:
        mask=0x10;
        break;
      case 5:
        mask=0x20;
        break;
      case 6:
        mask=0x40;
        break;
      case 7:
        mask=(byte)0x80;
        break;
      default:
        mask=(byte)0x00;
        break;

    }
    byte ret=(byte)(a|mask);
    return ret;
  }

  private static byte clearBitAt(byte a, int pos)
  {
    byte mask;

    ///the mask is essentially a byte with 0 at the pos val
    switch(pos)
    {
      case 0:
        mask = (byte)0xfe;
        break;
      case 1:
        mask = (byte)0xfd;
        break;
      case 2:
        mask = (byte)0xfb;
        break;
      case 3:
        mask = (byte)0xf7;
        break;
      case 4:
        mask = (byte)0xef;
        break;
      case 5:
        mask = (byte) 0xdf;
        break;
      case 6:
        mask = (byte)0xbf;
        break;
      case 7:
        mask = (byte) 0x7f;
        break;
      default:
        mask = (byte) 0xff;
        break;
    }
    byte ret=(byte)(a&mask);
    return ret;


  }
  /**
   * Converts a string to an array
   * @param bitField String
   * @return int[]
   */
  public static int[] convertStringToArray(String bitField) {
    int[] intBitField = new int[bitField.length()];

    //COnvert each character to its int value
    for (int i = 0; i <bitField.length(); i++) {
      intBitField[i] = (int)(bitField.charAt(i))-(int)('0');
    }


    return intBitField;
  }
  /**
  * Converts a Hexadecimal string to byteArray
  * @param hex String
  * @throws UnsupportedEncodingException
  * @return byte[]
  * @author Got From the Internet
  */
 public static byte[] convertHexStringToByte(String hex) throws
     UnsupportedEncodingException {

   byte[] bts = new byte[ (hex.length() / 2)];

   //Get two charaters at a time and convert them to a byte
   for (int i = 0; i < bts.length; i++) {
     bts[i] = (byte) ( (Integer.parseInt(hex.substring(2 * i, 2 * i + 2), 16)));


   }
   //Return the byte Array
   return bts;

 }


 public static String ourStringFunc(byte[] b)
 {

  String s = null;
  try {



    s = new String(b, Constants.BYTE_ENCODING);
  }
  catch (UnsupportedEncodingException ex1) {
    System.out.println("Error during conversion" +ex1.toString());
  }



  String s2=null;
  try
  {
    String s11=s.substring(0,50);

     s2 = URLEncoder.encode(s11,Constants.BYTE_ENCODING);
  }
 catch (UnsupportedEncodingException ex)
  {
        System.out.println("Error during conversion" +ex.toString());
  }



  s = URLDecoder.decode(s2);



  return s;


 }


}
