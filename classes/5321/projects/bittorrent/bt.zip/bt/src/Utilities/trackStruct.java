package Utilities;
/**
 *
 * <p>Title: trackStruct.java</p>
 * <p>Description:This describes the structure of the peer details got from the tracker </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Baylor University </p>
 * @author not attributable
 * @version 1.0
 */


public class trackStruct
{
public int no;
public  String peerID;
public String peerIP;
public  String peerPort;
  /**
   * default constructor
   */
  public trackStruct()
  {
    peerID=new String();
    peerIP=new String();
    peerPort=new String();

  }
  /**
   * constructor with no, peerid, peer 's ip and port
   * @param n int
   * @param pId String
   * @param pIP String
   * @param pPort String
   */

  public trackStruct(int n,String pId,String pIP, String pPort)
  {
    no=n;
    peerID=pId;
    peerIP=pIP;
    peerPort=pPort;

  }
  /**
   * returns the ip address of the peer
   * @return String
   */

  public String getIP()
  {
    return peerIP;
  }
  /**
   * returns the port of the peer
   * @return String
   */

  public String getPort()
  {
    return peerPort;
  }
  /**
   * toString function which returns the details in the order id,ip and port
   * @return String
   */
  public String toString()
  {
    return " ID :" +peerID+"  iP : "+peerIP+" peerPort  "+peerPort;
  }

}
