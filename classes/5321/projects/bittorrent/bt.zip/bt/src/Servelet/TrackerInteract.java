package Servelet;

import java.util.ArrayList;
import java.io.IOException;
import java.net.Socket;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.DataInputStream;
import java.net.UnknownHostException;
import BenCoder.Decoder;
import java.util.Map;
import Utilities.trackStruct;
import java.net.URL;
import java.net.MalformedURLException;
import java.net.URLEncoder;
import java.io.UnsupportedEncodingException;
import Utilities.Functions;
import java.util.StringTokenizer;
import Utilities.Constants;
import Protocol.FileInfo;
import java.net.SocketException;
import java.util.zip.*;
import java.io.InputStream;
import java.io.StringReader;
import java.io.ByteArrayInputStream;


/**
 *
 * <p>Title: Tracker Interact</p>
 * <p>Description: Creates the Get Request String and calls GetHandler to get the peer list</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: CSI5321</p>
 * @author Arun Chokkalignam
 * @version 1.0
 *
 */
public class TrackerInteract
{

  /**
   * Creates a request query string and sends it to the tracker using GetHandler
   * @param announceURL String
   * @param infoHash String
   * @throws MalformedURLException
   * @throws MalformedURLException
   * @throws IOException
   * @return Vector
   */
  private Socket s;
  private PrintStream op;
  private DataInputStream di;
  private   OutputStream os;
    /**
     * Constructor
     */
    public TrackerInteract()
    {


    }


  public ArrayList getInfofromTracker(String announceURL,String infoHash) throws
      MalformedURLException, UnsupportedEncodingException, UnknownHostException,
      IOException
  {

    //Get the URL of the tracker
     URL myURL=new URL(announceURL);

    //first append info_hash
    String parmList=new String("?info_hash=");

    //URL encode the info hash
    String infoHash2=new String(URLEncoder.encode(infoHash,Constants.BYTE_ENCODING));

    //Append it to the request string
    parmList=parmList+infoHash2;

    //append peer_id
    parmList=parmList+("&peer_id=");

    //Generate the Peer ID for the client using the Current time of the Machine
    Long currTime=new Long(System.currentTimeMillis());

    //String myPeerID=Functions.getHostName()+currTime.toString();
    String myPeerID;
    if(FileInfo.idSetFlag==true)
    {
      myPeerID=FileInfo.myId;
    }
    else
    {
      FileInfo.idSetFlag=true;
      myPeerID="S123----"+(currTime.toString().substring(0,12));
//      myPeerID="M3-4-2--96713ca3a037";
      FileInfo.myId=myPeerID;
    }

    ///assign to globals
    FileInfo.myId=myPeerID;
    parmList=parmList+(myPeerID);




    //append port we wanna listen at
    parmList=parmList+("&port=");
    String myPortNumber=Functions.getPortNumber();
    parmList=parmList+(myPortNumber);

    //append key
    parmList=parmList+"&key="+Constants.myKey;

    //upload
    String myUpL=Functions.getUploaded();
    parmList=parmList+("&uploaded=");
    parmList=parmList+myUpL;

    //append downloaded
     parmList=parmList+("&downloaded=");
     parmList=parmList+Functions.getDownloaded();

     //append left

     parmList=parmList+("&left=");
     parmList=parmList+Functions.getLeft();

     //compact
//    parmList=parmList+"&compact="+Constants.myCompact;

     //start value
     parmList=parmList+("&event=started");
     //

  //get the hostname,url,port
    String URLStr=myURL.toString();
    String tempHostName= URLStr;
    tempHostName=tempHostName.replaceAll("/announce","");
    StringTokenizer st=new StringTokenizer(tempHostName,":");
    st.nextToken();


    String HostName=st.nextToken();
    HostName=HostName.replaceAll("//","");

///
    FileInfo.trackerIP=HostName;
    String myPort=st.nextToken();
    int portID=Integer.parseInt(myPort);

    //pass and get the list of peers in a vector
    ArrayList peerList =myGet(URLStr,HostName,portID,parmList);

    //return the vector containing the Peer List
    return peerList;
  }

  /**
     * Communicates with the Tracker to get the peer list
     * @param hostURL String
     * @param hostName String
     * @param port int
     * @param myParm String
     * @throws IOException
     * @return Vector
     */
    // This function returns a vector containing the peerid , ip and port

   public  ArrayList myGet(String hostURL, String hostName, int port, String myParm) throws UnknownHostException,
        IOException {



     //do a get request
     System.out.println("--> hostURL" + hostURL);
//   hostURL="/announce";

      String request = "GET " + hostURL + myParm +  " HTTP/1.0\r\n";
      System.out.println("\nreqyest "+request);

//    request=request+"Host: 129.62.150.58:6969\r\nAccept-encoding: gzip\r\nUser-agent: BitTorrent/3.4.2\r\n";
//    request=request+"Host: 129.62.150.58:6969\r\nUser-agent: BitTorrent/3.4.2\r\n";

      // System.out.println("request ::"+ request);
      //Connect to the tracker
      s = new Socket(hostName, port);
      os = s.getOutputStream();
      op = new PrintStream(os);

      //Send the Get Request
      op.println(request);


         DataInputStream di = new DataInputStream(s.getInputStream());
         ArrayList peerList = new ArrayList();
         String line;
         //Read one line at a time from the trackers reply
         while ((line = di.readLine()) != null)
         {
           System.out.println("line"+line);
                  //Get the peers from the list (if any)
                 //check if this line has interval
                 if(line.length() > 11)
                 {

                   String s1 = line.substring(3, 11);
          System.out.println("        line2"+line);
                   if(s1.equals("interval"))
                   {
                               System.out.println("           line3"+line);
                     //This contains the interval..get it bendecoded.
                     Map dMap = Decoder.decode(line.getBytes());

                     ArrayList l1 =  (ArrayList )dMap.get("peers");

                     //get all the peer list and add it to the list of  vectors
                     int cnt=0;
                     for(int i=0; i< l1.size();i++)
                     {

                       Map tempMap=(Map)l1.get(i);

                       //Get the IP of the peer
                       String myIP = new String( (byte[]) tempMap.get("ip"),
                                                 Constants.BYTE_ENCODING);

                       //The Peer ID submitted to the tracker
                       String myPeerId= new String((byte[])tempMap.get("peer id"),Constants.BYTE_ENCODING);

                       //The port number on which the peer is listening
                       String myport = ((Object)tempMap.get("port")).toString();

                       //Create a structure of the Peer
                       trackStruct tS=new trackStruct(cnt,myPeerId,myIP,myport);
                   System.out.println("peer from tk " +tS.toString());
                       //Add the peer structure to the vector
                       peerList.add(tS);
                       cnt++;

                     }

                   }
                 }

               }
              // Close the socket connection
               if(s!=null)
                 s.close();

          //Return the Peer list
           return peerList;

    }

    /**
     * This function sends a completed signal to the tracker by computing the values
     * and then calling the sendCompleted
     * @param announceURL
     * @param infoHash
     * @throws MalformedURLException
     * @throws UnsupportedEncodingException
     * @throws UnknownHostException
     * @throws IOException
     */
        public  void trackerCompStopped(String announceURL,String infoHash,String event) throws
          MalformedURLException, UnsupportedEncodingException, UnknownHostException,
          IOException {

        //Get the URL of the tracker
         URL myURL=new URL(announceURL);

        //first append info_hash
        String parmList=new String("?info_hash=");

        //URL encode the info hash
        String infoHash2=new String(URLEncoder.encode(infoHash,Constants.BYTE_ENCODING));

        //Append it to the request string
        parmList=parmList+infoHash2;

        //append peer_id
        parmList=parmList+("&peer_id=");
        Long currTime=new Long(System.currentTimeMillis());

         //String myPeerID=Functions.getHostName()+currTime.toString();
         String myPeerID;
         if(FileInfo.idSetFlag==true)
         {
           myPeerID=FileInfo.myId;
           //Alert : to be erased later
           //  myPeerID="OurSyst"+currTime.toString();
     }
     else
     {
       FileInfo.idSetFlag=true;
       myPeerID="S123----"+(currTime.toString().substring(0,12));
       FileInfo.myId=myPeerID;

     }

         ///assign to globals
         FileInfo.myId=myPeerID;
         parmList=parmList+(myPeerID);

        //append port we wanna listen at
         parmList=parmList+("&port=");
         String myPortNumber=Functions.getPortNumber();
         parmList=parmList+(myPortNumber);


     //append key
    parmList=parmList+"&key="+Constants.myKey;


     //upload
     String myUpL=Functions.getUploaded();
     parmList=parmList+("&uploaded=");
     parmList=parmList+myUpL;

     //append downloaded
      parmList=parmList+("&downloaded=");
      parmList=parmList+Functions.getDownloaded();

      //append left

      parmList=parmList+("&left=");
      parmList=parmList+Functions.getLeft();
      //compact
        parmList=parmList+"&compact="+Constants.myCompact;


         //start value
         parmList=parmList+("&event=")+event;

      //get the hostname,url,port
        String URLStr=myURL.toString();
        String tempHostName= URLStr;
        tempHostName=tempHostName.replaceAll("/announce","");
        StringTokenizer st=new StringTokenizer(tempHostName,":");
        st.nextToken();


        String HostName=st.nextToken();
        HostName=HostName.replaceAll("//","");
        String myPort=st.nextToken();
        int portID=Integer.parseInt(myPort);

        //pass and get the list of peers in a vector
        sendCompleted(URLStr,HostName,portID,parmList);



      }
      /**
       * This sends a completed get method to the tracker
       * @param hostURL
       * @param hostName
       * @param port
       * @param myParm
       * @throws UnknownHostException
       * @throws IOException
       */
    private  void sendCompleted(String hostURL, String hostName, int port, String myParm) throws UnknownHostException,
        IOException
    {



     //   hostURL="/announce";
        String request = "GET " + hostURL + myParm +  " HTTP/1.0\r\n";

  //     request=request+"Host: 129.62.150.58:6969\r\nAccept-encoding: gzip\r\nUser-agent: BitTorrent/3.4.2\r\n";

          // System.out.println("request ::"+ request);

     //do a get request

      //Send the Get Request
      s = new Socket(hostName, port);
      os = s.getOutputStream();
      op = new PrintStream(os);

      //Send the Get Request
     // op.println(request);

      op.println(request);

      ArrayList peerList = new ArrayList();
      String line=null;
      //Read one line at a time from the trackers reply
    /*  while ((line = di.readLine()) != null)
      {
       System.out.println(line.toString());

      }
*/

    }





}
