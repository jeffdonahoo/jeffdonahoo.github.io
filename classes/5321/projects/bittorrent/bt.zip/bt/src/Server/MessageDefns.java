package Server;

import java.net.Socket;
import java.io.IOException;
import Protocol.FileInfo;
import Utilities.Constants;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class MessageDefns {

 public static boolean doHandShake(Socket aSocket)
  {
    boolean hS;
    try
      {
        //call the message send's handshake
        hS = MessageSend.HandShake(aSocket, FileInfo.myId, FileInfo.myInfoHash);
//        System.out.println("One Done -->"+FileInfo.myId);

      }
      //catch texceptions
      catch (InterruptedException ex)
      {
        System.out.println("Bad Handshake " + ex.toString());
        hS = false;
      }
      catch (IOException ex) {
        System.out.println("Bad Handshake" + ex.toString());
        hS = false;
      }   catch (Exception ex)
      {
        System.out.println("Bad Handshake" + ex.toString());
        hS = false;
      }

      return hS;

  }
  /**
   * This function sends the bit field
   * @param aSocket
   * @return
   */
  public static boolean sendBitField(Socket aSocket)
  {

    return MessageSend.msgBitField(aSocket);
  }

  /**
  * This function sends an unchoke message. Returns true if successful
  * @param s Socket
  * @return boolean
  */
 public static boolean sendUnChoke(Socket s)
{
 return MessageSend.msgLenID(s, Constants.unchokeLen,
                             Constants.unchokeID);
}

  public static boolean sendRequestedPiece(Socket s,int pID, int offset, int piecelen, byte[] reqPiece)
  {
    return MessageSend.msgLenIDPiece(s,Constants.pieceLen+piecelen,pID,offset,reqPiece);
  }

  /**
   * handles handshake from tracker
   * @param aSocket
   * @return
   */
  public static boolean doTrackerHandShake(Socket aSocket)
  {
    boolean hS;
    try
      {
        //call the message send's handshake
        hS = MessageSend.trackerHandShake(aSocket, FileInfo.myId, FileInfo.myInfoHash);
//        System.out.println("One Done -->"+FileInfo.myId);

      }
      //catch texceptions
      catch (InterruptedException ex)
      {
        System.out.println("Bad Handshake " + ex.toString());
        hS = false;
      }
      catch (IOException ex) {
        System.out.println("Bad Handshake" + ex.toString());
        hS = false;
      }   catch (Exception ex)
      {
        System.out.println("Bad Handshake" + ex.toString());
        hS = false;
      }

      return hS;

  }

}