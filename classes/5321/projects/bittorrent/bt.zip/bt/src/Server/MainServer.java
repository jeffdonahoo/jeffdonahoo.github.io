package Server;


import java.net.ServerSocket;
import java.net.Socket;
import Utilities.Constants;
import java.io.IOException;
import java.io.DataInputStream;
import java.io.BufferedInputStream;

/**
 *
 * <p>Title:Server </p>
 * <p>Description:This implements the BitTorrent Listener </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Baylor University CS</p>
 * @author CSI 5321 not attributable
 * @version 1.0
 */
public class MainServer implements Runnable
{
   private ServerSocket listener;//server socket variable


   /**
    * default constructor
    */
   public MainServer()
  {

  }
  /**
   * Implements run method
   */

  public void run()
  {

      listen();

  }

  /**
   * this function implements the listener socket
   */
  public void  listen()
  {
    int i = 0;
    boolean flag=false;
    while(flag==false)
    {
      try
      {

          Constants.portNumber++;
          listener = new ServerSocket(Constants.portNumber);
          if((listener.getLocalPort() > 0) &&
              (listener.isClosed()==false) )
           {
             flag=true;
           }
     }
     catch (Exception ioe)
     {

     }
    }
      Constants.portNumber = listener.getLocalPort();
      System.out.println("*****Server Listening on "+ Constants.portNumber+"********");
      Socket server;

      try{

        while ( (i++ < Constants.maxConnections) ||
               (Constants.maxConnections == 0)) {

          server = listener.accept();
//         System.out.println("Connection got");
          handleConnection(server);
        }
      }
      catch(Exception e)
      {
         System.out.println("Exception doing server socket: " + e.toString());
      }




      try
      {
        listener.close();
      }
      catch (IOException ioe)
      {
        System.out.println("IOException: " + ioe);
        ioe.printStackTrace();


       }




  }
  /**
   * this handles the connection from every client
   * @param s Socket
   */
  public void handleConnection(Socket s)
  {
    //System.out.println("\n\n\nCreate new SP");
    ServerProtocol SP=new ServerProtocol(s);

    Thread myThread =new Thread(SP);
    myThread.start();


  }

}
