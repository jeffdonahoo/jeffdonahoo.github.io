package Server;

import java.net.Socket;
import java.util.ArrayList;
import Utilities.Constants;
import Protocol.FileInfo;
import java.io.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class ServerProtocol implements Runnable
{

  public ArrayList RequestQueue;
  private ServerListener SL;
  private Thread myThread;
  private Socket s;
  public ServerProtocol(Socket s1)
  {
    s=s1;
    RequestQueue=new ArrayList();
  }

public void run()
  {
    this.doProtocol();
  }
  public boolean add( Request aRequest )
  {

    return RequestQueue.add(aRequest);
  }
  public boolean delete( Request aRequest ) {

   return RequestQueue.remove(aRequest);
 }

  public void doProtocol()
  {
    //check if its a handshake from the server alone


    if(s.getInetAddress().toString().equals(("/"+FileInfo.trackerIP))==true)
    {
      //do the new Protocol and quit
      boolean success=MessageDefns.doTrackerHandShake(s);


    }


    //first accept the handshake and send a handshake if the receriveone is good
    else
    {


      boolean success=MessageDefns.doHandShake(s);


      if(success==true)
      {
        //now send the bitField
        success=MessageDefns.sendBitField(s);
        success=MessageDefns.sendUnChoke(s);

        //now start the listener thread
        SL= new ServerListener(s,this);
        myThread =new Thread(SL);
        myThread.start();


        //keep checking the request and do the request

         while(true)
        {
          if (RequestQueue.size() > 0) {
            //get a request
            Request rq = (Request) RequestQueue.get(0);

            //send the requesting piece
            Integer I= new Integer(rq.pieceID);
            byte[] piece= (byte [])FileInfo.fileMap.get(I);


            //go to the offset and send the length number of bytes
            byte[] requestedBytes=new byte[rq.length];

            //get the bytes that are required
            for(int i=0;i<rq.length;i++)
            {
                  requestedBytes[i]=piece[(rq.offset + i)];
            }

            //send the requested Bytes

            MessageDefns.sendRequestedPiece(s,rq.pieceID,rq.offset,rq.length,requestedBytes);
            FileInfo.upload += rq.length;
            //delete the element from the queue
            RequestQueue.remove(0);

          }
        }

      }
      else
      {
        try {
          s.close();
        }
        catch (IOException ex1) {
          System.out.println("Close error");
        }
      }


    }



    try
    {

      s.close();
    }
    catch (IOException ex) {
      System.out.println("error in closing");
    }


  }
}