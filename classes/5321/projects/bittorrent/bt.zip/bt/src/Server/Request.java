package Server;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class Request {

    int pieceID=0;
    int offset=0;
    int length=0;
    int status=0;

    public Request(int pID, int off, int len, int stat)
    {
      pieceID=pID;
      offset=off;
      length=len;
      status=stat;
    }


}