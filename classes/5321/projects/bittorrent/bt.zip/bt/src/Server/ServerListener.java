package Server;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */


import java.net.Socket;
import java.io.DataInputStream;
import java.io.BufferedInputStream;
import java.io.IOException;
import Utilities.Functions;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

//This class implements the listener thread for the Server
public class ServerListener implements Runnable
{

   private Socket mySocket = null;
   private DataInputStream in = null;
   private ServerProtocol myServerProtocol;

  /**
   * Creates an instance of the Listener Thread
   * @param aPeer Peer
   */
  public ServerListener(Socket aSocket, ServerProtocol aServerProtocol)
  {

    mySocket = aSocket;
    myServerProtocol = aServerProtocol;

    try {

      in = new DataInputStream(new BufferedInputStream(mySocket.getInputStream()));

    }
    catch (Exception e)
    {

      System.out.println("Caught while creating InputStream " + e.toString());

    }
  }


/**
 * Running The Listener Thread
 */
public void run()
  {
    boolean  flag=true;
      while ( flag==true )
      {
        flag=listenCycle();
      }
  }

  /**
   * Listens and takes appropriate action for the incoming messages
   */
  public boolean listenCycle()
  {



   int length_field = 0;
   int inID;
   byte[] payLoad = null;
   // Read the length field of the incoming Messages
   try
   {
     length_field = in.readInt();
   }
   catch (IOException ex)
   {

     System.out.println("Caught while reading length at server" + ex.toString() + mySocket.toString());
     return false;

   }

   //If there is no payload read id and change the status depending on the message
   if (length_field == 1)
   {
     try
     {
       inID = in.readByte();
     }
     catch (IOException ex1)
     {
       System.out.println("Caught while reading ID" + ex1.toString() + mySocket.toString() );

       inID = 10;
     }
     switch (inID) {
       case 0: /******** CHOKE MESSAGE *********/


         //Change the status of the client


         break;
       case 1: /******** UNCHOKE MESSAGE *********/

         //The peer has unchoked the client
         //Change the status of the client


         break;

       case 2: /******** INTERESTED MESSAGE *********/

         //The peer is interested in the client
         //Change the status of the peer


         break;
       case 3: /******** NOT-INTERESTED MESSAGE *********/

         //The peer has no interes in the client's stuff
         //Change the status of the peer

         break;

     }
   }
   /* Handle the messages having a PayLoad field */
   else if (length_field > 1) {
     // Read the ID field of the message
     try {
       inID = in.readByte();
     }
     catch (IOException ex2)
     {
       System.out.println("Caught while reading ID field " + ex2.toString() );
       inID = 10;
     }

     switch (inID) {

       case 4: /******** Have MESSAGE *********/

         //The peer has sent the Have Message

         try {
            readHave(in, length_field);
         }
         catch (Exception ex3)
         {
           System.out.println("Caught while reading ID field " + ex3.toString() );
         }

         break;




       case 5: /******** BitField MESSAGE *********/

         //The peer has sent the BitField

         //Read the Bit Field
          readBitField(in,length_field);

         break;
       case 6:/******** Request MESSAGE *********/

         //The peer has sent the Request

         try {
         readRequest(in,length_field);
       } catch (Exception ex4) {
         System.out.println("Caught while reading Request " + ex4.toString());
       }


       case 7: /******** PIECE MESSAGE *********/

         //The peer has sent a Piece

         try {
           //Read the Piece
           //readPiece(in, length_field);
           //Check if the Piece has been dowloaded completley
           //If so tell the myPeer about the dowload and send the piece too


         }
         catch (Exception ex4) {
           System.out.println("Caught while reading Piece " + ex4.toString());
         }
         break;

       case 8: /******** CANCEL MESSAGE *********/

         //The peer has sent a Cancel Message

         try {
           readCancel(in, length_field);
         }
         catch (Exception ex4) {
           System.out.println("Caught while reading Cancel " + ex4.toString());
         }



     }



   }

   return true;
  }
  /**
   * Reads the incoming bitField message from the peer
   * @param in DataInputStream
   * @param length_field int
   * @return int[]
   */
  public void readBitField(DataInputStream in , int length_field) {

      //Subtract one for the id which has already been read
      //Set the size of the payload
       byte[] payLoad = new byte[length_field - 1];

       //Read the BitField payload
       try {
            in.read(payLoad);
       }
       catch (IOException ex3) {
         System.out.println("Caught while reading Payload of Bit field " + ex3.toString() );
       }


       String MamaPieceIndex = "";
       //Get the binary representation of the BitField
       for (int j = 0; j < length_field - 1; j++) {
         byte aByte;
         aByte = payLoad[j];
         MamaPieceIndex = MamaPieceIndex + Functions.getBinary(aByte);
       }



  }
  /**
   * Read the have Message Peer has sent telling what additional pieces it Got
   * Set that Particular Bit in the BitField of the Peer
   * @param in DataInputStream
   * @param length_field int
   * @throws Exception
   */
  public void readHave(DataInputStream in , int length_field) throws Exception {

      // If length Field does not match with expected
      if ( length_field != 5) {
        System.out.println("Length field is not 5 in Have message");
        throw new Exception("Length MisMatch");

      }

     //Read the PayLoad of the Have Message which tells the piecesIndex
      int pieceIndex;
       try {
            pieceIndex = in.readInt();
        }
       catch (IOException ex3) {
         System.out.println("Caught while reading Payload of Have " + ex3.toString() );
         pieceIndex = -1;
       }



  }

  /**
   * Reads an incoming request message for a piece from the Peer
   * @param in DataInputStream
   * @param length_field int
   * @throws Exception
   */
  public void readRequest(DataInputStream in , int length_field ) throws Exception {
       int inPI;

       if ( length_field != 13) {
        System.out.println("Length field is not 13 in Request message");
        throw new Exception(" Length MisMatch in Request");

      }

       //Read the piece index
       try {
         inPI = in.readInt();
       }
       catch (IOException ex) {
         System.out.println("Caught while reading PI in Request" + ex.toString());
         inPI = -1;
       }
       int inOffset;
       //Read the offset
       try {
         inOffset = in.readInt();
       }
       catch (IOException ex1) {
         System.out.println("Caught while reading Offset in Request" + ex1.toString());
         inOffset = -1;
       }
       int length;
       //Read the length of the Block requested
      try {
        length = in.readInt();
      }
      catch (IOException ex1) {
        System.out.println("Caught while reading length in Request" + ex1.toString());
        length = -1;
      }

      Request aRequest = new Request(inPI,inOffset,length,0);

      myServerProtocol.add(aRequest);

 }
 /**
  * Reads a cancel Request message from the Peer
  * @param in DataInputStream
  * @param length_field int
  * @throws Exception
  */
 public void readCancel(DataInputStream in , int length_field ) throws Exception {
        int inPI;

        if ( length_field != 13) {
         System.out.println("Length field is not 13 in Request message");
         throw new Exception(" Length MisMatch in Request");

       }

        //Read the piece index
        try {
          inPI = in.readInt();
        }
        catch (IOException ex) {
          System.out.println("Caught while reading PI in Request" + ex.toString());
          inPI = -1;
        }
        int inOffset;
        //Read the offset
        try {
          inOffset = in.readInt();
        }
        catch (IOException ex1) {
          System.out.println("Caught while reading Offset in Request" + ex1.toString());
          inOffset = -1;
        }
        int length;
        //Read the length of the Block
       try {
         length = in.readInt();
       }
       catch (IOException ex1) {
         System.out.println("Caught while reading length in Request" + ex1.toString());
         length = -1;
       }

       Request aRequest = new Request(inPI,inOffset,length,0);
       myServerProtocol.delete(aRequest);
  }




}

