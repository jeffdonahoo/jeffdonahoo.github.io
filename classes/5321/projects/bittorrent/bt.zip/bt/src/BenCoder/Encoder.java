package BenCoder;

import java.util.*;
import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import Utilities.Constants;

/**
 * A set of utility methods to encode a Map into a bencoded array of byte.
 * integer are represented as Long, String as byte[], dictionnaries as Map, and list as List.
 *
 * @author  TdC_VgA
 */
public class Encoder
{
    /** Creates a new instance of Encoder */
    public Encoder()
    {
    }

    public static String encode(Map object) throws IOException
    {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Encoder.encode(baos, object);


        byte[] value = baos.toByteArray();


        String myVal=null;

         try
         {
           myVal = new String(new String(value,
               Constants.BYTE_ENCODING));

         }
         catch(Exception e)
         {
           System.out.println("Caught while codeing string " +e.toString());
         }



        return myVal;
    }

    private static void        encode(
                ByteArrayOutputStream baos,
                Object object)

            throws IOException
        {

        if ( object instanceof String || object instanceof Float){

            String tempString = (object instanceof String) ? (String)object : String.valueOf((Float)object);


            baos.write((String.valueOf(tempString.getBytes(Constants.BYTE_ENCODING).length)).getBytes());

            baos.write(':');

            baos.write(tempString.getBytes(Constants.BYTE_ENCODING));

        }
        else if(object instanceof Map)
        {

            Map tempMap = (Map)object;

            SortedMap tempTree = null;

                    // unfortunately there are some occasions where we want to ensure that
                    // the 'key' of the map is not mangled by assuming its UTF-8 encodable.
                    // In particular the response from a tracker scrape request uses the
                    // torrent hash as the KEY. Hence the introduction of the type below
                    // to allow the constructor of the Map to indicate that the keys should
                    // be extracted using a BYTE_ENCODING

            boolean	byte_keys = object instanceof ByteEncodedKeyHashMap;

            //write the d
            baos.write('d');

            //are we sorted?
            if ( tempMap instanceof TreeMap ){

                tempTree = (TreeMap)tempMap;

            }else
            {

                        //do map sorting here

                tempTree = new TreeMap(tempMap);
            }

            Iterator	it = tempTree.entrySet().iterator();

            while( it.hasNext())
            {

                    Map.Entry	entry = (Map.Entry)it.next();

                    String key = (String)entry.getKey();

                                      Object value = entry.getValue();

                                      if ( value != null )
                                      {

                                        if ( byte_keys )
                                        {

                                                   try{

                                                            Encoder.encode(baos,key.getBytes( Constants.BYTE_ENCODING ));

                                                      Encoder.encode(baos, tempMap.get(key));

                                                    }catch( UnsupportedEncodingException e ){

                                                    throw( new IOException( "Encoder: unsupport encoding: " + e.getMessage()));
                                                  }

                                              }
                                              else
                                              {

                                Encoder.encode(baos, key );	// Key goes in as UTF-8

                                              Encoder.encode(baos, value);
                                    }
                }
            }

            /*
            //create a list to hold the alpha ordered keys
            ArrayList keyList = new ArrayList();

            //BUILD THE KEY LIST
            //I KNOW THIS IS NASTY, BUT SUN DIDN'T SEE FIT TO RETURN A NULL
            do{
                try{
                    //get the key
                    String tempKey = (String)tempTree.firstKey();
                    //stuff it into the list
                    keyList.add(tempKey);
                    //get the rest of the tree
                    tempTree = tempTree.tailMap(tempKey+"\0");
                }catch(NoSuchElementException e){
                    break;
                }
            }while(true);

                    //encode all of the keys

            if ( byte_keys ){

                    try{

                                        for(int i = 0; i<keyList.size(); i++){

                                                   String key = (String)keyList.get(i);
                                                   Object value = tempMap.get(key);
                                                   if (value != null) {
                                                             //encode the key
                                                     Encoder.encode(baos,key.getBytes( Constants.BYTE_ENCODING ));
                                                             //encode the value
                                                     Encoder.encode(baos, tempMap.get(key));
                                             }
                                           }
                    }catch( UnsupportedEncodingException e ){

                            throw( new IOException( "Encoder: unsupport encoding: " + e.getMessage()));
                    }
            }else{

                                for(int i = 0; i<keyList.size(); i++){
                                        Object key = keyList.get(i);
                                        Object value = tempMap.get(key);
                                        if (value != null) {
                                          //encode the key
                                          Encoder.encode(baos, key );	// Key goes in as UTF-8
                                          //encode the value
                                          Encoder.encode(baos, value);
                                  }
                                }
            }
            */


            baos.write('e');


        }else if(object instanceof List){

            List tempList = (List)object;

                    //write out the l

            baos.write('l');

            for(int i = 0; i<tempList.size(); i++){

                Encoder.encode(baos, tempList.get(i));
            }

            baos.write('e');

        }else if(object instanceof Long){

            Long tempLong = (Long)object;
            //write out the l
               baos.write('i');
               baos.write(tempLong.toString().getBytes());
               baos.write('e');
         }else if(object instanceof Integer){

                        Integer tempInteger = (Integer)object;
                        //write out the l
                        baos.write('i');
                        baos.write(tempInteger.toString().getBytes());
                        baos.write('e');

       }else if(object instanceof byte[]){

            byte[] tempByteArray = (byte[])object;
            baos.write((String.valueOf(tempByteArray.length)).getBytes());
            baos.write(':');
            baos.write(tempByteArray);
        }
    }

    public static boolean
        mapsAreIdentical(
                Map	map1,
                Map	map2 )
        {
            if ( map1 == null && map2 == null ){

                    return( true );

            }else if ( map1 == null || map2 == null ){

                    return( false );
            }

            if ( map1.size() != map2.size()){

                    return( false );
            }

            try{
                    return(  Arrays.equals( encode(map1).getBytes() , encode(map2).getBytes() ));

            }catch( IOException e ){

                    e.printStackTrace();

                    return( false );
            }
    }
}

  class ByteEncodedKeyHashMap extends HashMap {}
