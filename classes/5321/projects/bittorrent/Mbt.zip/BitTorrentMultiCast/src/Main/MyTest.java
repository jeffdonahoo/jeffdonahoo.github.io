package Main;

import rice.scribe.testing.*;
import rice.scribe.testing.BasicScribeRegrTest;
import rice.pastry.PastryNode;
import java.io.DataInputStream;
import java.io.BufferedInputStream;
import java.io.*;
import java.util.Map;
import rice.MBTorrent.Constants;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class MyTest {
  public MyTest() {
  }

  /**
   * my Test function for scribe
   * @param args
   */
  public static void main(String args[])
  {

       //DistScribeRegrTest a= new DistScribeRegrTest();
    String a=null;
    System.out.println("Enter 1 for bootstrap server .. consecutive numbers for other peers");

    DataInputStream dis=new DataInputStream(new BufferedInputStream(System.in));
    try
    {
      a = dis.readLine();
    }

    catch (IOException ex)
    {
    }

    if(a.equals("1")==true)
    {
      String[] b = {"-protocol","wire"};
      MultiStarter m=new MultiStarter(5009);
      m.startProtocol(b,true);
    }
    else
    {
      Integer newI=new Integer(a);
      int p=5009+newI.parseInt(a);
      newI=new Integer(p);
      System.out.println("Calling port with " + newI.toString());

      String[] b={"-port",newI.toString(), "-bootstrap",Constants.bootStrapVal,"-protocol","wire"};
  MultiStarter m=new MultiStarter(p);
    m.startProtocol(b,false);
     String s = BaylorMessage.createVoteReplyMessage("a","B",3);
     System.out.println("mess->"+s);
    /*  if(BaylorMessage.checkVoteReplyMessage(s))
      {

        Map m=BaylorMessage.getVoteReplyDetails(s);

        System.out.println("topic -> "+(String)m.get(BaylorMessage.topicIDStr));
        System.out.println("nodeid -> "+(String)m.get(BaylorMessage.nodeIDStr));
        System.out.println("time-> "+(String)m.get(BaylorMessage.waitTimeStr));


      }*/

    }

   }

}
