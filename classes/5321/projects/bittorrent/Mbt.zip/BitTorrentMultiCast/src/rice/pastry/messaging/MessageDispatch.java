/*************************************************************************

"FreePastry" Peer-to-Peer Application Development Substrate

Copyright 2002, Rice University. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

- Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.

- Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

- Neither  the name  of Rice  University (RICE) nor  the names  of its
contributors may be  used to endorse or promote  products derived from
this software without specific prior written permission.

This software is provided by RICE and the contributors on an "as is"
basis, without any representations or warranties of any kind, express
or implied including, but not limited to, representations or
warranties of non-infringement, merchantability or fitness for a
particular purpose. In no event shall RICE or contributors be liable
for any direct, indirect, incidental, special, exemplary, or
consequential damages (including, but not limited to, procurement of
substitute goods or services; loss of use, data, or profits; or
business interruption) however caused and on any theory of liability,
whether in contract, strict liability, or tort (including negligence
or otherwise) arising in any way out of the use of this software, even
if advised of the possibility of such damage.

********************************************************************************/

package rice.pastry.messaging;

import java.util.*;

/**
 * An object which remembers the mapping from names to MessageReceivers
 * and dispatches messages by request.
 *
 * @version $Id: MessageDispatch.java,v 1.2 2002/02/28 07:04:49 druschel Exp $
 *
 * @author Andrew Ladd
 */

public class MessageDispatch
{
    // have modified from HashMap to HashMap to use the internal representation
    // of a LocalAddress.  Otherwise remote node cannot get its message delivered
    // because objects constructed differently are not mapped to the same value
    private HashMap addressBook;

    /**
     * Registers a receiver with the mail service.
     *
     * @param name a name for a receiver.
     * @param receiver the receiver.
     */

    public void registerReceiver(Address address, MessageReceiver receiver)
    {
	addressBook.put(address, receiver);
    }

    /**
     * Dispatches a message to the appropriate receiver.
     *
     * @param msg the message.
     *
     * @return true if message could be dispatched, false otherwise.
     */

    public boolean dispatchMessage(Message msg)
    {
	MessageReceiver mr = (MessageReceiver) addressBook.get(msg.getDestination());
   //     System.out.println("\n\n\n\n MRRR"+mr.getClass().toString()+"---"+msg.getDestination());
	if (mr != null) {

          mr.receiveMessage(msg);
              return true;
        }
	else
        {

          throw new Error("message " + msg + " could not be dispatched at " +
                          msg.getDestination());
        }

	// this should be a more interseting exception...
    }

    /**
     * Constructor.
     */

    public MessageDispatch()
    {
	addressBook = new HashMap();
    }

}
