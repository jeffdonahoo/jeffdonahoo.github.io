/*************************************************************************

"FreePastry" Peer-to-Peer Application Development Substrate

Copyright 2002, Rice University. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

- Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.

- Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

- Neither  the name  of Rice  University (RICE) nor  the names  of its
contributors may be  used to endorse or promote  products derived from
this software without specific prior written permission.

This software is provided by RICE and the contributors on an "as is"
basis, without any representations or warranties of any kind, express
or implied including, but not limited to, representations or
warranties of non-infringement, merchantability or fitness for a
particular purpose. In no event shall RICE or contributors be liable
for any direct, indirect, incidental, special, exemplary, or
consequential damages (including, but not limited to, procurement of
substitute goods or services; loss of use, data, or profits; or
business interruption) however caused and on any theory of liability,
whether in contract, strict liability, or tort (including negligence
or otherwise) arising in any way out of the use of this software, even
if advised of the possibility of such damage.

********************************************************************************/

package rice.scribe.testing;

import rice.pastry.*;
import rice.pastry.rmi.*;
import rice.pastry.standard.*;
import rice.pastry.join.*;
import rice.pastry.client.*;
import rice.pastry.messaging.*;
import rice.pastry.security.*;
import rice.pastry.routing.*;
import rice.pastry.leafset.*;
import rice.pastry.dist.*;

import rice.scribe.*;
import rice.scribe.maintenance.*;

import java.util.*;
import java.net.*;
import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.security.*;
import java.io.DataInputStream;
import java.io.BufferedInputStream;
import java.io.IOException;
import rice.scribe.messaging.ScribeMessage;
import rice.MBTorrent.*;
import java.io.DataOutputStream;
import java.io.BufferedOutputStream;
import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.io.*;
/**
 * @(#) DistScribeRegrTest.java
 *
 * A test suite for Scribe with RMI/WIRE.
 *
 * @version $Id: DistScribeRegrTest.java,v 1.18 2002/09/14 18:22:37 druschel Exp $
 *
 * @author Animesh Nandi
 * @author Atul Singh
 */

public  class MultiStarter
{
    private PastryNodeFactory factory;
    private Vector pastryNodes;
    private Random rng;
    public Vector distClients;
    public Vector localNodes;
    public DistScribeRegrTestApp app;
    private  int port = 5009;
    private  String bshost = null;
    private  int bsport = 5009;
    private  int numNodes = 1;
    public Integer num = new Integer(0);
    public  int NUM_TOPICS = 1;
    private boolean mflag=false;
    // number of message received before a node tries
    //to unsubscribe with random probability
    public  int UNSUBSCRIBE_LIMIT = 50;
    public  double UNSUBSCRIBE_PROBABILITY = 0.1;

    public  String fileName;
    public FileDetails fd;

    //This hashtable keeps track of the number of nodes out of 'numNodes' virtual nodes that have
    // already unsubscribed to a topic. The idea is to allow a maximum determined by
    // 'fractionUnsubscribedAllowed' of 'numNodes' to unsubscribe for each topic.
    private Hashtable numUnsubscribed = null;


    // fraction of total virtual nodes on this host allowed to unsubscribe
    public double fractionUnsubscribedAllowed = 0.5;
    public  Object LOCK = new Object();

    // Time a node waits for messages after subscribing, if no messages
    // received in this period, warning mesg is printed.
    public int IDLE_TIME = 120; // in seconds

    public int protocol = DistPastryNodeFactory.PROTOCOL_WIRE;
    private boolean initialized=false;
    private int noOfPieces;
    private long fileSize;
    public rice.MBTorrent.FileDetails myFileDetails;

    /** Firasath Maps **/
   private Map m_topicMap;
   public Map m_timerMap;
   public Map m_sourceMap;
   public Map m_PublisherThreadsMap;


    private long waitTime=0;
    private Date waitDate;
    private Map pieceMap;
    int cntGot=0;
    public MultiStarter(int p)
    {
        int i;
        port=p;
        myFileDetails=new FileDetails();
        NodeId topicId;
        numUnsubscribed = new Hashtable();
        // Create topicIds & set initially the number of vitual nodes that have unsubscribed to 0
/**        for (i=0; i< NUM_TOPICS; i++) {
            topicId = generateTopicId(new String("Topic " + i));
            numUnsubscribed.put(topicId, new Integer(0));
        }**/

        factory = DistPastryNodeFactory.getFactory(new RandomNodeIdFactory(), protocol, port);
        pastryNodes = new Vector();
        distClients = new Vector();
        rng = new Random(PastrySeed.getSeed());
        localNodes = new Vector();
        waitDate=new Date();
        pieceMap=new HashMap();
        fd = new FileDetails();
        m_topicMap = new HashMap();
        m_timerMap = new HashMap();
        m_sourceMap = new HashMap();
         m_PublisherThreadsMap=new HashMap();

    }


    public  int getNumUnsubscribed(NodeId topicId)
    {
        return ((Integer)numUnsubscribed.get(topicId)).intValue();
    }

    public void incrementNumUnsubscribed(NodeId topicId) {
        int count;
        count = ((Integer)numUnsubscribed.get(topicId)).intValue();
        numUnsubscribed.remove(topicId);
        numUnsubscribed.put(topicId, new Integer(count + 1));
    }

    private NodeHandle getBootstrap()
    {
        InetSocketAddress addr = null;
        if(bshost != null )
        {

          addr = new InetSocketAddress(bshost, bsport);
          System.out.println("Use Bootstrap");
          mflag=true;
        }
        else
        {
            try
            {
              System.out.println("Create Bootstrap");
              addr = new InetSocketAddress(InetAddress.getLocalHost().getHostName(), bsport);

            }
            catch(UnknownHostException e){
                System.out.println(e);
            }
        }

//        System.out.println("BootStrap ==>"+addr.getAddress().toString());
        NodeHandle bshandle = ((DistPastryNodeFactory)factory).getNodeHandle(addr);

        return bshandle;
    }


     public NodeId generateTopicId( String topicName )
     {
        MessageDigest md = null;

        try {
            md = MessageDigest.getInstance( "SHA" );
        } catch ( NoSuchAlgorithmException e ) {
            System.err.println( "No SHA support!" );
        }

        md.update( topicName.getBytes());
        byte[] digest = md.digest();

        NodeId newId = new NodeId( digest );

        return newId;
    }



    /**
     * process command line args, set the security manager
     */
    private  void doInitstuff(String args[]) {
        // process command line arguments

        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-help")) {
                System.out.println("Usage: DistScribeRegrTest [-port p] [-protocol (rmi|wire)] [-bootstrap host[:port]] [-nodes n] [-help]");
                System.exit(1);
            }
        }

        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-port") && i+1 < args.length) {
                int p = Integer.parseInt(args[i+1]);
                if (p > 0) port = p;
                System.out.println("port --->" +port);
                break;
            }
        }

        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-bootstrap") && i+1 < args.length) {
                String str = args[i+1];
                int index = str.indexOf(':');
                if (index == -1) {
                    bshost = str;
                    bsport = port;
                } else {
                    bshost = str.substring(0, index);
                    bsport = Integer.parseInt(str.substring(index + 1));
                    if (bsport <= 0) bsport = port;
                }
                break;
            }
        }

        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-nodes") && i+1 < args.length) {
                int n = Integer.parseInt(args[i+1]);
                if (n > 0) numNodes = n;
                break;
            }
        }

        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-protocol") && i+1 < args.length) {
                String s = args[i+1];
                System.out.println("The protocol is " +s);
                if (s.equalsIgnoreCase("wire"))
                    protocol = DistPastryNodeFactory.PROTOCOL_WIRE;
                else if (s.equalsIgnoreCase("rmi"))
                    protocol = DistPastryNodeFactory.PROTOCOL_RMI;
                else
                    System.out.println("ERROR: Unsupported protocol: " + s);

                break;
            }
        }

    }

    /**
     * Create a Pastry node and add it to pastryNodes. Also create a client
     * application for this node, and spawn off a separate thread for it.
     *
     * @return the PastryNode on which the Scribe application exists
     */
    public PastryNode makeScribeNode(int k)
    {
        NodeHandle bootstrap = getBootstrap();

        PastryNode pn =factory.newNode(bootstrap); // internally initiateJoins

        pastryNodes.addElement(pn);

        localNodes.addElement(pn.getNodeId());


        Credentials cred = new PermissiveCredentials();


        Scribe scribe = new Scribe(pn, cred );

        scribe.setTreeRepairThreshold(3);




        app = new DistScribeRegrTestApp(pn, scribe, cred, this);
        int i = 0;
        distClients.addElement(app);


        return pn;

    }

    /**
     * Usage: MultiStarter [-nodes n] [-port p] [-bootstrap bshost[:bsport]] [-protocol [wire,rmi]]
     *                      [-help].
     *
     * Ports p and bsport refer to WIRE/RMI port numbers (default = 5009).
     * Without -bootstrap bshost[:bsport], only localhost:p is used for bootstrap.
     */
    public void startProtocol(String args[], boolean isStarter)
    {
        int seed;

        System.out.println("\n\nEnter the name of the file");
        DataInputStream dis=new DataInputStream(new BufferedInputStream(System.in));
        try
        {
          fileName= dis.readLine();
        }

        catch (IOException ex)
        {
        }

        PastryNode pn;
        fd.setFileName(fileName);
        Log.init(args);
        doInitstuff(args);
        System.out.println("\n Boot port "+ bsport);
        seed = (int)System.currentTimeMillis();
        PastrySeed.setSeed(seed);


        System.out.println("seed used=" + seed);
        MultiStarter driver = this;

        // create first node
        pn = driver.makeScribeNode(0);
        bshost = null;

        // We set bshost to null and wait till the first PastryNode on this host is ready so that the
        // rest of the nodes find a bootstrap node on the local host
        synchronized(pn)
        {
            while (!pn.isReady())
            {
                try
                {
                    pn.wait();
                }
                catch(InterruptedException e) {
                    System.out.println(e);
                }
            }
        }

        //firasath's code
        if(isStarter)
        { FileSplit.splitFile(fileName,fd);
          //Create a Central Group with file name as topic where the new members join and get the file details
          driver.app.m_topics.add(generateTopicId(fd.getFileName( )));
          driver.app.m_logTable.put(generateTopicId(fd.getFileName( )), new DistTopicLog());
          //driver.app.create(generateTopicId(fd.getFileName( )));
          //driver.app.join(generateTopicId(fd.getFileName() ));

          m_topicMap.put(generateTopicId(fd.getFileName()),new Integer(1) );

          Publisher aPublisher = new Publisher(driver,-1,true);
          m_PublisherThreadsMap.put(fd.getFileName(),aPublisher);
          new Thread(aPublisher).start();


          driver.NUM_TOPICS = fd.getNumberOfPieces();
          for ( int i = 0; i < driver.NUM_TOPICS;i++ )
          {
            //driver.app.create(generateTopicId(new String(fd.getFileName() + i)));
            //driver.app.join(generateTopicId(new String(fd.getFileName()+ i)));

            //System.out.println("Creating group\t "+ generateTopicId(new String(fd.getFileName()+ i)) );
            m_topicMap.put(generateTopicId(new String(fd.getFileName() + i)),new Integer(1) );
            Publisher a2Publisher = new Publisher(driver,i,true);
            m_PublisherThreadsMap.put(fd.getFileName()+i,a2Publisher);
            new Thread(a2Publisher).start();
          }
          //driver.app.create(generateTopicId(new String(fd.getFileName() + i )));
          //System.out.println("create Topic "+ generateTopicId(new String("Topic "+i) ));

          //app.create(generateTopicId(new String("Topic "+i)));
          //System.out.println("create Topic "+ generateTopicId(new String("Topic "+i) ));

          //app.create(generateTopicId(new String("Topic "+i)));
          //System.out.println("create Topic "+ generateTopicId(new String("Topic "+i) ));
        }
        else
        {
          //first join the topic filename and to get the details of the file
          System.out.println("JOIN ADD -->"+generateTopicId(new String(fileName)));
         /* app.m_topics.add(generateTopicId(new String(fileName)));
          app.m_logTable.put(generateTopicId(new String(fileName)), new DistTopicLog());*/

          m_topicMap.put(generateTopicId(fd.getFileName()),new Integer(1) );
          Publisher aPublisher = new Publisher(driver,-1,false);
          m_PublisherThreadsMap.put(fd.getFileName(),aPublisher);
          new Thread(aPublisher).start();

   //      app.join(generateTopicId(new String(fileName)));

    //      String joinMessage=BaylorMessage.createJoinMessage(generateTopicId(new String(fileName)).toString());
     //     app.multicast(generateTopicId(new String(fileName)),joinMessage);



          while(isInitialized()!=true)
          {
          }

          //Join all the groups and start listening
          for(int i=0;i<myFileDetails.getNumberOfPieces();i++)
          {
            m_topicMap.put(generateTopicId(new String(fd.getFileName() + i)),new Integer(1) );
            Publisher a2Publisher = new Publisher(driver,i,false);
            m_PublisherThreadsMap.put(fd.getFileName()+i,a2Publisher);
            new Thread(a2Publisher).start();

          //  TopicClient tC=new TopicClient(myFileDetails.getFileName()+i,driver);
           // new Thread(tC).start();
           System.out.println("\n\n\n\n6Joining -->"+i);
           String topicId=myFileDetails.getFileName()+i;
           /*app.m_topics.add(generateTopicId(topicId));
           app.m_logTable.put(generateTopicId(topicId), new DistTopicLog());*/
           //app.join(generateTopicId(topicId));

             //Join Message
          //  app.multicast(generateTopicId(topicId),
           // BaylorMessage.createJoinMessage(generateTopicId(topicId).toString()));


          }

          boolean life=true;

          while(life)
          {



          }





        }


        if (Log.ifp(5)) System.out.println(numNodes + " nodes constructed");
    }


    public void receiveMessage( ScribeMessage msg )
   {
       NodeId topicId;
       DistTopicLog topicLog;

       topicId = (NodeId) msg.getTopicId();

       System.out.println("\n\n\n\n\n\n\n\n\nMessage Received of Multi Cast" +msg.getData().toString());

       String message = msg.getData().toString();

       boolean flag=false;
       //check if its the initialization group
       if(topicId.equals(generateTopicId(fileName)))
       {
//          System.out.println("Init Group -->" + msg.getData().toString());
         flag=true;
          if(BaylorMessage.checkFileInfoMessage(message))
             {
             Map messageMap = BaylorMessage.parseFileInfoMessage(message);

             String gotFileName=(String)messageMap.get(BaylorMessage.fileNameStr).toString();
             System.out.println("FileName-->" +
                                messageMap.get(BaylorMessage.fileNameStr).toString());

             System.out.println("FileLen--->" +
                                messageMap.get(BaylorMessage.fileLengthStr).
                                toString());
            long gotFileLength=Long.parseLong(
            (String) messageMap.get(BaylorMessage.fileLengthStr).toString());

             System.out.println("PieceLen-->" +
                                messageMap.get(BaylorMessage.pieceLengthStr).
                                toString());
             int gotPieceLen=Integer.parseInt((String)
                                             messageMap.get(BaylorMessage.pieceLengthStr).toString());
             System.out.println("no Of pieces-->" +
                                messageMap.get(BaylorMessage.noOfPiecesStr).
                               toString());
            int gotNoOfPieces=Integer.parseInt((String)
                                     messageMap.get(BaylorMessage.noOfPiecesStr).toString());
            myFileDetails.setFileLength(gotFileLength);
            myFileDetails.setFileName(gotFileName);
            myFileDetails.setNumberOfPieces(gotNoOfPieces);
            myFileDetails.setPieceLength(gotPieceLen);
              setInitialized();
          }

          else
          {

            System.out.println("else " +message);

            //checking if vote request message
            if(BaylorMessage.checkVoteRequestMessage(message))
            {

              System.out.println("\n\n\n\n\n\n\n---->Vote request messge recd");

              //get the details
              Map m=BaylorMessage.getVoteRequestDetails(message);
              String topicID=(String)m.get(BaylorMessage.topicIDStr);

              //get the topic ID details
              String voteRep=BaylorMessage.createVoteReplyMessage(topicID,
               getNodeIDStr(),getWaitTime());

             System.out.println("\n\n\n\nSending node ID -->"+voteRep);
             app.multicast(generateTopicId(topicID),voteRep);

         flag=true;

            }



            //check if source select message
        if (BaylorMessage.checkSourceSelectedMessage(message))
            {
              Map m=BaylorMessage.getSourceSelectedMessage(message);
              if(getNodeIDStr().toString().equals( (String) m.get(BaylorMessage.nodeIDStr)))
              {
                String top=(String)m.get(BaylorMessage.topicIDStr);
                System.out.println("Source Selected for "+ (String)m.get(BaylorMessage.topicIDStr));
                System.out.println("Count "+ (String)m.get(BaylorMessage.countStr));
                         flag=true;

                Publisher p=(Publisher)(m_PublisherThreadsMap.get(top));
                p.setAmSource();
              }
            }


          }


       }

       boolean jFlag = BaylorMessage.checkJoinMessage(msg.getData().toString(),topicId.toString()   );
      System.out.println("New member joined\t"+ jFlag);
      if (jFlag)
      {
        incrementNumberOfMembers(topicId);
        jFlag = false;
      }

        boolean vFlag = BaylorMessage.checkVoteReplyMessage(msg.getData().
            toString());

        if (vFlag)
        {

          Map newMap = new HashMap();
          newMap = BaylorMessage.getVoteReplyDetails(msg.getData().toString());



          String topicName = (String)newMap.get(BaylorMessage.topicIDStr);

          System.out.println("\n\nVOte reply "+(String)newMap.get(BaylorMessage.waitTimeStr));
          long waitTime=Long.parseLong((String)newMap.get(BaylorMessage.waitTimeStr));
          Long tempTime = new Long(-100);
          topicId = generateTopicId(topicName);

          tempTime = (Long) m_timerMap.get(topicId);
          if(tempTime == null ){
            tempTime = new Long(-100);
          }
          if ( tempTime.longValue()  < waitTime )
          {
            m_timerMap.put(topicId,new Long(waitTime)) ;
            m_sourceMap.put(topicId,(String)newMap.get(BaylorMessage.nodeIDStr));
          }




          vFlag = false;

        }

//         System.out.println("\n\n\n Message"+message);//+msg.getData().toString()+"for Topic"+msg.getTopicId().toString());

         if(BaylorMessage.checkDataMessage(message))
        {

              Map m= BaylorMessage.getDataFromMessage(message);
           System.out.println("\n\n\n got data for "+ (String)m.get(BaylorMessage.pieceIDStr));
      //      System.out.println("data  "+ (String)m.get(BaylorMessage.dataStr));
            m.put( new Integer((String)m.get(BaylorMessage.pieceIDStr)),(String)m.get(BaylorMessage.dataStr));
            String saveFile= fileName;
            DataOutputStream outSte = null;
 System.out.println("\n\n Got piece "+message);
            PrintWriter ps=null;

            try {
              ps= new PrintWriter((new FileOutputStream(saveFile)));
            }
            catch (FileNotFoundException ex) {
            }
    // fileOut.writeTo(outSte);
       for(int i=0;i<myFileDetails.getNumberOfPieces();i++)
       {
         Integer pInd=new Integer(i);


         String s = (String)m.get(pInd);
         if(s!=null)
         {
             fd.setPiece(pInd.intValue(),s);
              System.out.println("\nWriting ");
              ps.write(s);


         }
       }

        ps.flush();
        ps.close();


     }



   }

   /**
    * check if it got the initialization details
    * @return
    */
   private boolean isInitialized()
   {
     return initialized;
   }

   /**
    * sets the flag which says it got the initialization message containing
    * the file details
    */
   private void setInitialized()
   {
     initialized=true;
   }

   /**
    *increments the wait time
    */


   /**
    * resets the wait time
    */
   public void resetWaitTime()
   {
     waitDate=new Date();
   }
   /**
    * gets the waitTime
    * @return
    */
   public long getWaitTime()
   {
     long t1= waitDate.getSeconds();
     Date tempDate=new Date();
     long t2 = tempDate.getSeconds();
     return t2-t1;


//    return 0;
   }

   /**
    * get node ID as string
    * @return
    */
   public String getNodeIDStr()
   {

     return app.getNodeId().toString();
   }
   public void incrementNumberOfMembers(NodeId topicId)
   {

     Integer i =(Integer) m_topicMap.get(topicId);
     m_topicMap.put(topicId,new Integer( i.intValue() + 1));
     System.out.println("Incrementing the number of members for \t"+topicId+"\t"+i.intValue()  );

   }
   public int getNumberOfMembers(NodeId topicId) {
     Integer i =(Integer) m_topicMap.get(topicId);
     return i.intValue();
   }

   public String getSource(NodeId topicID) {

     return (String)m_sourceMap.get(topicID);
   }

   public boolean checkIfSource(String topiCName){

     return true;
   }

}









