package rice.scribe.testing;

import java.util.StringTokenizer;
import java.util.Map;
import java.util.HashMap;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public  class BaylorMessage
{

  public static final String delim = ";";
  public static final String joinStr = "OurJOIN";
  public static final String fileInfoMessageStr = "FileInfoMessage";
  public static final String fileNameStr = "FileName";
  public static final String fileLengthStr = "FileLength";
  public static final String pieceLengthStr = "PieceLength";
  public static final String noOfPiecesStr = "NoOfPieces";
  public static final String voteRequestStr = "VoteRequest";
  public static final String voteReplyStr = "VoteReply";
  public static final String ipAddrStr = "ipAddress";
  public static final String portStr = "port";
  public static final String waitTimeStr = "waitTime";
  public static final String topicIDStr = "topicID";
  public static final String nodeIDStr = "nodeID";
  public static final String countStr = "countID";
  public static final String selectStr = "Sourceselected";
  public static final String pieceIDStr = "pieceId";
  public static final String dataStr="dataStr";


  public static String createJoinMessage(String groupName)
  {
    return joinStr+delim+groupName;
  }

  /**
   * check join message
   * @param m
   * @param groupName
   * @return
   */
  public static boolean checkJoinMessage(String m,String groupName)
  {
    StringTokenizer st=new StringTokenizer(m,delim);
    if(st.hasMoreTokens())
    {
      if( ((String)st.nextToken()).equalsIgnoreCase(joinStr))
      {
        if(st.hasMoreTokens())
        {
          String gName=(String)st.nextToken();
          if(gName.equals(groupName))
          {
            return true;

          }
        }

      }
    }

    return false;


  }
  /**
   * create File Info Message
   * @param fileName
   * @param fileLength
   * @param pieceLength
   * @param noOfPieces
   * @return
   */
  public  static String createFileInfoMessage(String fileName, long fileLength, int pieceLength, int noOfPieces )
  {
    String message=fileInfoMessageStr+delim+fileNameStr+delim+fileName
                 +delim+fileLengthStr+delim+fileLength+
                 delim+pieceLengthStr+delim+pieceLength+
                 delim+noOfPiecesStr+delim+noOfPieces;
    return message;
  }

  /**
   * checks if it is a file info message
   * @param m
   * @return
   */
  public static boolean checkFileInfoMessage(String m)
  {
    StringTokenizer st=new StringTokenizer(m,delim);
   if(st.hasMoreTokens())
   {
     if ( ((String) st.nextToken()).equalsIgnoreCase(fileInfoMessageStr))
     {
       return true;
     }
   }
   return false;
  }

  /**
   * parses the file info message and returns them in a  map
   * @param m
   * @return
   */
  public static Map parseFileInfoMessage(String m)
  {
    Map messageMap=new HashMap();

    StringTokenizer st=new StringTokenizer(m,delim);
    if(st.hasMoreTokens())
    {
      if ( ((String) st.nextToken()).equalsIgnoreCase(fileInfoMessageStr))
      {

            if(st.hasMoreTokens())
            {
              //get the file name
              if ( ((String) st.nextToken()).equalsIgnoreCase(fileNameStr))
              {

                   messageMap.put(fileNameStr,(String)st.nextToken());
              }

            }
            if(st.hasMoreTokens())
            {

              //get the file length string
              if ( ((String) st.nextToken()).equalsIgnoreCase(fileLengthStr))
              {
                messageMap.put(fileLengthStr, (String)st.nextToken());
              }
            }
            if(st.hasMoreTokens())
           {
             //get the piece length string
             if ( ((String) st.nextToken()).equalsIgnoreCase(pieceLengthStr))
             {
               messageMap.put(pieceLengthStr, (String)st.nextToken());
             }
           }
           if(st.hasMoreTokens())
         {
           //get the number of pieces string
           if ( ((String) st.nextToken()).equalsIgnoreCase(noOfPiecesStr))
           {
             messageMap.put(noOfPiecesStr, (String)st.nextToken());
           }
         }



      }
    }


    return messageMap;
  }

  /**
   * returns a vote request message
   * @param ipAddr
   * @param port
   */
  public static String requestVoteMessge(String topicID)
  {
    return
        voteRequestStr + delim +
        topicIDStr + delim + topicID;
  }

  /**
   * checks if it is a vote request message
   * @param message
   * @return
   */
  public static boolean checkVoteRequestMessage(String message)
  {
    StringTokenizer st=new StringTokenizer(message,delim);
   if(st.hasMoreTokens())
   {
     if ( ((String) st.nextToken()).equalsIgnoreCase(voteRequestStr))
     {
       return true;
     }
   }
   return false;

  }

  /**
   * checks if it is a vote request message
   * @param message
   * @return
   */
  public static boolean checkVoteReplyMessage(String message)
  {
    StringTokenizer st=new StringTokenizer(message,delim);
   if(st.hasMoreTokens())
   {
     if ( ((String) st.nextToken()).equalsIgnoreCase(voteReplyStr))
     {
       return true;
     }
   }
   return false;

  }

  /**
   * this function gets the details of the vote request message in a map
   * and returns them
   *
   * @param message
   * @return
   */
  public static Map getVoteRequestDetails(String message)
  {

    Map messageMap=new HashMap();

    StringTokenizer st=new StringTokenizer(message,delim);
    if(st.hasMoreTokens())
    {
      if (((String) st.nextToken()).equalsIgnoreCase(voteRequestStr))
      {

        //get the ip address
        if(st.hasMoreTokens())
        {
          if ( ((String) st.nextToken()).equalsIgnoreCase(topicIDStr))
          {
            messageMap.put(topicIDStr,(String)st.nextToken());
          }
        }

      }


    }

    return messageMap;
  }

  /**
   * Creates a vore reply message
   * @param waitTime
   * @return
   */
  public static String createVoteReplyMessage(String tID,String nID,long waitTime)
  {
    return voteReplyStr+delim
        +topicIDStr+delim+tID+delim
        +nodeIDStr+delim+nID+delim
        +waitTimeStr+delim  +waitTime;
  }

  /**
   * returns the time given the message
   * @param m
   * @return
   */
  public static Map getVoteReplyDetails(String message)
   {

     Map messageMap=new HashMap();

     StringTokenizer st=new StringTokenizer(message,delim);
     if(st.hasMoreTokens())
     {
       if (((String) st.nextToken()).equalsIgnoreCase(voteReplyStr))
       {

         //get the topicID
         if(st.hasMoreTokens())
         {
           if ( ((String) st.nextToken()).equalsIgnoreCase(topicIDStr))
           {
             messageMap.put(topicIDStr,(String)st.nextToken());
           }
         }
         if(st.hasMoreTokens())
         {
           if ( ((String) st.nextToken()).equalsIgnoreCase(nodeIDStr))
           {
             messageMap.put(nodeIDStr,(String)st.nextToken());
           }
         }

         if(st.hasMoreTokens())
        {
         if ( ((String) st.nextToken()).equalsIgnoreCase(waitTimeStr))
         {
           messageMap.put(waitTimeStr,(String)st.nextToken());
         }
       }


       }


     }

     return messageMap;
   }
   /**
    * create a source selectd message with the string id
    * @param nID
    * @return
    */
   public static String createSourceSelectedMessage(String nID,String tID, int count)
   {
     return selectStr+delim+
                 nodeIDStr+delim+nID+delim+
                 topicIDStr+delim+tID+delim+
                 countStr+delim+count;
   }

   /**
    * get the source selected message
    * @param message
    * @return
    */
   public static Map getSourceSelectedMessage(String message)
   {
     Map messageMap=new HashMap();

    StringTokenizer st=new StringTokenizer(message,delim);
    if(st.hasMoreTokens())
    {
      if ( ( (String) st.nextToken()).equalsIgnoreCase(selectStr)) {

        //get the topicID
        if (st.hasMoreTokens()) {
          if ( ( (String) st.nextToken()).equalsIgnoreCase(nodeIDStr)) {
            messageMap.put(nodeIDStr, (String) st.nextToken());
          }
        }
        if (st.hasMoreTokens()) {
          if ( ( (String) st.nextToken()).equalsIgnoreCase(topicIDStr)) {
            messageMap.put(topicIDStr, (String) st.nextToken());
          }
        }
        if (st.hasMoreTokens()) {
        if ( ( (String) st.nextToken()).equalsIgnoreCase(countStr)) {
          messageMap.put(countStr, (String) st.nextToken());
        }
      }

      }
    }
    return messageMap;

   }
   /**
    * check if this is a source selected message
    * @param message
    * @return
    */
   public static boolean checkSourceSelectedMessage(String message)
    {
      Map messageMap = new HashMap();

      StringTokenizer st = new StringTokenizer(message, delim);
      if (st.hasMoreTokens())
      {
        if ( ( (String) st.nextToken()).equalsIgnoreCase(selectStr))
        {
          return true;
        }

      }
      return false;
    }

    /**
     * creates amd sends a data message
     * @param pieceID
     * @param data
     * @return
     */
    public static String createSendDataMessage(int pieceID,String data)
    {
      return pieceIDStr+delim+pieceID+delim+dataStr+delim+data;
    }

    /**
   * checks data message
   * @param pieceID
   * @param data
   * @return
   */
  public static boolean checkDataMessage(String dataMsg)
  {


    StringTokenizer st = new StringTokenizer(dataMsg, delim);
    if (st.hasMoreTokens()) {
      if ( ( (String) st.nextToken()).equalsIgnoreCase(pieceIDStr)) {
        return true;
      }

    }
    return false;
  }

  /**
   * returns the source selected
   * @param message
   * @return
   */
  public static Map getDataFromMessage(String message)
 {
   Map messageMap = new HashMap();

   StringTokenizer st = new StringTokenizer(message, delim);
   if (st.hasMoreTokens()) {
     if ( ( (String) st.nextToken()).equalsIgnoreCase(pieceIDStr)) {
       messageMap.put(pieceIDStr, (String) st.nextToken());
     }
   }

   if (st.hasMoreTokens()) {
     if (  ((String)st.nextToken()).equalsIgnoreCase(dataStr))
     {
       messageMap.put(dataStr, (String) st.nextToken());
     }
   }
   return messageMap;
 }






}