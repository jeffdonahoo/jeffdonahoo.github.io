package rice.scribe.testing;


import rice.pastry.NodeId;
import rice.MBTorrent.Constants;
import java.net.Socket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.net.ServerSocket;
import java.io.*;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class Publisher implements Runnable{


  MultiStarter m_multiStarter;
  int m_prevNumberOfMembers;
  int m_piece;

  NodeId m_topicId;
  String topicName;
  boolean amSource;
  boolean stop;
  String source;
  boolean m_starter;
  public Publisher(MultiStarter aMultiStarter, int piece,boolean starter ) {

    m_multiStarter = aMultiStarter;
    m_piece = piece;
    m_prevNumberOfMembers = 1;
    amSource = starter;
    stop = false;
    source = null;
    m_starter = starter;
  }

  public void run() {

    long timer = 0;
    String message=null;
    // If its the FileInfo Group generate topicID with only file name
    //Otherwise generate topicID associated by concatenating
    //the filename and the pieceID assigned to the thread
    if ( m_piece != -1 ) {
      topicName = new String(m_multiStarter.fd.
          getFileName() + m_piece);
      m_topicId = m_multiStarter.generateTopicId(topicName);
      if(m_starter)
      message = BaylorMessage.createSendDataMessage(m_piece,m_multiStarter.fd.getPiece(m_piece));
      //message = "you have joined";
    }
    else
     {
       topicName = new String(m_multiStarter.fd.getFileName() );
       m_topicId = m_multiStarter.generateTopicId( topicName);
       if(m_starter)
      message =  BaylorMessage.createFileInfoMessage(m_multiStarter.fd.getFileName(),m_multiStarter.fd.getFileLength(),m_multiStarter.fd.getPieceLength(),m_multiStarter.fd .getNumberOfPieces() ) ;
     }
   int currentNoMembers;

   //Add the topic to the topics Vector
   m_multiStarter.app.m_topics.add(m_topicId);
   m_multiStarter.app.m_logTable.put(m_topicId, new DistTopicLog());

   //Create the Topic and Join
   if (m_starter){
   m_multiStarter.app.create(m_topicId);
    m_multiStarter.app.join(m_topicId);
   }
   else {
     m_multiStarter.app.join(m_topicId);
     String joinMessage=BaylorMessage.createJoinMessage(m_topicId.toString());
     m_multiStarter.app.multicast(m_topicId,joinMessage);
   }





   //Run untill Stopped
   while(!stop) {
     //If the localNode is the Source/Publisher
     //Check if there is a new member who joined since the last upload
     //If so multicast the piece

     while (amSource) {
       currentNoMembers = m_multiStarter.getNumberOfMembers(m_topicId);
       //System.out.println("group =\t"+m_topicId.toString() +"\tPrev =\t"+m_prevNumberOfMembers+"\tCu=\t"+currentNoMembers);
       if (currentNoMembers > m_prevNumberOfMembers)
       {
         m_prevNumberOfMembers = currentNoMembers;
         m_multiStarter.app.multicast(m_topicId, message);
       }

     //THis is the implementation of send TImer
     //where the source will wait for sendTimer to expire before uploading again

       try {
         Thread.sleep(Constants.sendTimer);

         //Increment the time for which this node has been the source
         timer = timer + Constants.sendTimer;
       }
       catch (InterruptedException ex) {
         System.out.println("Caught in the publisher " + m_topicId.toString() +
                            "\t" + ex.toString());
       }

       //If the source selection timer expires
       //Select a new source and ask him to become the source
       //and the local node will stop publishing
       if ( timer >= Constants.selectionTimer ) {

         System.out.println("-----------------Select source is being called-----------------------" );

         String tempSource = selectSource();
         if ( tempSource != null ){
           source = BaylorMessage.createSourceSelectedMessage(tempSource,
               topicName,m_prevNumberOfMembers);

           m_multiStarter.app.multicast(m_topicId, source);
           amSource = false;
           m_multiStarter.resetWaitTime();
         }

         timer = 0;
       }
     }
     //If i am not the source keep checking if i am selected as the source
     //If so switch to the publisher mode
     while(!amSource)
     {
       message =  BaylorMessage.createFileInfoMessage(m_multiStarter.fd.getFileName(),m_multiStarter.fd.getFileLength(),m_multiStarter.fd.getPieceLength(),m_multiStarter.fd .getNumberOfPieces() ) ;
     }
     if(!m_starter && amSource) {

     }

   }
  }

  public String selectSource() {
    Map voteRepMap = new HashMap();
    String voteRequest;

    voteRequest = BaylorMessage.requestVoteMessge(topicName);
    m_multiStarter.app .multicast(m_topicId,voteRequest);

    long start = System.currentTimeMillis();

    try {
      Thread.sleep(Constants.waitForVoteTime);
    }
    catch (InterruptedException ex) {
    }

     return m_multiStarter.getSource(m_topicId);


  }

  public String getVote(Socket newSocket) {
    DataInputStream in = null;
    try {
   in = new DataInputStream(new BufferedInputStream(newSocket.getInputStream()));
    }
    catch (IOException ex) {
    }
    String voteReply = null;
    try {
      voteReply = in.readLine();
    }
    catch (IOException ex1) {
    }
    return voteReply;
  }

  public void setAmSource()
  {
    amSource=true;
  }

}
