package rice.MBTorrent;

import java.util.Map;
import java.util.HashMap;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class FileSplit {


  public static Map splitFile(String fname,FileDetails fd) {
  Map pieceMap = new HashMap();

  fd.setFileName(fname);
  long FileLength = 0;

  BufferedInputStream bis = null;
  try {
    File inputFile = new File(fname);
    FileInputStream fis = new FileInputStream(inputFile);
    bis = new BufferedInputStream(fis);
    FileLength = inputFile.length() ;
    fd.setFileLength(FileLength) ;
  }
  catch (Exception e) {
    System.out.println("Error in Tracker File reading " + e.toString());

  }


  byte[] byteFile= new byte[(int)FileLength];
  try {

    bis.read(byteFile);
  }
  catch (IOException ex) {
  System.out.println( "Caught while reading the file " + ex.toString() );
}
 fd.setPieceLength(Constants.pieceLength);
  byte[] piece = null;
  int currentPieceLength;
  int k;
  int i;
  for ( k = 0,i = 0; i < byteFile.length; i = i +  fd.getPieceLength()  ) {
     currentPieceLength = fd.getPieceLength();
    if (i + currentPieceLength > byteFile.length) {
      currentPieceLength = byteFile.length - i ;
    }
    piece = new byte[currentPieceLength];
    for ( int j = i ; j < i + currentPieceLength; j++ ) {
    piece[j-i] = byteFile[j];
    }
    //String pieceString = new String ( piece );
    //System.out.println("Piece " + k + " " + pieceString);
    pieceMap.put(new Integer(k), piece);
    k++;
  }
  fd.setPieces(pieceMap);
  fd.setNumberOfPieces(k);
  return pieceMap;
}
}


