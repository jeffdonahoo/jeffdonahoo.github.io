package rice.MBTorrent;

import java.util.Map;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class FileDetails {

  private String fileName;
  private long fileLength;
  private int pieceLength;
  private int numberOfPieces;
  private Map pieces;
  public FileDetails() {
    fileName = null;
    fileLength = -1;
    pieceLength = -1;
    numberOfPieces = -1;
    pieces = null;
  }

  public String getFileName() {
    return fileName;
  }
  public long getFileLength() {
      return fileLength;
    }
  public int getPieceLength() {
      return pieceLength;
 }
 public int getNumberOfPieces() {
       return numberOfPieces;
     }
 public Map getPieces() {
   return pieces;
 }


 public void setFileName( String aFName) {
   fileName = aFName;
 }

 public void setFileLength(long aFileLength) {
   fileLength = aFileLength;
 }
 public void setPieceLength(int aPieceLength) {
  pieceLength = aPieceLength;
 }
 public void setNumberOfPieces(int aNumberOfPieces) {
 numberOfPieces =aNumberOfPieces;
 }

 public void setPieces(Map aPieces) {
   pieces = aPieces;
 }

 public String toString() {
   return fileName+":"+fileLength +":"+pieceLength+":"+numberOfPieces;
 }
  public String getPiece(int aPieceId)
  {
   byte[] aPiece;
   aPiece = (byte[])pieces.get(new Integer(aPieceId));
   return new String(aPiece);
}

public void setPiece(int aPieceid,String aPiece)
 {
   pieces.put(new Integer(aPieceid),aPiece.getBytes() );

}


}
