package rice.MBTorrent;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class Constants {
  public static final int pieceLength = 10000;
  public static final long sendTimer = 5000;
  public static final long selectionTimer = 50000;
  public static final int serverPort = 2000;
  public static final long waitForVoteTime = 5000;
  public static final String bootStrapVal="ICPCRES5.ecs.baylor.edu:5009";
}
