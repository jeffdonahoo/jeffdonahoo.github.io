package rice.scribe.testing;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class TopicClient implements Runnable{
  String topicId;
  MultiStarter m_driver;
  public TopicClient(String topic, MultiStarter driver)
  {
    topicId=topic;
    m_driver=driver;
  }
  public void run()
  {
    System.out.println("Thread for " + topicId);
     m_driver.app.join(m_driver.generateTopicId(topicId));

     //Join Message
     m_driver.app.multicast(m_driver.generateTopicId(topicId),
                            BaylorMessage.createJoinMessage(m_driver.generateTopicId(topicId).toString())         );

    while(true)
    {




    }

  }


}