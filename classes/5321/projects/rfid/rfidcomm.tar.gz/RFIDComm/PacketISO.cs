using System;

namespace RFIDencode
{
	/// <summary>
	/// Stub for eventual expansion to support ISO command packets
	/// </summary>
	public class PacketISO :Packet 
	{
		public PacketISO() : base((byte[])null)
		{
		}
	}
}
