using System;
using System.IO;
using System.Text ;

namespace RFIDencode
{
	/// <summary>
	/// Read_Single_Block reads a single block from the reader.
	/// Inherits from PackettagIt
	/// @author : Jeff Wilson
	///			: Ashish Vashishta
	/// </summary>
    public class Read_Single_Block : PackettagIt
	{
		/// <summary>
		/// Default constructor
		/// </summary>
		public Read_Single_Block() : this(null,(byte)TagIt_Commands.Read_Single_Block,(byte)0)
		{
		}

		/// <summary>
		/// Constructor invoked by deserialize()
		/// <param name="byteBuffer">byte[]</param>
		/// <param name="cmd">byte</param>
		/// <param name="cf">byte</param>
		/// <returns>PackettagIt</returns>
		/// </summary>
		public Read_Single_Block( byte[] byteBuffer, byte cmd, byte cf ) : base(byteBuffer,cmd,cf)
		{
			if( byteBuffer == null )
			{
				; // do nothing
			}
			// check if it is request addressed mode.
			else if ( CommandFlag == (byte) Command_Flags.Request_Addressed_Mode
				&& LengthOfPacket == (short)
									((int)Request_Size_Constants.Read_Single_Block_Addressed +
									 (int)Packet_Header.HEADER_SIZE +
									 (int)Packet_Header.LRC_SIZE) )
			{
				// addressed mode.
				PType = Packet_Type.Request;
				// throw an exception if the buffer is not the expected length
				if( byteBuffer.Length != (int)
					((int)Request_Size_Constants.Read_Single_Block_Addressed +
					 (int)Packet_Header.HEADER_SIZE +
					 (int)Packet_Header.LRC_SIZE) ) 
				{
					throw new IOException("Read_Single_Block encountered unexpected data format when trying to determine Transponder ID");
				}
				// read txPonderID from byteBuffer, LSB is first
				TxPonderID = 0;
				// start with MSB and go towards LSB, multiplying by 0x100 as you go
				for(int i=10;i>6;i--)
				{
					TxPonderID = TxPonderID * 0x100 + (uint) byteBuffer[i];
				}
				// read blockNum from byteBuffer, LSB first
				blockNum = byteBuffer[11];
			}
				//check for request non addressed mode.
			else if ( CommandFlag != (byte) Command_Flags.Request_Addressed_Mode
				&& LengthOfPacket == (short)
								((int)Request_Size_Constants.Read_Single_Block_Nonaddressed +
								 (int)Packet_Header.HEADER_SIZE +
								 (int)Packet_Header.LRC_SIZE))
			{
				// NON-ADDRESSED mode
				PType = Packet_Type.Request;
				// throw an exception if buffer is not expected length
				if( byteBuffer.Length != (int)
								((int)Request_Size_Constants.Read_Single_Block_Nonaddressed +
								 (int)Packet_Header.HEADER_SIZE +
								 (int)Packet_Header.LRC_SIZE))
				{
					throw new IOException("Read_Single_Block encountered unexpected data format when trying to read block address");
				}
				// read block number from pos 7
				blockNum = byteBuffer[7];
			}
			//check to see if response packet
			else if ( LengthOfPacket == (short)
								((int)Response_Size_Constants.Read_Single_Block +
								 (int)Packet_Header.HEADER_SIZE +
								 (int)Packet_Header.LRC_SIZE))
			{
				PType = Packet_Type.Response;
				//if command flag is set to 1 indicates error.
				if ( CommandFlag == (byte) Command_Flags.Response_Command_Flag_Error)
				{
					// throw new IOException( read single block operation returned an error )
					throw new IOException("Read_Single_Block encountered error flag in response packet");
				}
				else
				{
					if( byteBuffer.Length != (int)
								((int)Response_Size_Constants.Read_Single_Block +
								 (int)Packet_Header.HEADER_SIZE +
								 (int)Packet_Header.LRC_SIZE))
					{
						throw new IOException("Read_Single_Block encountered unexpected data format when trying to read block data");
					}
					// blockData gets the next four bytes of data 
					BlockData = new byte[4];
					Array.Copy(byteBuffer,7,BlockData,0,4);
					LockStatus = byteBuffer[11];
					BlockNum = byteBuffer[12];
				}
			}
			else 
				// unrecognized packet format
			{
				throw new IOException("Read Single Block failed to interpret byte stream");
			}
		}
		override public byte[] serialize()
		{
			MemoryStream ms = new MemoryStream((int)Packet_Header.MAX_PACKET_SIZE);
			serialize(ms);
			return ms.ToArray();
		}
		/// <summary>
		/// Overrides the ToString() method.
		/// <returns>String</returns>
		/// </summary>
		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();
			sb.AppendFormat("Read_Single_Block (0x{0:X2})\n",Command);
			switch(PType)
			{
				case Packet_Type.Request:
					//append Request
					sb.Append(" [Request]\n");
					//append tranponder ID
					sb.Append(" Transponder ID: ");
					try
					{
						sb.Append(TxPonderID);
					}
					catch
					{
						sb.Append("(not set)");
					}
					sb.Append("\n");
					sb.AppendFormat(" Block Number: {0}\n",BlockNum);
					break;
				case Packet_Type.Response:
					sb.Append(" [Response]\n");
					sb.AppendFormat(" Block Data: {0}\n",HexCon.ByteToString(BlockData));
					sb.AppendFormat(" Lock Status: {0}\n",LockStatus);
					sb.AppendFormat(" Block Number: {0}\n",BlockNum);
					break;
				case Packet_Type.Unknown:
				default:
					sb.Append(" badly formed packet\n");
					break;
			}
			return sb.ToString();
		}
		/// <summary>
		/// Method to serialize to the stream.
		/// <param name="sr">writeable Stream</param>
		/// </summary>
		new public void serialize( Stream sr )
		{
			// the buffer to store RSB specific bytes
			byte [] rsb = null;		
			// if packet type is not specified ...
			if( PType == Packet_Type.Unknown ) 
			{
				throw new ArgumentException("Read_Single_Block: must set packet type to Request or Response prior to serializing");
			}
			else if( PType == Packet_Type.Request ) 
			{
				// CommandFlag specifies ADDRESSED mode
				if( CommandFlag == (byte) Command_Flags.Request_Addressed_Mode )
				{
					rsb = new byte[(int)Request_Size_Constants.Read_Single_Block_Addressed];
					uint tid = TxPonderID;
					for(int i=0;i<(int)TagIt_Constants.Transponder_ID_Size;i++)
					{
						rsb[i] = (byte) (tid % 0x100);
						tid /= 0x100;
					}
					rsb[(int)TagIt_Constants.Transponder_ID_Size+1] = BlockNum;
				
					base.Buffer=rsb;
				}
				else  // NON_ADDRESSED mode
				{
					rsb = new byte[(int)Request_Size_Constants.Read_Single_Block_Nonaddressed];
					rsb[0] = BlockNum;

					base.Buffer=rsb;
				}
			}
			else /* PType == Packet_Type.Response */
			{
				int i = 0;
				rsb = new byte[(int)Response_Size_Constants.Read_Single_Block];
				// no byte shift, just straight copy
				Array.Copy(BlockData,0,rsb,0,BlockData.Length);
				i += BlockData.Length;
				rsb[i++]=LockStatus;
				rsb[i++]=BlockNum;

				base.Buffer=rsb;
			}
			base.serialize(sr);
		}
		/// <summary>
		/// Method to set the response error flag.
		/// </summary>
		public void SetResponseErrorFlag()
		{
			// if packet is not response packet throw an exception.
			if( PType != Packet_Type.Response ) 
			{
				throw new InvalidOperationException("Must set packet type to Response prior to calling SetResponseErrorFlag");
			}
			CommandFlag = (byte) Command_Flags.Response_Command_Flag_Error;
		}
	}
}
