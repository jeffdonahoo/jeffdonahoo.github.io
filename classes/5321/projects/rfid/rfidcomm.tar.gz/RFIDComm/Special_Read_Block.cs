using System;
using System.IO;
using System.Text ;

namespace RFIDencode
{
	/// <summary>
	/// Class to represent Special Read Block Tag-it command.  For request packets, set the bit mask 
	/// to indicate which (or all) of the eight blocks (four bytes each) to read.  For response packets,
	/// iterate through the eight item DataBlock[] array to read data block contents, data block number, 
	/// and lock status of a given data block.
	/// </summary>
	public class Special_Read_Block : PackettagIt
	{
		private DataBlock[] blocks = new DataBlock[8];
		/// <summary>
		/// Exposes the response packet's data blocks
		/// </summary>
		/// <param name="pos">(int) Zero based index into response packet's data block.
		/// Does not necessarily reflect data block number.  Depends on which data blocks
		/// were indicated by request packet's bit mask.</param>
		/// <returns>DataBlock</returns>
		public DataBlock getBlock( int pos )
		{
			if( blocks[pos] == null )
				return null;
			if( blocks[pos].BlockNumber > 0x7 )
				return null;	// never been set
			return blocks[pos];
		}
		/// <summary>
		/// Store a response packet's datablock
		/// </summary>
		/// <param name="db">DataBlock</param>
		public void setBlock( DataBlock db )
		{
			blocks[(int)db.BlockNumber] = db;
		}
		private byte bitmask = 0x00;
		/// <summary>
		/// Set this true for a request packet to read from block 0
		/// </summary>
		public bool ReadBlock0
		{ 
			get 
			{
				return (bitmask & 0x1) == 0x1;
			}
			set
			{
				bitmask |= 0x1;
			}
		}
		/// <summary>
		/// Set this true for a request packet to read from block 1
		/// </summary>
		public bool ReadBlock1
		{ 
			get 
			{
				return (bitmask & 0x2) == 0x2;
			}
			set
			{
				bitmask |= 0x2;
			}
		}
		/// <summary>
		/// Set this true for a request packet to read from block 2
		/// </summary>
		public bool ReadBlock2
		{ 
			get 
			{
				return (bitmask & 0x4) == 0x4;
			}
			set
			{
				bitmask |= 0x4;
			}
		}
		/// <summary>
		/// Set this true for a request packet to read from block 3
		/// </summary>
		public bool ReadBlock3
		{ 
			get 
			{
				return (bitmask & 0x8) == 0x8;
			}
			set
			{
				bitmask |= 0x8;
			}
		}
		/// <summary>
		/// Set this true for a request packet to read from block 0
		/// </summary>
		public bool ReadBlock4
		{ 
			get 
			{
				return (bitmask & 0x10) == 0x10;
			}
			set
			{
				bitmask |= 0x10;
			}
		}
		/// <summary>
		/// Set this true for a request packet to read from block 5
		/// </summary>
		public bool ReadBlock5
		{ 
			get 
			{
				return (bitmask & 0x20) == 0x20;
			}
			set
			{
				bitmask |= 0x20;
			}
		}
		/// <summary>
		/// Set this true for a request packet to read from block 6
		/// </summary>
		public bool ReadBlock6
		{ 
			get 
			{
				return (bitmask & 0x40) == 0x40;
			}
			set
			{
				bitmask |= 0x40;
			}
		}
		/// <summary>
		/// Set this true for a request packet to read from block 7
		/// </summary>
		public bool ReadBlock7
		{ 
			get 
			{
				return (bitmask & 0x80) == 0x80;
			}
			set
			{
				bitmask |= 0x80;
			}
		}
		/// <summary>
		/// Each bit of this byte represents a block of data (bit 0 = block 0, etc).  If this
		/// byte is 0x00, then only the transponder's SID is returned.
		/// </summary>
		public byte BitMask
		{
			get
			{
				return bitmask;
			}
			set
			{
				bitmask = value;
			}
		}

		/// <summary>
		/// Default constructor
		/// </summary>
		public Special_Read_Block() : this(null,(byte)TagIt_Commands.Special_Read_Block,(byte)0)
		{
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="byteBuffer">(byte[]) serialized byte array representing this packet</param>
		/// <param name="cmd">byte</param>
		/// <param name="cf">byte</param>
		public Special_Read_Block( byte[] byteBuffer, byte cmd, byte cf ) : base(byteBuffer,cmd,cf)
		{
			if( byteBuffer == null )
			{
				; // do nothing
			}			
			else if ( (LengthOfPacket == (short)((int)Request_Size_Constants.Special_Read_Block_Nonaddressed +
				(int)Packet_Header.HEADER_SIZE +
				(int)Packet_Header.LRC_SIZE)) &&
				CommandFlag == (byte)Command_Flags.Request_NonAddressed_Mode )
			{
				// NON-ADDRESSED mode
				PType = Packet_Type.Request;
				if( CommandFlag == (byte) Command_Flags.Request_Addressed_Mode )
				{
					// throw an exception?  this shouldn't happen
				}
				// throw an exception if buffer is not expected length
				if( byteBuffer.Length != (int)
					((int)Request_Size_Constants.Special_Read_Block_Nonaddressed +
					(int)Packet_Header.HEADER_SIZE +
					(int)Packet_Header.LRC_SIZE))
				{
					throw new IOException("Special_Read_Block encountered unexpected data format when trying to read block address");
				}
				int k = (int) Packet_Header.HEADER_SIZE;
				// read bit mask from pos 7
				BitMask = byteBuffer[k];
			}
				//check to see if response packet
			else if ( (LengthOfPacket == (short)((int)Response_Size_Constants.Special_Read_Block_SID_Only +
				(int)Packet_Header.HEADER_SIZE +
				(int)Packet_Header.LRC_SIZE) ) ||
				(LengthOfPacket == (short)((int)Response_Size_Constants.Special_Read_Block_One_Block +
				(int)Packet_Header.HEADER_SIZE +
				(int)Packet_Header.LRC_SIZE) ) ||
				(LengthOfPacket == (short)((int)Response_Size_Constants.Special_Read_Block_Two_Blocks+
				(int)Packet_Header.HEADER_SIZE +
				(int)Packet_Header.LRC_SIZE) ) ||
				(LengthOfPacket == (short)((int)Response_Size_Constants.Special_Read_Block_Three_Blocks +
				(int)Packet_Header.HEADER_SIZE +
				(int)Packet_Header.LRC_SIZE) ) ||
				(LengthOfPacket == (short)((int)Response_Size_Constants.Special_Read_Block_Four_Blocks +
				(int)Packet_Header.HEADER_SIZE +
				(int)Packet_Header.LRC_SIZE) ) ||
				(LengthOfPacket == (short)((int)Response_Size_Constants.Special_Read_Block_Five_Blocks +
				(int)Packet_Header.HEADER_SIZE +
				(int)Packet_Header.LRC_SIZE) ) ||
				(LengthOfPacket == (short)((int)Response_Size_Constants.Special_Read_Block_Six_Blocks +
				(int)Packet_Header.HEADER_SIZE +
				(int)Packet_Header.LRC_SIZE) ) || 
				(LengthOfPacket == (short)((int)Response_Size_Constants.Special_Read_Block_Seven_Blocks +
				(int)Packet_Header.HEADER_SIZE +
				(int)Packet_Header.LRC_SIZE) ) ||
				(LengthOfPacket == (short)((int)Response_Size_Constants.Special_Read_Block_Eight_Blocks +
				(int)Packet_Header.HEADER_SIZE +
				(int)Packet_Header.LRC_SIZE) ) )
			{
				PType = Packet_Type.Response;
				if( CommandFlag == (byte) Command_Flags.Response_Command_Flag_Error ) 
				{
					// throw new exception?
				}
				int k = (int) Packet_Header.HEADER_SIZE;
				// first, read TxPonderID
				// read txPonderID from byteBuffer, LSB is first
				TxPonderID = 0;
				// start with MSB and go towards LSB, multiplying by 0x100 as you go
				for(k=10;k>6;k--)
				{
					TxPonderID = TxPonderID * 0x100 + (uint) byteBuffer[k];
				}
				for(k = (int) Packet_Header.HEADER_SIZE + (int) TagIt_Constants.Transponder_ID_Size;
					k < LengthOfPacket - (int) Packet_Header.LRC_SIZE;
					k += 6)
					// each data block read from the transponder gives back 4 byte block, 1 lock status block,
					// and 1 byte block number
				{
					byte [] tmp = new byte[6];
					Array.Copy(byteBuffer,k,tmp,0,6);
					DataBlock db = new DataBlock(tmp);
					setBlock(db);
				}
			}
			else if ((LengthOfPacket == (short)((int) Response_Size_Constants.Special_Read_Block_Error+
				(int)Packet_Header.HEADER_SIZE +
				(int)Packet_Header.LRC_SIZE)))
			{
				PType = Packet_Type.Response;
				Array.Copy(byteBuffer,(int)Packet_Header.HEADER_SIZE,Buffer,0,1);
			}
		}

		/// <summary>
		/// Exposes this Packet, serialized to byte[].
		/// </summary>
		/// <returns>byte[]</returns>
		override public byte[] serialize()
		{
			MemoryStream ms = new MemoryStream((int)Packet_Header.MAX_PACKET_SIZE);
			serialize(ms);
			return ms.ToArray();
		}

		/// <summary>
		/// Method to override ToString().
		/// <returns>string</returns>
		/// </summary>
		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();
			sb.AppendFormat("Special_Read_Block (0x{0:X2})\n",Command);
			switch(PType)
			{
				case Packet_Type.Request:
					sb.Append(" [Request]\n");
					sb.Append("\n");
					sb.AppendFormat(" Bitmask: {0:X2}\n",BitMask);
					break;
				case Packet_Type.Response:
					sb.Append(" [Response]\n");
					sb.AppendFormat(" Transponder ID: {0:X8}\n\n",TxPonderID);
					for( int i = 0; i < 8; i++ )
					{
						DataBlock db = this.getBlock(i);
						if( db != null )
						{
							sb.AppendFormat(" Block Number: {0:X2}\n",db.BlockNumber);
							sb.AppendFormat(" Lock Status:  {0:X2}\n",db.LockStatus);
							sb.AppendFormat(" Block Data:   {0}\n\n",HexCon.ByteToString(db.Buffer));
						}
					}
					break;
				case Packet_Type.Unknown:
				default:
					sb.Append(" badly formed packet\n");
					break;
			}
			return sb.ToString();
		}

		/// <summary>
		/// Method to serialize to the stream.
		/// <param name="sr">writeable Stream</param>
		/// </summary>
		new public void serialize( Stream sr )
		{
			byte [] srb = null;		// the buffer to store SRB specific bytes
			// if packet type is not specified ...
			if( PType == Packet_Type.Unknown ) 
			{
				throw new ArgumentException("Special_Read_Block: must set packet type to Request or Response prior to serializing");
			}
			else if( PType == Packet_Type.Request ) 
			{
				// CommandFlag specifies ADDRESSED mode
				if( CommandFlag == (byte) Command_Flags.Request_Addressed_Mode )
				{
					// throw new exception?  should not be used (see manual)
				}
				else  // NON_ADDRESSED mode
				{
					srb = new byte[(int)Request_Size_Constants.Special_Read_Block_Nonaddressed];
					srb[0] = BitMask;
					base.Buffer=srb;
				}
			}
			else /* PType == Packet_Type.Response */
			{
				// TxPonderID always gets written
				int psize = (int) TagIt_Constants.Transponder_ID_Size;
				// set the buffer to max expected size ... shrink later
				srb = new byte[psize+(int)Response_Size_Constants.Special_Read_Block_Eight_Blocks];

				// write transponder ID .
				uint tid = TxPonderID;
				for(int i=0;i<(int)TagIt_Constants.Transponder_ID_Size;i++)
				{
					srb[i] = (byte) (tid % 0x100);
					tid /= 0x100;
				}

				// write out the valid data blocks
				for( int i = 0; i < 8; i++ )
				{
					DataBlock db = getBlock(i);
					if( db != null )
					{
						// increase known size by size of DataBlock
						psize += 6;
						// copy DataBlock buffer to outgoing buffer
						Array.Copy(db.GetDataBlock(),0,srb,psize-6,6);
					}
				}

				// push data into base class
				Array.Copy(srb,0,base.Buffer,0,psize);
			}
			// call base class serializer
			base.serialize(sr);
		}	
	}
}