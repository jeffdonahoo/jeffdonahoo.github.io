using System;
using System.IO;
using System.Text ;


namespace RFIDencode
{
	/// <summary>
	/// Class to read transponder details. inherits from PackettagIt
	/// </summary>
	public class Read_Transponder_Details : PackettagIt
	{
		private bool mnIsSet = false;
		private byte mfrNum;
		/// <summary>
		/// Response packets report the RFID's manufacturer number
		/// </summary>
		public byte MfrNum
		{
			get 
			{
				if( !mnIsSet ) 
				{
					throw new InvalidOperationException("MfrNum not set");
				}
				return mfrNum;
			}
			set
			{
				mnIsSet = true;
				mfrNum = value;
			}
		}

		private bool vnIsSet = false;
		private short verNum;
		/// <summary>
		/// Response packets report the RFID's version number.
		/// </summary>
		public short VerNum
		{
			get
			{
				if( !vnIsSet ) 
				{
					throw new InvalidOperationException("VerNum not set");		// value not set
				}
				return verNum;
			}
			set
			{
				vnIsSet = true;
				verNum = value;
			}
		}

		private bool nbIsSet = false;

		/// <summary>
		/// Response packets report the RFID's number of blocks
		/// </summary>
		private byte numBlocks;
		public byte NumBlocks
		{
			get
			{
				if( !nbIsSet ) 
				{
					throw new InvalidCastException("NumBlocks not set");		// value not set
				}
				return numBlocks;
			}
			set
			{
				nbIsSet = true;
				numBlocks = value;
			}
		}
		private bool bpbIsSet = false;

		/// <summary>
		/// Response packets report the number of bytes per block
		/// </summary>
		private byte bytesPerBlock;
		public byte BytesPerBlock
		{
			get
			{
				if( !bpbIsSet ) 
				{
					// value not set
					throw new InvalidOperationException("BytesPerBlock not set");		
				}
				return bytesPerBlock;
			}
			set
			{
				bpbIsSet = true;
				bytesPerBlock = value;
			}
		}
		/// <summary>
		/// Method to override ToString().
		/// <returns>string</returns>
		/// </summary>
		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();
			sb.AppendFormat("Read_Transponder_Details (0x{0:X2})\n",(byte)Command);
			switch(PType)
			{
				case Packet_Type.Request:
					sb.Append(" [Request]\n");
					break;
				case Packet_Type.Response:
					sb.Append(" [Response]\n");
					// append transponder ID.
					sb.AppendFormat(" TransponderID: {0:X8}\n",TxPonderID);
					// append manufacturer Number.
					sb.AppendFormat(" Manufacturers Number: {0:X2}\n",MfrNum);
					// append version Number.
					sb.AppendFormat(" Version Number: {0:X4}\n",VerNum);
					// append number of blocks.
					sb.AppendFormat(" Number of Blocks: {0:X2}\n",NumBlocks);
					// append bytes per block.
					sb.AppendFormat(" Bytes per block: {0:X2}\n",BytesPerBlock);
					break;
				case Packet_Type.Unknown:
				default:
					sb.Append(" badly formed packet\n");
					break;
			}
			return sb.ToString();
		}
		/// <summary>
		/// Default constructor.
		/// </summary>
		public Read_Transponder_Details() : base(null,(byte)TagIt_Commands.Read_Transponder_Details,(byte)0)
		{
			PType = Packet_Type.Unknown;
		}
		/// <summary>
		/// Constructor invoked by deserialize()
		/// <param name="buffer">byte[]</param>
		/// <param name="cmd">byte</param>
		/// <param name="cf">byte</param>
		/// </summary>

		public Read_Transponder_Details( byte[] buffer, byte cmd, byte cf )  : base(buffer,cmd,cf)
		{
			if( buffer == null ) 
			{
				;
			}
				// addressed request
			else if ( CommandFlag == (byte) Command_Flags.Request_Addressed_Mode &&
				LengthOfPacket == (short) 
				((int)Request_Size_Constants.Read_Transponder_Details_Addressed +
				(int)Packet_Header.HEADER_SIZE +
				(int)Packet_Header.LRC_SIZE) )
			{
				PType = Packet_Type.Request;
				// read txPonderID from byteBuffer, LSB is first
				TxPonderID = 0;
				// start with MSB and go towards LSB, multiplying by 0x100 as you go
				for(int i=10;i>6;i--)
				{
					TxPonderID = TxPonderID * 0x100 + (uint) buffer[i];
				}
			}
				//check for request non addressed mode
			else if ( CommandFlag == (byte) Command_Flags.Request_NonAddressed_Mode &&
				LengthOfPacket == (short) 
				((int)Request_Size_Constants.Read_Transponder_Details_Nonaddressed +
				(int)Packet_Header.HEADER_SIZE +
				(int)Packet_Header.LRC_SIZE) )
			{
				PType = Packet_Type.Request;
			}
				//check to see if response addressed/non addressed mode
			else if (LengthOfPacket == (short) 
				((int)Response_Size_Constants.Read_Transponder_Details +
				(int)Packet_Header.HEADER_SIZE +
				(int)Packet_Header.LRC_SIZE) ) 
			{
				PType = Packet_Type.Response;
				// see if command flag indicates error
				if ( CommandFlag == (byte) Command_Flags.Response_Command_Flag_Error )
				{
					;     // could throw exception here ... or just fail silently
				}
				else
				{
					// read txPonderID from byteBuffer, LSB is first
					TxPonderID = 0;
					// start with MSB and go towards LSB, multiplying by 0x100 as you go
					for(int i=10;i>6;i--)
					{
						TxPonderID = TxPonderID * 0x100 + (uint) buffer[i];
					}
					int k = 11;
					MfrNum = buffer[k++];
					VerNum = 0;
					// start with MSB and go towards LSB, multiplying by 0x100 as you go
					for(int i=13;i>11;i--)
					{
						VerNum = (short) (VerNum * 0x100 +  (int) buffer[i]);
					}
					k = 14;
					NumBlocks = buffer[k++];
					BytesPerBlock = buffer[k++];
				}
			}
			else if( LengthOfPacket == (short)
				((int)Response_Size_Constants.Read_Transponder_Details_Error +
				(int)Packet_Header.HEADER_SIZE +
				(int)Packet_Header.LRC_SIZE) )
			{
				PType = Packet_Type.Response;
				CommandFlag = (byte) Command_Flags.Response_Command_Flag_Error;
			}
		}
		/// <summary>
		/// Method to serialize to the stream.
		/// <param name="sr">writeable Stream</param>
		/// </summary>
		new public void serialize( Stream sr ) 
		{
			byte [] rtd = null;		// the buffer to store RTD specific bytes
			// if packet type is not specified ...
			if( PType == Packet_Type.Unknown ) 
			{
				throw new ArgumentException("Read_Transponder_Details: must set packet type to Request or Response prior to serializing");
			}
			else if( PType == Packet_Type.Request ) 
			{
				// CommandFlag specifies ADDRESSED mode
				if( CommandFlag == (byte) Command_Flags.Request_Addressed_Mode )
				{
					rtd = new byte[(int)Request_Size_Constants.Read_Transponder_Details_Addressed ];
					uint tid = TxPonderID;
					for(int i=0;i<(int)TagIt_Constants.Transponder_ID_Size;i++)
					{
						rtd[i] = (byte) (tid % 0x100);
						tid /= 0x100;
					}
					base.Buffer = rtd ;
				}
				else  // NON_ADDRESSED mode
				{
					Buffer = new byte[0] {};
					//do nothing. 
				}
			}
			else /* PType == Packet_Type.Response */
			{
				int i = 0;
				
				rtd = new byte[(int)Response_Size_Constants.Read_Transponder_Details ];
				
				uint tid = TxPonderID;
				for(i=0;i<(int)TagIt_Constants.Transponder_ID_Size;i++)
				{
					rtd[i] = (byte) (tid % 0x100);
					tid /= 0x100;
				}

				rtd[i++] = MfrNum;
				
				short vn = VerNum;
				rtd[i++] = (byte) ( vn % 0x100 );		// LSB
				rtd[i++] = (byte) ( vn / 0x100 );		// MSB
				
				rtd[i++] = NumBlocks;
				rtd[i++] = BytesPerBlock;

				base.Buffer = rtd;
			}
			base.serialize(sr);
		}

		/// <summary>
		/// Exposes this Packet, serialized to byte[].
		/// </summary>
		/// <returns>byte[]</returns>
		override public byte[] serialize()
		{
			MemoryStream ms = new MemoryStream((int)Packet_Header.MAX_PACKET_SIZE);
			serialize(ms);
			return ms.ToArray();
		}
	}
}