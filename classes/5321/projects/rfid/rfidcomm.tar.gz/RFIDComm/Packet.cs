using System;
using System.IO ;
using System.Text ;

///
/// 
///

/**
 * the packet structure for both request and response is :
 *					SOF  length  nodeaddress  commandFlags  Command  Data  BCC
 *  (no. of byte)	1	   2		2			1				1	  Var	2	
 */

namespace RFIDencode
{
	/// <summary>
	/// Packet is class at the top of RFID hierarchy
	/// @author : Wilson, Jeff
	///			: Vashishta, Ashish
	/// </summary>
	public abstract class Packet
	{
		/// <summary>
		/// Gets the value of command flag in response packet.
		/// </summary>
		public bool ResponseError
		{
			get
			{
				if( PType == Packet_Type.Response )
				{
					return (bool) (CommandFlag == (byte) Command_Flags.Response_Command_Flag_Error);
				}
				throw new InvalidOperationException("Response error is valid only on response packets");
			}
		}
		private byte[] buffer;
		/// <summary>
		/// Byte array that represents this packet (used by serialize()/deserialize()).
		/// </summary>
		public byte[] Buffer
		{
			get 
			{
				return buffer;
			}
			set 
			{
				// if value is empty set the buffer to null and set the buffer length to 0.
				if( value == null ) 
				{
					buffer = null;
					LengthOfPacket = (short) 0;
					return;
				}
				//otherwise copy the value to the buffer
				LengthOfPacket = (short) value.Length;
				buffer = new byte[value.Length];
				Array.Copy(value,0,buffer,0,value.Length);
			}
		}
		// when sending the length take care to send LSB first.
		private short lengthOfPacket;
		/// <summary>
		/// Number of bytes in this packet's byte array
		/// </summary>
		public short LengthOfPacket
		{
			get 
			{
				return lengthOfPacket;
			}
			set
			{
				if( value > (short) Packet_Header.MAX_PACKET_SIZE )
				{ 
					// could throw exception here ... or just fail silently
					return;    
				}
				lengthOfPacket = value;
			}
		}
		// Response or Request
		private Packet_Type pType = Packet_Type.Unknown;		
		/// <summary>
		/// Packet Type must be set to request or response before serializing.
		/// </summary>
		public Packet_Type PType
		{
			get
			{
				return pType;
			}
			set
			{
				// check if value is within legal range of Packet_Type enumeration
				if (!Enum.IsDefined (typeof(Packet_Type), value))
				{
					 // could throw exception here ... or just fail silently
					return;   
				}
				pType = value;
			}
		}
		private byte commandFlag = (byte) Command_Flags.Request_NonAddressed_Mode;
		/// <summary>
		/// Indicates addressed mode for Request packets, or error condition for 
		/// Response packets.
		/// </summary>
		public byte CommandFlag
		{
			get
			{
				// check if value is within legal range of Command_Flag enumeration
				if( ! Enum.IsDefined(typeof(Command_Flags),commandFlag ) )
				{
					throw new InvalidOperationException("CommandFlag has not been set");
				}
				return commandFlag;
			}
			set
			{
				// check if value is within legal range of Command_Flag enumeration
				if( ! Enum.IsDefined(typeof(Command_Flags),value ) )
				{
					// could throw exception here ... or just fail silently
					return;   
				}
				commandFlag = value;
			}
		}
		private byte command = (byte) Misc_Commands.Reader_Version;
		/// <summary>
		/// Indicates the action performed by this packet.
		/// </summary>
		public byte Command
		{
			get
			{
				// check if value is within legal range of TagIt_Commands, ISO_Commands, or Misc_Commands
				if( ! ( Enum.IsDefined(typeof(TagIt_Commands),command) ||
					Enum.IsDefined(typeof(ISO_Commands),command) ||
					Enum.IsDefined(typeof(Misc_Commands),command) ) ) 
				{
					throw new InvalidOperationException("\"Command\" is not a valid value");
				}
				return command;
			}
			set
			{
				// check if value is within legal range of TagIt_Commands, ISO_Commands, or Misc_Commands
				if( ! ( Enum.IsDefined(typeof(TagIt_Commands),value) ||
						Enum.IsDefined(typeof(ISO_Commands),value) ||
						Enum.IsDefined(typeof(Misc_Commands),value) ) ) 
				{
					// could throw exception here ... or just fail silently
					return;    
				}
				command = value;
			}
		}

		/// <summary>
		/// Default constructor.
		/// </summary>
		/// <param name=none></param>
		/// <returns>Packet object</returns>
		public Packet() : this(null) 
		{
		}

		/// <summary>
		/// Constructor used by deserialize(). Sets private members using byte encoding as documented
		/// by TI's document RI-STU-TRDC-02, document number 11-06-21-700.
		/// </summary>
		/// <param name="buffer">byte array containing RFID command</param>
		public Packet(byte[] buffer)
		{
			Buffer		= buffer;
			// set by Buffer
			// LengthOfPacket =	(short) buffer.Length;
			if( buffer != null ) 
			{
				CommandFlag = buffer[5];
				Command		= buffer[6];
			}
		}
		/// <summary>
		/// Serialize the command into a byte array.  Sub classes invoke this method
		/// after encoding their specific data into the data payload.
		/// </summary>
		/// <param name=srout>writeable stream</param>
		/// <returns>void</returns>
		public virtual void serialize(Stream srout)
		{
			LengthOfPacket = (short) (LengthOfPacket + 
							(int) Packet_Header.HEADER_SIZE +
							(int) Packet_Header.LRC_SIZE);
			// length of incoming buffer, packet header, LRC
			byte[] outbuff = new byte[Buffer.Length+(int)(Packet_Header.HEADER_SIZE)];
			int i = 0;
			// pack these 7 bytes into a new buffer
			// 1 byte - SOF, 2 bytes - Length , 2 bytes - NodeAddress,
			// 1 byte - CommandFlag , 1 byte - command
			outbuff[i++] = (byte) Packet_Header.SOF;
			outbuff[i++] = (byte) lengthOfPacket;
			outbuff[i++] = (byte) (lengthOfPacket >> 8) ;
			outbuff[i++] = (byte) Packet_Header.NODEADDRLSB;
			outbuff[i++] = (byte) Packet_Header.NODEADDRMSB;
			outbuff[i++] = commandFlag;
			outbuff[i++] = command;
			
			Array.Copy(buffer,0,outbuff,i,buffer.Length);
			i += buffer.Length;

			// compute the LRC check sum of the packet
			byte[] LRC = LRCCheckSum.checkLRC(outbuff);

			// shove out the buffer to the byte stream
			srout.Write(outbuff,0,outbuff.Length);

			// follow up with the LRC
			srout.Write(LRC,0,LRC.Length);
			// flush the stream.
			srout.Flush() ;
		}

		/// <summary>
		/// Override this function in sub classes to expose serialized byte array
		/// representing this command packet.
		/// </summary>
		/// <returns>byte[]</returns>
		public virtual byte[] serialize() { return buffer; }

		/// <summary>
		///  toString method is overridden to get corresponding packet
		///  depending on the type passed in as parameter.
		/// </summary>
		/// <returns>String</returns>
		public override string ToString()
		{
			System.Type t = this.GetType();
			if( t == System.Type.GetType("RFIDencode.Reader_Version") )
			{
				return ((Reader_Version)this).ToString();
			}
			else if( t == System.Type.GetType("RFIDencode.Read_Single_Block") )
			{
				return ((Read_Single_Block)this).ToString();
			}
			else if( t == System.Type.GetType("RFIDencode.Write_Single_Block") )
			{
				return ((Write_Single_Block)this).ToString();
			}
			else if( t == System.Type.GetType("RFIDencode.Read_Transponder_Details") )
			{
				return ((Read_Transponder_Details)this).ToString();
			}
			else if( t == System.Type.GetType("RFIDencode.Special_Read_Block") )
			{
				return ((Special_Read_Block)this).ToString();
			}
			// if non of the above, no more subclasses for the packet.
			else 
			{
				return "No subclass";
			}			
		}

		/// <summary>
		/// Invokes subclass serialization method of packet.
		/// </summary>
		/// <param name="p">Packet</param>
		/// <returns></returns>
		public static byte[] serialize( Packet p ) 
		{
			System.Type t = p.GetType();
			if( t == System.Type.GetType("RFIDencode.Reader_Version") )
			{
				return ((Reader_Version)p).serialize();
			}
			else if( t == System.Type.GetType("RFIDencode.Read_Single_Block") )
			{
				return ((Read_Single_Block)p).serialize();
			}
			else if( t == System.Type.GetType("RFIDencode.Write_Single_Block") )
			{
				return ((Write_Single_Block)p).serialize();
			}
			else if( t == System.Type.GetType("RFIDencode.Read_Transponder_Details") )
			{
				return ((Read_Transponder_Details)p).serialize();
			}
			else if( t == System.Type.GetType("RFIDencode.Special_Read_Block") )
			{
				return ((Special_Read_Block)p).serialize();
			}
			else 
			{
				// could throw exception here ... or just fail silently
				return null;    
			}
		}

		/// <summary>
		/// Static helper function to deserialize directly from byte array
		/// </summary>
		/// <param name="buffer">byte[] containing RFID packet</param>
		/// <returns>fully initialized Packet object</returns>
		public static Packet deserialize(byte[] buffer)
		{
			MemoryStream ms = new MemoryStream(buffer);
			return deserialize(ms);
		}

		/// <summary>
		/// Static helper function to deserialize from a stream
		/// </summary>
		/// <param name="sr">readable Stream</param>
		/// <returns>fully initialized Packet object</returns>
		public static Packet deserialize(Stream sr)
		{
			byte[] byteBuffer = new byte[(int)Packet_Header.MAX_PACKET_SIZE];

			//read SOF , length of the packet , node address.
			byteBuffer[0] = (byte)sr.ReadByte();
			int low = sr.ReadByte() & 0xff ;
			int high = sr.ReadByte() & 0xff ;
			byteBuffer[1] = (byte) low;
			byteBuffer[2] = (byte) high;
			short packetLength = (short)(high << 8 | low) ;

			// read in the rest of the packet from sr
			// shove into a byte array
			// verify that the last two bytes match our own BCC calculation
			//we have already read first three bytes.
			for(int i = 3 ; i < packetLength ; i++)
			{
				sr.Read(byteBuffer , i , (packetLength-3) );
			}

			byte[] deser = new byte[packetLength];
			Array.Copy(byteBuffer,0,deser,0,packetLength);

			// Read the check sum off the byte array from the stream
			byte[] readCheckSum = new byte[2];
			Array.Copy(deser,packetLength-2,readCheckSum,0,2);

			// Compute the check sum from all but the last two bytes of the entire byte stream
			byte[] allButTwo = new byte[deser.Length-2];
			Array.Copy(deser,0,allButTwo,0,deser.Length-2);
			byte[] checkSumOutput = LRCCheckSum.checkLRC(allButTwo);
			
			//if read checksum is not equal to the calculated checksum then throw an exception.
			if ( checkSumOutput[0] != readCheckSum[0] || 
				 checkSumOutput[1] != readCheckSum[1])
			{
				throw new IOException("Error : checksum failed validation");
			}
			//see packet structure above.
			byte command = byteBuffer[6] ;
			if (command == (byte)Packet_Header.ISOTAG)
			{
				//send this packet to the ISO commands set.
				//return PacketISO.deSerialize(sr,lengthRestPacket,command , commandFlags );
				return new PacketISO();
			}
			else
			{
				//send this packet to the TagIt commands set.
				return PackettagIt.deSerialize(deser,command);
			}
		}
	}
	/// <summary>
	/// Lifted without permission from http://www.aciss.com/justin/io.htm. 
	/// Helper class with static methods to convert binary
	/// byte arrays into ASCII strings, and vice versa.
	/// </summary>
	public class HexCon 
	{
		/// <summary>
		/// Converts InBytes into ASCII string that represents the original binary array
		/// </summary>
		/// <param name="InBytes"></param>
		/// <returns>System.string</returns>
		public static string ByteToString(byte[] InBytes) 
		{
			string StringOut="";
			foreach (byte InByte in InBytes) 
			{
				StringOut=StringOut + String.Format("{0:X2} ",InByte);
			}
			return StringOut.Remove(StringOut.Length-1,1); 
		}
		/// <summary>
		/// Converts InString from ASCII representation into binary byte array
		/// </summary>
		/// <param name="InString"></param>
		/// <returns>byte[]</returns>
		public static byte[] StringToByte(string InString) 
		{
			string[] ByteStrings = InString.Split(null);
			byte[] ByteOut = new byte[ByteStrings.Length];
			for (int i=0;i<ByteStrings.Length;i++) 
			{
				ByteOut[i] = Convert.ToByte(("0x" + ByteStrings[i]),16);
			} 
			return ByteOut;
		}
		/// <summary>
		/// Added by Jeff and Ashish.
		/// Reverses the bytes in a four byte buffer 
		/// </summary>
		/// <param name="fourBytes">byte[] of Length==4</param>
		/// <returns>byte[] in reverse byte order</returns>
		public static byte[] ReverseMSBFourBytes( byte[] fourBytes )
		{
			if( fourBytes.Length != 4 ) return null;
			byte tmp;
			for(int i=0;i<2;i++) 
			{
				tmp = fourBytes[i];
				fourBytes[i] = fourBytes[3-i];
				fourBytes[3-i] = tmp;
			}
			return fourBytes;
		}
	}
}


