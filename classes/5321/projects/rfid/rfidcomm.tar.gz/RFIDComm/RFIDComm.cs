using System;
using System.IO;
using JH.CommBase;
using RFIDencode;
using System.Threading;

/* CommBase allows for a wide variety of serial communications.  Since this RFID reader, the S6350,
 * is master/slave driven by a host PC; all packets are encapsulated; and, the reader only responds
 * to requests from the host PC, then I have used the Transaction model.  This sends a packet, then 
 * blocks until a response packet returns, or the default timeout is hit.
 */
namespace RFIDComm
{
	/// <summary>
	/// RFIDComm inherits from NetSerialComm, graciously provided to the global C# community by John Hinds.
	/// See http://msdn.microsoft.com/msdnmag/issues/02/10/NETSerialComm/default.aspx for more information on
	/// the base class.  RFIDComm assumes settings specific to TI's RFID specifications, as noted within the 
	/// class definition.  All communication is initiated by the host.  After RFIDComm initiates communication
	/// (by serializing a packet and writing it out to the serial port represented by this RFIDComm object),
	/// RFIDComm waits for the response packet.  Settings are exposed as SerPort (to indicate which COM port
	/// to use), and TransTimeOut (how long to wait on a response packet before error).  Baud rate is assumed
	/// to be 57600 (documented as default by TI).  SerPort defaults to "COM1:". TransTimeOut defaults 500 ms.
	/// </summary>
	public class RFIDComm : CommBase
	{
		/* Straight from the S6350 doc, p. 7:
		 * The S6350 Reader is designed to operate as a part of a host-based reader system, which essentially
		 * relegates the reader to be a slave to the host. Host-to-Tag-it reader serial communications are
		 * accomplished within data packets whereby communications from the host to the reader are known as
		 * requests, and replies from the reader to the host are known as responses. This communication
		 * occurs at RS-232 levels using 57,000 baud, 8 data bits, 1 start bit, 1 stop bit and no parity. By
		 * definition, the host is always the primary station and initiates all communication sequences. These
		 * sequences consist of request/response pairs where the host waits for a response prior to continuing.
		 */

		private enum RFIDCommDefaults : int
		{
			defaultBaud = 57600,
			ridiculouslyLargePacket = 0x100,
			defaultTimeout = 500
		}

		private const string DefaultComPort = "COM1:";

		private string serPort = DefaultComPort;
		public string SerPort
		{
			get
			{
				return serPort;
			}
			set
			{
				serPort = value;
			}
		}
		/// <summary>
		/// Set preferences for serial communications subsystem.  The defaults use
		/// the documented standard of 57600 baud, 8 data bits, 1 start bit, 1 stop
		/// bit, and no parity.  User can specify which com port (COM1: is default)
		/// by setting SerPort before calling Open().
		/// </summary>
		/// <returns>CommBaseSettings</returns>
		protected override JH.CommBase.CommBase.CommBaseSettings CommSettings()
		{
			// Invoke defaults from base class
			CommBaseSettings cbs = base.CommSettings();
			// see notes above ... use 57000 baud, 
			// 8 bits (default for CommBase),
			// no parity (default for CommBase),
			// no handshaking (parameter 3),
			// user can modify which port to use by setting SerPort
			cbs.SetStandard(SerPort,(int)RFIDCommDefaults.defaultBaud,Handshake.none);
			return cbs;
		}

		private byte [] buffer = new byte[(int)RFIDCommDefaults.ridiculouslyLargePacket];	// ridiculously large packet size
		private uint bufferP = 0;
		private uint packetSize = (uint) RFIDCommDefaults.ridiculouslyLargePacket;  // ridiculously large packet size

		private void resetBuffer()
		{
			buffer = new byte[(int)RFIDCommDefaults.ridiculouslyLargePacket];
			bufferP = 0;
			packetSize = (uint)RFIDCommDefaults.ridiculouslyLargePacket;
		}

		// interprocess communication between overlapped I/O threads
		private ManualResetEvent TransFlag = new ManualResetEvent(true);
		private uint transTimeout = (uint) RFIDCommDefaults.defaultTimeout;
		public uint TransTimeout
		{
			get 
			{ 
				return transTimeout; 
			}
			set 
			{
				transTimeout = value;
			}
		}

		protected byte [] Transact(byte[] toSend) 
		{
			Send(toSend);
			TransFlag.Reset();
			if (!TransFlag.WaitOne((int)TransTimeout, false)) ThrowException("Timeout");
			byte[] s;
			lock(buffer) 
			{
				s=buffer;
				resetBuffer();
			}
			return s;
		}

		/// <summary>
		/// Unsolicited packets get dumped to console
		/// </summary>
		/// <param name="buff"></param>
		protected void OnRxLine(byte[] buff)
		{
			Packet p = Packet.deserialize(buff);
			Console.WriteLine("Unsolicited packet received:\n{0}",p.ToString());
			lock(buffer)
			{
				resetBuffer();
			}
		}

		/// <summary>
		/// Callback function used by overlapped I/O threads to deliver one byte at a time
		/// to the RFIDComm object.
		/// </summary>
		/// <param name="ch"></param>
		protected override void OnRxChar(byte ch)
		{
			// all bytes get shoved into a buffer
			lock(buffer) {buffer[bufferP++]=ch;} 
			// after three bytes, compute the packet size
			// and reallocate the buffer to fit
			if( bufferP == 3 ) 
			{
				// time to compute size of incoming packet
				packetSize = 0;
				packetSize += (uint)buffer[1];  // LSB
				packetSize += (uint)buffer[2]*(uint)RFIDCommDefaults.ridiculouslyLargePacket;  // MSB

				// resize buffer to match packet size
				byte[] tmp = new byte[(int)packetSize];
				lock(buffer) 
				{
					Array.Copy(buffer,0,tmp,0,3);
					buffer = tmp;
				}
			}
				// once the buffer has all the expected packets, signal 
				// other thread that it's "time to quit listening"
			else if( bufferP == packetSize )
			{
				if (TransFlag.WaitOne(0,false)) 
					// signaled, so this is unsolicited packet
				{
					OnRxLine(buffer);
				}
				else
					// not signaled, so set it to tell Transact we're done
				{
					TransFlag.Set();
				}
			}
		}


		/// <summary>
		/// Default constructor
		/// </summary>
		public RFIDComm() : this(null)
		{
		}

		/// <summary>
		/// Constructor, with comm port parameter
		/// </summary>
		/// <param name="comPort">string</param>
		public RFIDComm(string comPort)
		{
			if( comPort != null )
			{
				SerPort = comPort;
			}

		}

		/// <summary>
		/// Helper method to extend Packet interface to user classes.  Serializes request packet p
		/// to com port, and returns response packet.  Throws exception on timeout or comm error.
		/// </summary>
		/// <param name="p">Packet</param>
		/// <returns>Packet</returns>
		public Packet Transact( Packet p )
		{
			Packet retval;
			retval = Packet.deserialize( Transact(p.serialize()) );
			return retval;
		}
		
		/// <summary>
		/// Static utility function to serialize Packet objects out
		/// to the S6350 reader, and return the response Packet.
		/// </summary>
		/// <param name="p">Packet</param>
		/// <param name="port">String representation of serial port (i.e., "COM1:")</param>
		/// <param name="timeout">Time (in ms) to wait for response from S6350</param>
		/// <returns>Packet</returns>
		public static Packet TransactPacket( Packet p, string port, uint timeout )
		{
			RFIDComm rc = new RFIDComm(port);
			rc.TransTimeout = timeout;
			if( !rc.Open() )
			{
				rc.ThrowException("Failed to open serial port: " + rc.SerPort);
			}
			byte[] retval = rc.Transact(p.serialize());
			rc.Close();
			return Packet.deserialize(retval);
		}
	}
}