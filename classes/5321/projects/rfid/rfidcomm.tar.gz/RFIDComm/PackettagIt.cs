using System;
using System.IO;

namespace RFIDencode
{
	/// <summary>
	/// Packettagit is abstract class for the Tag-it specific reader commands.
	/// Inherits from Packet
	/// @author : Jeff Wilson
	///			: Ashish Vashishta
	/// </summary>
	public abstract class PackettagIt : Packet 
	{
		// initialize to illegal value
		protected byte blockNum = 0xff;		
		/// <summary>
		/// For single block operations, this represents the block in question.
		/// Legal values range from 0 to TagIt_Constants.Max_Data_Block_Address
		/// </summary>
		public byte BlockNum 
		{
			get 
			{ 
				if( blockNum > (byte)TagIt_Constants.Max_Data_Block_Address )
				{
					throw new InvalidOperationException("BlockNum not set");
				}
				return blockNum; 
			}
			set 
			{
				if( value > (byte) TagIt_Constants.Max_Data_Block_Address )
				{
					// could throw exception here ... or just fail silently
					return;    
				}
				blockNum = value;
			}
		}
		// four bytes represented by single block
		private byte[] blockData;	
		/// <summary>
		/// For single block operations, this byte array represents the 
		/// TagIt_Constants.Data_Block_Size byte block in question
		/// </summary>
		public byte[] BlockData
		{
			get
			{
				// do we need to throw exception if not set?  do we need to force null in ctor?
				return blockData;
			}
			set
			{
				if( value.Length != (int) TagIt_Constants.Data_Block_Size ) 
				{
					// could throw exception here ... or just fail silently
					return;    
				}
				blockData = new byte[value.Length];
				Array.Copy(value,0,blockData,0,value.Length);
			}
		}
		// transponder's unique ID
		private uint txPonderID;		
		private bool tidSet = false;

		/// <summary>
		/// For address-mode requests and responses that read an RFID's serial number,
		/// TxPonderID represents that unique identifier.
		/// </summary>
		public uint TxPonderID
		{
			get
			{
				if( !tidSet ) 
				{
					throw new InvalidOperationException("TxPonderID not set");
				}
				return txPonderID;
			}
			set
			{
				// should this be an exception thrown, or an implicit set?
				// I'm going for the implicit thing
				if( PType == Packet_Type.Request )
				{
					CommandFlag = (byte) Command_Flags.Request_Addressed_Mode;
				}
				txPonderID = value;
				tidSet = true;
			}
		}
		private bool lsSet = false;
		// two bits representing lock status of single block (4 bytes)
		private byte lockStatus;	
		/// <summary>
		/// Single block response packets report on the lock status of the single block in question.
		/// </summary>
		public byte LockStatus
		{
			get
			{
				if( !lsSet ) 
				{
					throw new InvalidOperationException("LockStatus not set");
				}
				return lockStatus;
			}
			set 
			{
				lsSet = true;
				lockStatus = value;
			}
		}
		/// <summary>
		/// Constructor used by sub class deserialization methods.
		/// </summary>
		public PackettagIt(byte[] buffer, byte cmd, byte cf) : base( buffer)
		{
			Command = cmd;
			CommandFlag = cf;
		}

		/// <summary>
		/// Static helper function to deserialize from a byte array representing 
		/// an RFID command. 
		/// </summary>
		/// <param name="byteBuffer">byte[]</param>
		/// <param name="command">byte</param>
		/// <returns>PackettagIt</returns>
		public static PackettagIt deSerialize(byte[] byteBuffer,byte command)
		{
			//see the packet structure 
			byte commandFlag = byteBuffer[5];
			switch( command ) 
			{
				case (byte) TagIt_Commands.Read_Single_Block:
					return new Read_Single_Block(byteBuffer,command,commandFlag);
				case (byte) TagIt_Commands.Write_Single_Block:
					return new Write_Single_Block(byteBuffer,command,commandFlag);
//				case (byte) TagIt_Commands.Lock_Single_Block:
//					return new Lock_Single_Block(byteBuffer);
				case (byte) TagIt_Commands.Read_Transponder_Details:
					return new Read_Transponder_Details(byteBuffer,command,commandFlag);	
				case (byte) TagIt_Commands.Special_Read_Block:
					return new Special_Read_Block(byteBuffer,command,commandFlag);	
				case (byte) Misc_Commands.Reader_Version:
					return new Reader_Version(byteBuffer,command,commandFlag);
				default:
					break;
			}
			return null;
		}
		/// <summary>
		/// function to serialize to the stream.
		/// </summary>
		/// <param name="sr">Stream</param>
		/// <returns>void</returns>
		new public void serialize( Stream sr )
		{
			base.serialize(sr);
		}
	}
	/// <summary>
	/// Represents a four byte data block, its lock status, and its block number
	/// </summary>
	public class DataBlock
	{
		private byte [] buffer = new byte[4];
		private byte lockStatus = 0x0;
		private byte blockNumber = 0xff;
		/// <summary>
		/// byte[] array representing the four byte data in this block
		/// </summary>
		public byte[] Buffer
		{
			get
			{
				return buffer;
			}
			set
			{
				Array.Copy(value,0,buffer,0,4);
			}
		}
		/// <summary>
		/// For response packets, represents the lock status of this four byte block
		/// </summary>
		public byte LockStatus
		{
			get
			{
				return lockStatus;
			}
			set
			{
				lockStatus = value;
			}
		}
		/// <summary>
		/// Set to the block number corresponding to the data in Buffer
		/// </summary>
		public byte BlockNumber
		{
			get
			{
				return blockNumber;
			}
			set
			{
				// only valid addresses are 0 ... 7
				blockNumber = (byte) (value & 0x07);
			}
		}
		/// <summary>
		/// Default constructor
		/// </summary>
		public DataBlock( ) : this(null)
		{
		}
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="buffer">(byte[]) Expects six bytes: four for data, one for lock status, one for block number</param>
		public DataBlock( byte[] buffer )
		{
			if(buffer != null)
			{
				Array.Copy(buffer,0,Buffer,0,4);
				LockStatus = buffer[4];
				BlockNumber = buffer[5];
			}
		}
		/// <summary>
		/// Serializes this class into a six byte array: four for data, one for lock status, one for block number
		/// </summary>
		/// <returns>byte[]</returns>
		public byte[] GetDataBlock()
		{
			byte [] tmp = new byte[6];
			Array.Copy(Buffer,0,tmp,0,4);
			tmp[4] = LockStatus;
			tmp[5] = BlockNumber;
			return tmp;
		}
	}
}
