using System;
using RFIDencode;
using RFIDComm;

namespace RFIDComm
{
	/// <summary>
	/// MainApp serves as implementation of the Store Inventory application.
	/// </summary>
	class MainApp
	{
		/// <summary>
		/// Display helpful comments to screen.
		/// </summary>
		public static void PrintUsage() 
		{
			string [] cmdline = Environment.CommandLine.Split(null);
			string progName = cmdline[0];
			// strip path info from program name
			if( progName.IndexOf('\\') > 0 )
			{
				string[] arr = progName.Split('\\');
				progName = arr[arr.Length-1];
				// strip trailing double-quote (")
				progName = progName.TrimEnd(new char[1] {'"'});
			}
			Console.WriteLine("\nUsage: {0} \"<store id>\"\n",progName);
			Console.WriteLine("       [Your four byte store ID, each byte separated by a space] [com port [timeout]]\n");
			Console.WriteLine("   or  {0} <byte1 (MSB)> <byte2> <byte3> <byte4 (LSB)> [<com port> [<timeout>]]",progName);
			Console.WriteLine("   or  {0} zero",progName);
			Console.WriteLine("   or  {0} showall",progName);
			Console.WriteLine("   or  {0} -? [help message]",progName);
		}

		/// <summary>
		/// Display detailed help instructions to screen.
		/// </summary>
		public static void PrintHelp()
		{
			PrintUsage();
			string outstr = "\n\nEnter your store ID\n";
			outstr += "This program monitors a TI S6350 RFID reader.\n";
			outstr += "For every TagIt RFID that crosses the S6350's\n";
			outstr += "range, the RFID's unique identifier is echoed\n";
			outstr += "to the console, and your store ID is written to\n";
			outstr += "the first available 4 byte block on the RFID.\n\n";
			outstr += "If no blocks are available for writing, an\n";
			outstr += "error message displays which RFID identifier\n";
			outstr += "failed the write operation.\n";
			outstr += "\n[Optional] com port\n";
			outstr += "  Set which com port the S6350 is connected to (default=\"COM1:\")\n";
			outstr += "\n[Optional] timeout (in milliseconds)\n";
			outstr += "  Set the timeout between request/response packets (default=500)\n";
			outstr += "\n\"zero\" Sets all 8 blocks on RFID to zero pattern (55 55 55 55)\n";
			outstr += "\n\"showall\" Show value stored in all 8 blocks on RFID\n";
			Console.WriteLine(outstr);
		}

		/// <summary>
		/// Invoke RFIDencode.Packet static methods and demonstrate
		/// communication with the S6350 reader by implementing the
		/// Store Inventory application.
		/// </summary>
		[MTAThread]
		static void Main(string[] args)
		{
			// set the defaults ... overwrite these, if specified on the command line
			string comPort = "COM1:";
			uint transTimeOut = 500;
			string blankBlockData = "55 55 55 55";

			// store ID to write out to RFIDs
			string storeID = "";
			byte [] bStoreID;

			// parse command line arguments
			if( args.Length < 1 || args.Length > 6 )
			{
				PrintUsage();
				return;
			}
			if( args.Length <= 3 )
			{
				if ( args[0] == "zero" )
				{
					if( RFIDUtil.ZeroRFID("55 55 55 55") )
					{
						Console.WriteLine("RFID was overwritten with zeros");
					}
					else
					{
						Console.WriteLine("Error occurred trying to zero RFID");
					}
					return;
				}
				else if ( args[0] == "showall" )
				{
					Special_Read_Block srb = RFIDUtil.ReadAllBlocks();
					if( srb == null ) 
					{
						Console.WriteLine("Error occurred on read operation");
					}
					else
					{
						for( int i = 0; i <= (int) TagIt_Constants.Max_Data_Block_Address; i++ )
						{
							DataBlock db = srb.getBlock(i);
							Console.WriteLine("BlockData[{0:X2}]={1}",
								db.BlockNumber,HexCon.ByteToString(db.Buffer));
						}
					}
					return;
				}
				// search command line for help request
				else if ( args[0].IndexOfAny(new char[3] {'?','h','H'}) > 0 ) 
				{
					PrintHelp();
					return;
				}
				// one string command line parameter
				string[] bytes = args[0].Split(null);
				// should be in the form of four bytes, each separated by one space
				if( bytes.Length != 4 )
				{
					Console.WriteLine("Wrong format ({0}): expecting four bytes\n\n",args[0]);
					PrintUsage();
					return;
				}
				storeID = args[0];
				if( args.Length > 1 )
				{
					comPort = args[1];
				}
				if( args.Length > 2 )
				{
					transTimeOut = Convert.ToUInt32(args[2]);
				}
			}
			else // args.Length >= 4
			{
				foreach( string arg in args )
				{
					storeID += arg + " ";
				}
				// remove the last space
				storeID = storeID.Remove(storeID.Length-1,1);
				if( args.Length > 4 )
				{
					comPort = args[4];
				}
				if( args.Length > 5 )
				{
					transTimeOut = Convert.ToUInt32(args[5]);
				}
			}
			bStoreID = HexCon.StringToByte(storeID);
			storeID = HexCon.ByteToString(bStoreID);
			Console.WriteLine("\nUsing 0x{0:X2}{1:X2}{2:X2}{3:X2} for store ID",bStoreID[0],bStoreID[1],bStoreID[2],bStoreID[3]);

			Console.WriteLine("\nUsing \"{0}\" with timeout={1}\n",comPort,transTimeOut);

			// test the com setting before entering the loop
			RFIDComm rc = new RFIDComm(comPort);
			rc.TransTimeout = transTimeOut;
			if( !rc.Open() ) 
			{
				Console.WriteLine("Failed to open {0} ... exiting",comPort);
				return;
			}
			rc.Close();

			// Known good quantities get written to the helper class
			RFIDUtil.comPort = comPort;
			RFIDUtil.timeOut = transTimeOut;

			while(true)
			{
				uint txID = 0;

				// Read from whatever transponder is in range (non addressed mode)
				Packet p_resp = RFIDUtil.ReadAllBlocks();
				if( p_resp == null )
				{
					// try again
					continue;
				}

				// The response packet indicates an error state
				if( p_resp.ResponseError )
				{
					// no transponders in range ... try again
					System.Threading.Thread.Sleep((int)transTimeOut);
					continue;
				}

				// Capture the unique serial number of this transponder
				txID = ((PackettagIt)p_resp).TxPonderID;

				Console.WriteLine("Detected RFID: {0:X8}\n",txID);

				// Check for storeID already stored in RFID ... don't rewrite!
				bool alreadyWritten = false;
				// if full, write error to console
				bool allFull = true;
				// otherwise, grab the block number of the first blank block
				int blockNum = 0;
				// cycle through all blocks
				for( int i = 0; i < (int) TagIt_Constants.Number_Of_Blocks; i++ )
				{
					DataBlock db = ((Special_Read_Block)p_resp).getBlock(i);
					// read data into string for easier comparison
					string dbStr = HexCon.ByteToString(HexCon.ReverseMSBFourBytes(db.Buffer));
					// if this is the storeID, we're done
					if( dbStr == storeID ) 
					{
						Console.WriteLine("StoreID already written to {0:X8}\n",txID);
						alreadyWritten = true;
						break;
					}
					// if this is a blank block, we're going to write to it
					else if( dbStr == blankBlockData )
					{
						// signal the condition and break the loop
						blockNum = i;
						allFull = false;
						break;
					}
				}

				if( !alreadyWritten )
				{
					if( allFull )
					{
						// no free blocks on the RFID
						Console.WriteLine("Store ID not written: no free blocks on transponder");
					}
					else 
					{
						// first free block is indicated by blockNum
						// write storeID to blockNum
						DataBlock db = new DataBlock();
						db.BlockNumber = (byte) blockNum;
						db.Buffer = bStoreID;
						if(RFIDUtil.WriteBlock(txID,db))
						{
							Console.WriteLine("Wrote to {0:X8}",txID);
						}
						else
						{
							Console.WriteLine("Error writing to {0:X8}",txID);
							// Sleep for transTimeOut ms before looking for the next RFID
							System.Threading.Thread.Sleep((int)transTimeOut);
							continue;
						}
					}
				}
				else 
				{
					// storeID detected as already written to RFID
					Console.WriteLine("Store ID not written: previously written to transponder");
				}
				// Sleep for transTimeOut ms before looking for the next RFID
				System.Threading.Thread.Sleep((int)transTimeOut);
			}
		}
	}
}



/*				Old Main  ... useful for stepping through commands manually ... needs to be modified
							  to calculate BCC automatically ...
 
  				Console.WriteLine("Enter the command string to send: [press enter to quit]");
				string cmd = Console.ReadLine();
				if( cmd == "" ) break;
				byte [] buffer = HexCon.StringToByte(cmd);
				Packet req = Packet.deserialize(buffer);
				Packet resp = RFIDComm.TransactPacket(req,"COM1:",500);
				Console.WriteLine("\nSent: \n{0}",req.ToString());
				Console.WriteLine("Received: \n{0}\n{1}",HexCon.ByteToString(resp.serialize()),resp.ToString()); 
*/
