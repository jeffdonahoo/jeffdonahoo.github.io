using System;
using System.Globalization;
using System.IO;

namespace RFIDencode
{
	public class LRCCheckSum
	{
		/// <summary>
		/// Performs the Block Character Check (Longitudinal Redundancy Check)
		/// on the command string (byte array).  Returns two bytes, LSB is LRC,
		/// MSB is ones-complement of LRC.
		/// </summary>
		/// <param name="sCmdString">byte array containing header and data of packet</param>
		/// <returns>two byte BCC of command packet</returns>
		public static byte[] checkLRC(byte[] sCmdString)
		{
			//LRC is long field.
			long LRC = 0x0;
			int i = 0;
			// convert to decimal bytes
			byte[] sLRC = new byte[2];
			// compute the accumulative XOR of all bytes in sCmdString
			for (i = 0 ; i < sCmdString.Length ; i++ )
			{
				LRC = LRC ^ (long) sCmdString[i];
			}
			
			// compute the ones complement of the LRC
			long onesComp = LRC ^ 0xff;

			// LSB gets LRC
			sLRC[0]=(byte)LRC;
			// MSB gets ones complement
			sLRC[1]=(byte)onesComp;

			return sLRC;
		}
	}
}