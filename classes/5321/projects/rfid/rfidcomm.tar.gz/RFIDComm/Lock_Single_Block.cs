using System;
using System.IO;

namespace RFIDencode
{
	public class Lock_Single_Block : PackettagIt
	{
		public Lock_Single_Block( byte[] buffer ) : base(buffer)
		{
			//in the request packet the fourth bit of the command flag is set to 1
			//, to indicate address flag. 
			//condition to search for that fourth bit and see if it is set. and to see if the 
			//length of the rest of packet is 14 (indicating request addressed mode)
			if ( commandFlag == (byte) Packet_Header.Command_Flag_Addressed_Mode 
				&& (lengthOfPacket == (short)14 ) )
			{
			}
				//check for request non addressed mode.
			else if ( commandFlag != (byte) Packet_Header.Command_Flag_Addressed_Mode  
				&& (lengthOfPacket == (short)10 ) )
			{
			}
				//check to see if response addressed/non addressed mode.
			else if ( lengthOfPacket == (short)12 ) 
			{
				//if command flag is set to 1 indicates error.
				if ( ( commandFlag ^ 0x00 )== commandFlag )
				{
				}
				else
				{
				}
			}
			else
			{
				throw new IOException("Lock Single Block failed to interpret serial byte stream");
			}
		}

		public void serialize( Stream sr ) 
		{
		}
	}
}