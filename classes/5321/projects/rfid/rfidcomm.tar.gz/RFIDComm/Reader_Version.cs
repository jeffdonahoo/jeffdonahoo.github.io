using System;
using System.IO;
using System.Text ;


namespace RFIDencode
{
	/// <summary>
	/// Class representing a command packet to gather information from RFID transceiver
	/// </summary>
	public class Reader_Version : PackettagIt
	{
		/// <summary>
		/// Reader reports either "Ready" or "Lacks firmware"
		/// </summary>
		public enum Reader_Type : byte 
		{
			Ready = 0x07,
			Lacks_Firmware = 0x00
		}
		private Reader_Type readerType = Reader_Type.Lacks_Firmware;
		private bool rtIsSet = false;

		/// <summary>
		/// Response packet reports transceiver status as either "Ready" or "Lacks firmware"
		/// </summary>
		public Reader_Type ReaderType
		{
			get
			{
				if( !rtIsSet )
				{
					throw new InvalidOperationException("ReaderType not set"); // value not set
				}
				return readerType;
			}
			set
			{
				if( !Enum.IsDefined(typeof(Reader_Type),value) )
				{
					return;    // could throw exception here ... or just fail silently
				}
				rtIsSet = true;
				readerType = value;
			}
		}
		private short versionNumber;
		private bool verIsSet = false;

		/// <summary>
		/// Response packet reports Version Number of RFID transceiver
		/// </summary>
		public short VersionNumber
		{
			get
			{
				if( !verIsSet ) 
				{
					throw new InvalidOperationException("VersionNumber not set");	// value not set
				}
				return versionNumber;
			}
			set
			{
				verIsSet = true;
				versionNumber = value;
			}
		}

		/// <summary>
		/// Sets version number from byte array (expects LSB first)
		/// </summary>
		/// <param name="ver">byte[]</param>
		public void SetVersionNumber( byte[] ver )
		{
			short val = 0;
			if( ver.Length != 2 ) 
			{
				return;
			}
			val += (short) ver[1];
			val *= 0x100;
			val += (short) ver[0];
			VersionNumber = val;
		}
		// <summary>
		// Returns version number in byte array (LSB first)
		// </summary>
		public byte[] GetVersionNumber()
		{
			byte [] ret = new byte[2] { 0x00, 0x00 };
			short ver = VersionNumber;
			ret[0] = (byte) (ver % 0x100);  // LSB
			ret[1] = (byte) (ver / 0x100);  // MSB
			return ret;
		}

		
		/// <summary>
		/// Method to override ToString().
		/// <returns>string</returns>
		/// </summary>
		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();
			sb.AppendFormat("Reader_Version (0x{0:X2})\n",Command);
			switch(PType)
			{
				case Packet_Type.Request:
					sb.Append(" [Request]\n");
					break;
				case Packet_Type.Response:
					sb.Append(" [Response]\n");
					sb.AppendFormat(" Firmware version: {0:X4}\n",VersionNumber);
					string rt = (ReaderType==Reader_Type.Ready) ? "Ready" : "Lacks Firmware";
					sb.AppendFormat(" Reader status: 0x{0:X} ({1})\n",ReaderType,rt);
					break;
				case Packet_Type.Unknown:
				default:
					sb.Append(" badly formed packet\n");
					break;
			}
			return sb.ToString();
		}
		
		/// <summary>
		/// Default constructor
		/// </summary>
		public Reader_Version() : this(null,(byte)Misc_Commands.Reader_Version,(byte)0)
		{
			PType = Packet_Type.Unknown;
		}

		/// <summary>
		/// Constructor used by deserialize() method
		/// </summary>
		/// <param name="buffer">byte[]</param>
		/// <param name="cmd">byte</param>
		/// <param name="cf">byte</param>
		public Reader_Version( byte[] buffer, byte cmd, byte cf ) : base(buffer,cmd,cf)
		{
			if( buffer == null )
			{
				; // do nothing
			}
			else if( buffer.Length == 0x9 )
			{
				PType = Packet_Type.Request;
			}
			else if( buffer.Length == 0xC ) 
			{
				PType = Packet_Type.Response;
				ReaderType = (Reader_Type) buffer[9];
				byte [] verNum = new byte[2];
				Array.Copy(buffer,7,verNum,0,2);
				SetVersionNumber( verNum );
			}
		}

		/// <summary>
		/// Exposes this Packet, serialized to byte[].
		/// </summary>
		/// <returns>byte[]</returns>
		override public byte[] serialize()
		{
			MemoryStream ms = new MemoryStream((int)Packet_Header.MAX_PACKET_SIZE);
			serialize(ms);
			return ms.ToArray();
		}

		/// <summary>
		/// Method to serialize to the stream.
		/// <param name="sr">writeable Stream</param>
		/// </summary>
		new public void serialize( Stream sr ) 
		{
			if( PType == Packet_Type.Unknown ) 
			{
				throw new ArgumentException("must set packet type to Request or Response prior to serializing");
			}
			else if( PType == Packet_Type.Request ) 
			{
				; // nothing to do
			}
			else // PType == Packet_Type.Response 
			{
				// create a buffer to byte-ify the object
				byte[] rv = new byte[(int)Response_Size_Constants.Reader_Version];
				// put the two byte short in the buffer, LSB first
				Array.Copy(GetVersionNumber(),0,rv,0,GetVersionNumber().Length);
				// offset into the buffer by two bytes, drop in Reader Type
				rv[GetVersionNumber().Length]=(byte)ReaderType;
				// shove bytes into base class' buffer
				this.Buffer = rv;
			}
			// invoke base class serialization
			base.serialize(sr);
		}
	}
}
