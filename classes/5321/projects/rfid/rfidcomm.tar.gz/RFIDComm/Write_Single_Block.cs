using System;
using System.IO;
using System.Text ;


namespace RFIDencode
{
	/// <summary>
	/// Writes a single block of data at the specified address.
	/// if address is not specified, writes to any available reader.
	/// Inherits from PackettagIt
	/// @author : Jeff Wilson
	///			: Ashish Vashishta
	/// </summary>
	public class Write_Single_Block : PackettagIt
	{
		private byte successByte;
		// get/set the buye to indicate successful writing.
		public byte SuccessByte
		{
			get 
			{
				return successByte;
			}
			set
			{
				successByte = value;
			}
		}
		/// <summary>
		/// Overrides the ToString() method.
		/// <returns>string</returns>
		/// </summary>
		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();
			sb.AppendFormat("Write_Single_Block (0x{0:X2})\n",Command);
			switch(PType)
			{
				case Packet_Type.Request:
					sb.Append(" [Request]\n");
					string txid;
					//append the transponder ID.
					try 
					{
						txid = "0x" + Convert.ToString(TxPonderID,16);
					}
					catch
					{
						txid = "(not set)";
					}
					sb.AppendFormat(" Transponder ID: {0}\n",txid);
					sb.AppendFormat(" Block Number: 0x{0:X2}\n",BlockNum);
					sb.AppendFormat(" Block Data: {0}\n",HexCon.ByteToString(BlockData));
					break;
				case Packet_Type.Response:
					sb.Append(" [Response]\n");
					sb.AppendFormat(" Data: 0x{0:X2}\n",SuccessByte);
					break;
				case Packet_Type.Unknown:
				default:
					sb.Append(" badly formed packet\n");
					break;
			}
			return sb.ToString();
		}
		/// <summary>
		/// Constructors.
		/// </summary>
		public Write_Single_Block() : this(null,(byte)TagIt_Commands.Write_Single_Block,(byte)0)
		{
			successByte = 0x00 ;
			blockNum = 0xff ;
		}
		/// <summary>
		/// Constructors.
		/// <param name="buffer"></param>
		/// <param name="cmd"></param>
		/// <param name="cf"></param>
		/// </summary>
		public Write_Single_Block( byte[] buffer, byte cmd, byte cf ) : base(buffer,cmd,cf)
		{
			if( buffer == null )
			{
				; // do nothing
			}
			//in the request packet the fourth bit of the command flag is set to 1
			//, to indicate address flag. 
			//condition to search for that fourth bit and see if it is set. and to see if the 
			//length of the rest of packet is 18 (indicating request addressed mode)
			else if ( CommandFlag == (byte) Command_Flags.Request_Addressed_Mode 
					&& LengthOfPacket == (short)
						((int)Request_Size_Constants.Write_Single_Block_Addressed +
						 (int)Packet_Header.HEADER_SIZE +
						 (int)Packet_Header.LRC_SIZE) )
			{
				PType = Packet_Type.Request;
				// throw an exception if the buffer is not the expected length
				if( buffer.Length != (int)
						((int)Request_Size_Constants.Write_Single_Block_Addressed +
						 (int)Packet_Header.HEADER_SIZE +
						 (int)Packet_Header.LRC_SIZE) ) 
				{
					throw new IOException("Write_Single_Block encountered unexpected data format when trying to determine Transponder ID");
				}
				// read txPonderID from byteBuffer, LSB is first
				TxPonderID = 0;
				// start with MSB and go towards LSB, multiplying by 0x100 as you go
				for(int i=10;i>6;i--)
				{
					TxPonderID = TxPonderID * 0x100 + (uint) buffer[i];
				}
				// read blockNum from buffer, LSB first
				blockNum = buffer[11] ;
				byte[] writtenData = new byte[(int)TagIt_Constants.Data_Block_Size];
				Array.Copy(buffer,12,writtenData ,0,(int)TagIt_Constants.Data_Block_Size );
				//copy this data to the block data.
				BlockData = writtenData ;

			}
			//check for request non addressed mode.
			else if ( CommandFlag != (byte) Command_Flags.Request_Addressed_Mode
					&& LengthOfPacket == (short)
						((int)Request_Size_Constants.Write_Single_Block_Nonaddressed +
						 (int)Packet_Header.HEADER_SIZE +
						 (int)Packet_Header.LRC_SIZE) )
			{
				// NON-ADDRESSED mode
				PType = Packet_Type.Request;
				// throw an exception if buffer is not expected length
				if( buffer.Length != (int)
						((int)Request_Size_Constants.Write_Single_Block_Nonaddressed +
						 (int)Packet_Header.HEADER_SIZE +
						 (int)Packet_Header.LRC_SIZE))
				{
					throw new IOException("Write_Single_Block encountered unexpected data format ");
				}
				// read blockNum from buffer, LSB first
				blockNum = buffer[7] ;
				byte[] writtenData = new byte[(int)TagIt_Constants.Data_Block_Size];
				Array.Copy(buffer,8,writtenData ,0,(int)TagIt_Constants.Data_Block_Size );
				//copy this data to the block data.
				BlockData = writtenData ;
			}

			//check to see if response packet .
			else if ( LengthOfPacket == (short)
						((int)Response_Size_Constants.Write_Single_Block +
						 (int)Packet_Header.HEADER_SIZE +
						 (int)Packet_Header.LRC_SIZE)) 
			{
				PType = Packet_Type.Response;
				//if command flag is set to 1 indicates error.
				if ( CommandFlag == (byte) Command_Flags.Response_Command_Flag_Error )
				{
					throw new IOException("Write_Single_Block encountered error flag in response packet");
				}
				else
				{
					if( buffer.Length != (int)
								((int)Response_Size_Constants.Write_Single_Block +
								 (int)Packet_Header.HEADER_SIZE +
								 (int)Packet_Header.LRC_SIZE))
					{
						throw new IOException("Write_Single_Block encountered unexpected data format ");
					}
					//check if the write operation was successful or not.
					if (buffer[7] != (byte)Response_Size_Constants.Write_Single_Block_Successful_Op)
					{
						throw new IOException("Write Single Block : Unsuccessful operation");
					}
				}
			}
			else
			{
				throw new IOException("Write Single Block failed to interpret serial byte stream");
			}
		}

		override public byte[] serialize()
		{
			MemoryStream ms = new MemoryStream((int)Packet_Header.MAX_PACKET_SIZE);
			serialize(ms);
			return ms.ToArray();
		}
		/// <summary>
		/// Method to serialize to the stream.
		/// <param name="sr"></param>
		/// </summary>
		new public void serialize( Stream sr ) 
		{
			// the buffer to store WSB specific bytes
			byte [] wsb = null;		
			// if packet type is not specified ...
			if( PType == Packet_Type.Unknown ) 
			{
				throw new ArgumentException("Write_Single_Block: must set packet type to Request or Response prior to serializing");
			}
			else if( PType == Packet_Type.Request ) 
			{
				// CommandFlag specifies ADDRESSED mode
				if( CommandFlag == (byte) Command_Flags.Request_Addressed_Mode )
				{
					wsb = new byte[(int)Request_Size_Constants.Write_Single_Block_Addressed];
					uint tid = TxPonderID;
					//write transponder ID .
					for(int i=0;i<(int)TagIt_Constants.Transponder_ID_Size;i++)
					{
						wsb[i] = (byte) (tid % 0x100);
						tid /= 0x100;
					}
					int k = (int)TagIt_Constants.Transponder_ID_Size;
					wsb[k++] = BlockNum ;
					//write the data LSB first.
					for (int j = (int)TagIt_Constants.Data_Block_Size-1; j >= 0 ; --j)
					{
						wsb[k++] = BlockData[j] ;
					}
					base.Buffer = wsb ;
				}
				else  // NON_ADDRESSED mode
				{
					wsb = new byte[(int)Request_Size_Constants.Write_Single_Block_Nonaddressed];
					int k = 0 ;
					wsb[k++] = BlockNum ;
					//write the data LSB first.
					for (int j = (int)TagIt_Constants.Data_Block_Size - 1; j >= 0; --j)
					{
						wsb[k++] = BlockData[j] ;
					}
					base.Buffer = wsb ;
				}
			}
			else // PType == Packet_Type.Response 
			{
				//One byte to indicate whether successful o
				wsb = new byte[1];
				wsb[0] = successByte ;
				base.Buffer = wsb ;
			}
			base.serialize(sr);
		}
		/// <summary>
		/// Method to set the response error flag.
		/// </summary>
		public void SetResponseErrorFlag()
		{
			if( PType != Packet_Type.Response ) 
			{
				throw new InvalidOperationException("Must set packet type to Response prior to calling SetResponseErrorFlag");
			}
			CommandFlag = (byte) Command_Flags.Response_Command_Flag_Error;
		}
	}
}
