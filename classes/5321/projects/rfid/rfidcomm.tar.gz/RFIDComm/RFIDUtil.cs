using System;
using RFIDencode;
using RFIDComm;

namespace RFIDComm
{
	/// <summary>
	/// Static utility functions for utilizing RFIDComm.
	/// </summary>
	public class RFIDUtil
	{
		public static string comPort = "COM1:";
		public static uint timeOut = 500;

		/// <summary>
		/// Using RFIDComm, send Write Single Block command over serial port
		/// </summary>
		/// <param name="wsb">Write Single Block object</param>
		/// <returns>(bool) true on success</returns>
		private static bool WriteSingleBlock( Write_Single_Block wsb )
		{
			try
			{
				RFIDComm.TransactPacket(wsb,comPort,timeOut);
			}
			catch
			{
				return false;
			}
			return true;
		}

		/// <summary>
		/// Write a single block to any RFID in range
		/// </summary>
		/// <param name="db">DataBlock</param>
		/// <returns>(bool) true on success</returns>
		public static bool WriteBlock( DataBlock db )
		{
			Write_Single_Block wsb = new Write_Single_Block();
			wsb.PType = Packet_Type.Request;
			wsb.BlockData = db.Buffer;
			wsb.BlockNum = db.BlockNumber;
			return WriteSingleBlock(wsb);
		}

		/// <summary>
		/// Write a single block to a specific RFID
		/// </summary>
		/// <param name="TransponderID">(uint) Address of RFID</param>
		/// <param name="db">DataBlock</param>
		/// <returns>(bool) true on success</returns>
		public static bool WriteBlock( uint TransponderID, DataBlock db )
		{
			Write_Single_Block wsb = new Write_Single_Block();
			wsb.PType = Packet_Type.Request;
			wsb.TxPonderID = TransponderID;
			wsb.BlockData = db.Buffer;
			wsb.BlockNum = db.BlockNumber;
			return WriteSingleBlock(wsb);
		}

		/// <summary>
		/// Reset all blocks on RFID to zero pattern
		/// </summary>
		/// <param name="zero">(string) zero pattern to write out</param>
		/// <returns>(bool) true on success </returns>
		public static bool ZeroRFID( string zero )
		{
			DataBlock db = new DataBlock();
			db.Buffer = HexCon.StringToByte(zero);
			for( int i = 0; i <= (int) TagIt_Constants.Max_Data_Block_Address; i++ )
			{
				db.BlockNumber=(byte)i;
				if( !WriteBlock(db) )
					return false;
			}
			return true;
		}

		/// <summary>
		/// Reset all blocks on a specific RFID to zero pattern
		/// </summary>
		/// <param name="TransponderID">(uint) Address of RFID</param>
		/// <param name="zero">(string) zero pattern to write out</param>
		/// <returns>(bool) true on success</returns>
		public static bool ZeroRFID( uint TransponderID, string zero )
		{
			DataBlock db = new DataBlock();
			db.Buffer = HexCon.StringToByte(zero);
			for( int i = 0; i <= (int)TagIt_Constants.Max_Data_Block_Address; i++ )
			{
				if( !WriteBlock(TransponderID,db) )
					return false;
			}
			return true;
		}

		/// <summary>
		/// Read all data blocks from any RFID in range
		/// </summary>
		/// <returns>(Special_Read_Block) resulting packet object, containing all 8 data blocks on successful read;
		/// otherwise, null</returns>
		public static Special_Read_Block ReadAllBlocks()
		{
			Special_Read_Block srb_req = new Special_Read_Block();
			srb_req.PType = Packet_Type.Request;	// create a request packet
			srb_req.BitMask = 0xff;		// read all blocks of any transponder in range
			Packet p_resp = null;
			while(true) 
			{
				try
				{
					// send packet, wait for response, return response packet
					p_resp = RFIDComm.TransactPacket(srb_req,comPort,timeOut);
					break;
				}
				catch
				{
					// sleep for timeOut ms before trying again
					System.Threading.Thread.Sleep((int)timeOut);
					continue;
				}
			}
			return (Special_Read_Block) p_resp;
		}
	}
}
