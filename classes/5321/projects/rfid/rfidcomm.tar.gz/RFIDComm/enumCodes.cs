using System;

namespace RFIDencode
{
	/// <summary>
	/// Constants defined for packet headers
	/// </summary>
	public enum Packet_Header : byte 
	{
		SOF = 0x01,
		ISOTAG = 0x60,
		NODEADDRLSB = 0x00,
		NODEADDRMSB = 0x00,
		MAX_PACKET_SIZE = 0xFF,
		HEADER_SIZE = 0x07,
		LRC_SIZE = 0x02
	}
	/// <summary>
	/// Constants defined for command flags
	/// </summary>
	public enum Command_Flags : byte
	{
		Request_NonAddressed_Mode = 0x00,		// Request Command Flag, 0x00 == NON_ADDRESSED_MODE
		Request_Addressed_Mode = 0x10,			// Request Command Flag, 0x10 == ADDRESSED_MODE
		Response_Command_No_Error = 0x00,		// Response Command Flag, 0x00 == NO_ERROR
		Response_Command_Flag_Error = 0x10		// Response Command Flag, 0x10 == ERROR
	}
	/// <summary>
	/// Constants defined for Tag-it commands
	/// </summary>
	public enum TagIt_Commands : byte
	{
		Read_Single_Block = 0x02,
		Write_Single_Block = 0x03,
		Lock_Single_Block = 0x04,
		Read_Transponder_Details = 0x05,
		Special_Read_Block = 0x0F
	}
	/// <summary>
	/// Constants defined for miscellaneous Tag-it commands
	/// </summary>
	public enum Misc_Commands  : byte
	{
		Initialize_Flash = 0xD0,
		Send_Data_ToFlash = 0xD8,
		Reader_Version = 0xF0,
		Read_Inputs = 0xF1,
		Write_Reader_Outputs = 0xF2,
		RF_Carrier_On_Off = 0x04
	}
	/// <summary>
	/// Constants defined for ISO commands
	/// </summary>
	public enum ISO_Commands  : byte
	{
		Inventory = 0x01,
		Stay_Quiet = 0x02,
		Read_Single_Block = 0x20,
		Write_Single_Block = 0x21,
		Lock_Block = 0x22,
		Read_Multiple_Blocks = 0x23,
		Write_AFI = 0x27,			
		Lock_AFI = 0x28,
		Write_DSFID = 0x29,
		Lock_DSFID = 0x2A,
		Get_MultiBlock_Security_Status = 0x2C
	}
	/// <summary>
	/// Constants defined for Error Codes returned in response packets
	/// </summary>
	public enum Error_Codes : byte
	{
		Transponder_Not_Found = 0x01,
		Command_Not_Supported = 0x02,
		Packet_BCC_Invalid = 0x03,
		Packet_Flags_Invalid = 0x04,
		General_Write_Failure = 0x05,
		Write_Failed_Locked_Blocked = 0x06,
		Function_Not_Supported = 0x07,
		Undefined_Error = 0x0F
	}
	/// <summary>
	/// Constants defined for packet type
	/// </summary>
	public enum Packet_Type : byte
	{
		Unknown,
		Request,
		Response
	}
	/// <summary>
	/// Constants defined for expected sizes of request packet payload
	/// </summary>
	public enum Request_Size_Constants : int
	{
		Read_Single_Block_Addressed = 5,
		Read_Single_Block_Nonaddressed = 1,
		Write_Single_Block_Addressed = 9,
		Write_Single_Block_Nonaddressed = 5,
		Lock_Single_Block_Addressed = 5,
		Lock_Single_Block_Nonaddressed = 1,
		Read_Transponder_Details_Nonaddressed = 0,
		Read_Transponder_Details_Addressed = 4,
		Special_Read_Block_Nonaddressed = 1,
		Reader_Version = 0
	}
	/// <summary>
	/// Constants defined for expected sizes of response packet payload
	/// </summary>
	public enum Response_Size_Constants : int
	{
		Write_Single_Block_Successful_Op = 0,
		Read_Single_Block = 6,
		Write_Single_Block = 1,
		Lock_Single_Block = 1,
		Read_Transponder_Details_Error = 1,
		Read_Transponder_Details = 9,
		Reader_Version = 3,
		Special_Read_Block_Error = 1,
		Special_Read_Block_SID_Only = 4,
		Special_Read_Block_One_Block = 10,
		Special_Read_Block_Two_Blocks = 16,
		Special_Read_Block_Three_Blocks = 22,
		Special_Read_Block_Four_Blocks = 28,
		Special_Read_Block_Five_Blocks = 34,
		Special_Read_Block_Six_Blocks = 40,
		Special_Read_Block_Seven_Blocks = 46,
		Special_Read_Block_Eight_Blocks = 52
	}
	/// <summary>
	/// Constants defined for various Tag-it entities
	/// </summary>
	public enum TagIt_Constants : int
	{
		Number_Of_Blocks = 8,
		Data_Block_Size = 4,
		Transponder_ID_Size = 4,
		Max_Data_Block_Address = 7
	}
}