

/**
 * <p>Title: Secure Connection</p>
 * <p>Description: CSI 5321Program 1</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Baylor CS</p>
 * @authors: Lin Cai,Jerry Knight,Ashish Vashishta,Jeff Wilson
 * @version 1.0
 */


import java.net.Socket;

public class SecureConnection extends Connection{
  public SecureConnection(Socket aConn) {
    super(aConn);
  }

  void connProcess(Socket aSocket) throws Exception
  {

  }
}