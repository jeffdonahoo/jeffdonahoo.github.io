README for MySurge
$Revision: 1.4 $
11/01/2003

Description:

MySurge is an example application that uses MultiHop ad-hoc routing.  It
is designed to be used in conjunction with the SurgeListen java tool. Each
Surge node forwards their address to a base station.
The node can also respond to broadcast commands from the base.


Tools:

net.tinyos.tools.SurgeListen

This class processes sensor data from Surge programmed nodes via a
GenericBase station.

How to Run:
A. In TOSSIM
1. export MOTECOM=tossim-serial
2. bulid/pc/main.exe <num_notes>
3. java SurgeListen

B. On serial port 1
1. export MOTECOM=serial@COM1:mica2
2. MIB510=/dev/COM1 make mica2 install
3. java SurgeListen