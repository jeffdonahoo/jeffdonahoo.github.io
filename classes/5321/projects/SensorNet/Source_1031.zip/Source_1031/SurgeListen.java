import java.io.*;
import net.tinyos.packet.*;
import net.tinyos.util.*;
import net.tinyos.message.*;

public class SurgeListen {
    public static void main(String args[]) throws IOException {
	if (args.length > 0) {
	    System.err.println("usage: java net.tinyos.tools.Listen");
	    System.exit(2);
	}
	
	PacketSource reader = BuildSource.makePacketSource();
	if (reader == null) {
	    System.err.println("Invalid packet source (check your MOTECOM environment variable)");
	    System.exit(2);
	}

	try {
	  reader.open(PrintStreamMessenger.err);
	  for (;;) {
	    byte[] packet = reader.readPacket();
		System.out.print("Dest:"+packet[1]);
		System.out.print(" Source:"+packet[6]+packet[7]);
		System.out.print(" Readings:"+packet[12]+packet[13]);
	    System.out.println();
	  }
	}
	catch (IOException e) {
	    System.err.println("Error on " + reader.getName() + ": " + e);
	}
    }
}

