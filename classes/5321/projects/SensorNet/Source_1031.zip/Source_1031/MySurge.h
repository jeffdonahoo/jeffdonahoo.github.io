int INITIAL_TIMER_RATE = 2048;

typedef struct MySurgeMsg {
  uint8_t type;
  uint16_t reading;
  uint16_t parentaddr;
} __attribute__ ((packed)) MySurgeMsg;

enum {
  MYSURGE_TYPE_SENSORREADING = 0
}; 


enum {
  AM_MYSURGEMSG = 17
};




