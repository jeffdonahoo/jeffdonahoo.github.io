import java.io.*;

public class DelimitedCharacterOutput extends BufferedWriter {

  public DelimitedCharacterOutput(OutputStream out, String encoding)
      throws UnsupportedEncodingException {
    super(new OutputStreamWriter(out, encoding));
  }

  public DelimitedCharacterOutput(OutputStream out)
      throws UnsupportedEncodingException {
    super(new OutputStreamWriter(out));
  }

  public void write(String s) throws IOException {
    write(s, 0, s.length());
  }

  public void write(String s, char delimiter) throws IOException {
    String sOut = s + delimiter;
    write(sOut, 0, sOut.length());
  }
}