import java.io.*;

public class DelimitedCharacterInput extends BufferedReader {

  public DelimitedCharacterInput(InputStream in, String encoding)
      throws UnsupportedEncodingException {
    super(new InputStreamReader(in, encoding));
  }

  public DelimitedCharacterInput(InputStream in)
      throws UnsupportedEncodingException {
    super(new InputStreamReader(in));
  }

  public String getNextToken(char delimiter) throws IOException {
    int nextChar;
    StringBuffer buf = new StringBuffer();
    nextChar = read();
    if (nextChar == -1) {
      throw new EOFException("EOF Found");
    }
    while ((nextChar != -1) && (nextChar != delimiter)) {
      buf.append((char) nextChar);
      nextChar = read();
    }

    return buf.toString();
  }

  public void readFully(char[] cbuf) throws IOException {
    int bytesRead = 0;
    while (bytesRead < cbuf.length) {
      int rv = read(cbuf, bytesRead, cbuf.length);
      if (rv == -1) {
        throw new EOFException("Premature EOF");
      }
      bytesRead += rv;
    }
  }
}