import java.util.*;
import java.io.*;

class StringList {
  ArrayList stringList = new ArrayList();

  public StringList() {
  }

  public StringList(InputStream in, PrintStream out) {
    while (ConsoleStream.readLine("Add (Y/N)> ", in, out).toUpperCase()
        .indexOf('Y') != -1) {
      stringList.add(ConsoleStream.readLine("> ", in, out));
    }
  }

  public StringList(DelimitedCharacterInput in, char delimiter) throws IOException {
    int listLen = Integer.parseInt(in.getNextToken(delimiter));
    stringList = new ArrayList(listLen);
    for (int i = 0; i < listLen; i++) {
      stringList.add(in.getNextToken(delimiter));
    }
  }

  public void serializeGrammarEnc(DelimitedCharacterOutput out, char delimiter)
      throws IOException {
    out.write(Integer.toString(stringList.size()), delimiter);
    for (Iterator i = stringList.iterator(); i.hasNext();) {
      out.write((String) i.next(), delimiter);
    }
  }

  public String toString() {
    String s = "";
    for (int i = 0; i < stringList.size(); i++) {
      s += "\n" + stringList.get(i);
    }

    return s;
  }

  public void add(String s) {
    stringList.add(s);
  }
}