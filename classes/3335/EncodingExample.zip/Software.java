import java.io.*;

public abstract class Software extends Product {

  public StringList OSList;

  public Software(int ID, String description, float price, StringList OSList) {
    super(ID, description, price);
    this.OSList = OSList;
  }

  public Software(InputStream in, PrintStream out) {
    super(in, out);
    out.println("OSs:");
    OSList = new StringList(in, out);
  }

  public static Software deserializeGrammarEnc(DelimitedCharacterInput in,
      int ID, String description, float price) throws IOException {
    StringList OSList = new StringList(in, Product.GRAMMAR_DELIMITER);

    switch ((char) in.read()) {
      case 'G':
        return new Game(in, ID, description, price, OSList);
      case 'P':
        return new Player(in, ID, description, price, OSList);
      default:
        throw new IOException("Bad subtype");
    }
  }

  public void serializeGrammarEnc(DelimitedCharacterOutput out) throws IOException {
    super.serializeGrammarEnc(out);
    out.write('S');
    OSList.serializeGrammarEnc(out, Product.GRAMMAR_DELIMITER);
  }

  public String toString() {
    return super.toString() + "\nCompatible OSs:" + OSList.toString();
  }
}