import java.io.*;

public abstract class Product {

  private int ID;
  private String description;
  private float price;

  protected static final String GRAMMAR_CHARENC = "ASCII";
  protected static final char GRAMMAR_DELIMITER = ' ';
  protected static final int GRAMMAR_DESCRLEN = 10;

  public Product(int ID, String description, float price) {
    this.ID = ID;
    this.description = description;
    this.price = price;
  }

  public Product(InputStream in, PrintStream out) {
    ID = ConsoleStream.readInt("ID> ", in, out);
    description = ConsoleStream.readLine("Description> ", in, out);
    price = (float) (ConsoleStream.readDouble("Price> $", in, out));
  }

  public static Product deserializeGrammarEnc(DelimitedCharacterInput in)
      throws IOException {

    int ID = Integer.parseInt(in.getNextToken(GRAMMAR_DELIMITER));
    char[] description = new char [GRAMMAR_DESCRLEN];
    in.readFully(description);
    float price = Float.parseFloat(in.getNextToken(GRAMMAR_DELIMITER));
    switch ((char) in.read()) {
      case 'H':
        return new Hardware(in, ID, new String(description).trim(), price);
      case 'S':
        return Software.deserializeGrammarEnc(in, ID,
          new String(description).trim(), price);
      default:
        throw new IOException("Bad subtype");
    }
  }

  public void serializeGrammarEnc(DelimitedCharacterOutput out) throws IOException {
    out.write(Integer.toString(ID), GRAMMAR_DELIMITER);

    // Make description the right length
    String outDesc;
    if (description.length() < GRAMMAR_DESCRLEN) {
      outDesc = description;
      for (int i = 0; i < GRAMMAR_DESCRLEN - description.length(); i++) {
        outDesc += " ";
      }
    } else {
      outDesc = description.substring(0, GRAMMAR_DESCRLEN);
    }
    out.write(outDesc);
    out.write(Float.toString(price), GRAMMAR_DELIMITER);
  }

  public static Product deserializeConsoleEnc(InputStream in, PrintStream out) {
    out.println("1-Hardware");
    out.println("2-Game");
    out.println("3-Player");
    for (;;) {
      int choice = ConsoleStream.readInt("New Product> ", in, out);
      switch (choice) {
        case 1:
          return new Hardware(in, out);
        case 2:
          return new Game(in, out);
        case 3:
          return new Player(in, out);
        default:
          out.println("Bad choice");
      }
    }
  }

  public int getID() {
    return ID;
  }

  public String toString() {
    return "ID: " + ID + "\n" + description + "\n$" + price;
  }
}