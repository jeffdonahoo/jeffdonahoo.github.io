public final class RatingType implements Comparable {
  public static final int EVERYONE_ORDINAL = 0;
  public static final int TEEN_ORDINAL = 1;
  public static final int MATURE_ORDINAL = 2;

  public static final RatingType EVERYONE = new RatingType(EVERYONE_ORDINAL);
  public static final RatingType TEEN = new RatingType(TEEN_ORDINAL);
  public static final RatingType MATURE = new RatingType(MATURE_ORDINAL);

  private int ordinal;

  private RatingType(int ordinal) {
    this.ordinal = ordinal;
  }

  public int getOrdinal() {
    return ordinal;
  }

  public int compareTo(Object size) {
    int cmpSize = ((RatingType) size).getOrdinal();

    if (ordinal == cmpSize) {
      return 0;
    } else if (ordinal < cmpSize) {
        return -1;
    } else {
      return 1;
    }
  }

  public static final RatingType makeRatingType(int ordinal) {
    if ((ordinal < EVERYONE_ORDINAL) && (ordinal > MATURE_ORDINAL)) {
      return null;
    }
    return new RatingType [] {EVERYONE, TEEN, MATURE}[ordinal];
  }

  public String toString() {
    return new String [] {"EVERYONE", "TEEN", "MATURE"}[ordinal];
  }
}
