import java.io.*;

public class Game extends Software {

  public RatingType rating;

  public Game(int ID, String description, float price, StringList OSList,
      RatingType rating) {
    super(ID, description, price, OSList);
    this.rating = rating;
  }

  public Game(InputStream in, PrintStream out) {
    super(in, out);
    out.println("Choose a rating:");
    out.println("1 - Everyone");
    out.println("2 - Teen");
    out.println("3 - Mature");
    rating = RatingType.makeRatingType(ConsoleStream.readInt("Rating> ", in, out) - 1);
  }

  public Game(DelimitedCharacterInput in, int ID, String description,
      float price, StringList OSList) throws IOException {
    super(ID, description, price, OSList);
    switch ((char) in.read()) {
      case ('E'):
        rating = RatingType.EVERYONE;
        break;
      case ('T'):
        rating = RatingType.TEEN;
        break;
      case ('M'):
        rating = RatingType.MATURE;
        break;
      default:
        throw new IOException("Bad rating");
    }
    in.readLine();
  }

  public void serializeGrammarEnc(DelimitedCharacterOutput out) throws IOException {
    super.serializeGrammarEnc(out);
    out.write('G');
    out.write(rating.toString().substring(0,1), Product.GRAMMAR_DELIMITER);
    out.newLine();
  }

  public String toString() {
    return super.toString() + "\nRating: " + rating;
  }
}