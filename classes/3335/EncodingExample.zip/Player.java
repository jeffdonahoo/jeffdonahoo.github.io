import java.io.*;

public class Player extends Software {

  private StringList mediaTypeList;

  public Player(int ID, String description, float price, StringList OSList,
      StringList mediaTypeList) {
    super(ID, description, price, OSList);
    this.mediaTypeList = mediaTypeList;
  }

  public Player(InputStream in, PrintStream out) {
    super(in, out);
    out.println("Media Types:");
    mediaTypeList = new StringList(in, out);
  }

  public Player(DelimitedCharacterInput in, int ID,
      String description, float price, StringList OSList) throws IOException {
    super(ID, description, price, OSList);
    mediaTypeList = new StringList(in, Product.GRAMMAR_DELIMITER);
    in.readLine();
  }

  public void serializeGrammarEnc(DelimitedCharacterOutput out) throws IOException {
    super.serializeGrammarEnc(out);
    out.write('P');
    mediaTypeList.serializeGrammarEnc(out, Product.GRAMMAR_DELIMITER);
    out.newLine();
  }

  public String toString() {
    return super.toString() + "\nMedia Types:" + mediaTypeList;
  }
}
