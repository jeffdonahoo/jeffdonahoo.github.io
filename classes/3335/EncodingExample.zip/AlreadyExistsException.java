import java.io.IOException;

/**
 * Signals that the given ID already exists.
 */
public class AlreadyExistsException extends IOException {

  /**
   * Constructs a AlreadyExistsException with the message "Product <id> already exists."
   *
   * @param ID ID of the product not found
   */
  public AlreadyExistsException(int id) {
    super("Product " + id + " already exists.");
  }

  private AlreadyExistsException(String s) {
  }
}