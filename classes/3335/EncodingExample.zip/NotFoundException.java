import java.io.IOException;

/**
 * Signals that the given ID could not be found.
 */
public class NotFoundException extends IOException {

  /**
   * Constructs a NotFoundException with the message "Product <id> not found."
   *
   * @param ID ID of the product not found
   */
  public NotFoundException(int id) {
    super("Product " + id + " not found.");
  }

  private NotFoundException(String s) {
  }
}