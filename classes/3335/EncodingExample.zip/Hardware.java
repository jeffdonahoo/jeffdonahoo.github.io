import java.io.*;

public class Hardware extends Product {

  private float weight;

  public Hardware(int ID, String description, float price, float weight) {
    super(ID, description, price);
    this.weight = weight;
  }

  public Hardware(DelimitedCharacterInput in, int ID, String description,
      float price) throws IOException {
    super(ID, description, price);
    weight = Float.parseFloat(in.getNextToken(GRAMMAR_DELIMITER));
    in.readLine();
  }

  public Hardware(InputStream in, PrintStream out) {
    super(in, out);
    weight = (float) (ConsoleStream.readDouble("Weight> ", in, out));
  }

  public void serializeGrammarEnc(DelimitedCharacterOutput out) throws IOException {
    super.serializeGrammarEnc(out);
    out.write('H');
    out.write(Float.toString(weight), Product.GRAMMAR_DELIMITER);
    out.newLine();
  }

  public String toString() {
    return super.toString() + "\nWeight: " + weight;
  }
}
