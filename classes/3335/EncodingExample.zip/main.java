import java.io.*;

public class main {

  public static void main(String args[]) throws IOException {

    String input = "123 Protoman  24.95 S1 XP GE\n" +
                   "321 Windows MP0 S2 XP 2K P1 MP3\n";
    DelimitedCharacterInput in = new DelimitedCharacterInput(
        new ByteArrayInputStream(input.getBytes("ASCII")));
    try {
      for (; ; ) {
        Product p = Product.deserializeGrammarEnc(in);
        System.out.println(p);
        System.out.println();
      }
    } catch (EOFException e) {}

    Product p = Product.deserializeConsoleEnc(System.in, System.out);

    System.out.println("\n" + p + "\n\nencodes to\n");
    DelimitedCharacterOutput out = new DelimitedCharacterOutput(System.out);
    p.serializeGrammarEnc(out);
    out.flush();

    System.out.println("Done");
  }
}