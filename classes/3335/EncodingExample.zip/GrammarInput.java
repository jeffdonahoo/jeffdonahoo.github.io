import java.io.*;

public class GrammarInput extends DelimitedCharacterInput {

  public GrammarInput(InputStream in) throws UnsupportedEncodingException {
    super(in, Product.GRAMMAR_CHARENC);
  }
}